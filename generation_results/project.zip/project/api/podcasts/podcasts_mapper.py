from domain.podcasts.podcasts_entity import Podcasts
from api.dtos.podcasts_dto import PodcastsCreate, PodcastsUpdate, PodcastsResponse
from typing import Union

class PodcastsMapper:
    """Mapper for Podcasts between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Podcasts) -> PodcastsResponse:
        """Convert entity to response DTO"""
        return PodcastsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[PodcastsCreate, PodcastsUpdate]) -> Podcasts:
        """Convert DTO to entity"""
        return Podcasts(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Podcasts, dto: PodcastsUpdate) -> Podcasts:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

podcasts_mapper = PodcastsMapper()
