from typing import List, Optional
from domain.podcasts.podcasts_entity import Podcasts
from domain.podcasts.podcasts_service_interface import IAsyncPodcastsService
from infrastructure.repositories.podcasts.podcasts_repository import PodcastsRepository
from api.mappers.podcasts_mapper import podcasts_mapper
from shared.utils.logger import logger

class PodcastsService(IAsyncPodcastsService):
    """Service implementation for Podcasts"""

    def __init__(self):
        self.repository = PodcastsRepository()

    async def get_by_id(self, id: str) -> Optional[Podcasts]:
        """Get podcasts by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting podcasts by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Podcasts]:
        """Get all podcastss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all podcastss: {str(e)}")
            raise

    async def create(self, data: Podcasts) -> Podcasts:
        """Create new podcasts"""
        try:
            return await self.repository.create(podcasts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating podcasts: {str(e)}")
            raise

    async def update(self, id: str, data: Podcasts) -> Optional[Podcasts]:
        """Update podcasts"""
        try:
            return await self.repository.update(id, podcasts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating podcasts: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete podcasts"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting podcasts: {str(e)}")
            raise
