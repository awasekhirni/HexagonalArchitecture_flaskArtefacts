from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.podcasts.podcasts_entity import Podcasts
from domain.podcasts.podcasts_service_interface import IAsyncPodcastsService
from api.dtos.podcasts_dto import PodcastsCreate, PodcastsUpdate, PodcastsResponse
from api.mappers.podcasts_mapper import podcasts_mapper
from api.validations.podcasts_validation_schemas import validate_podcasts_create, validate_podcasts_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('podcasts', description='Podcasts operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
podcasts_create_model = api.model('PodcastsCreate', {
    'name': fields.String(required=True, description='podcasts name'),
    'description': fields.String(description='podcasts description'),
    'status': fields.String(description='podcasts status', enum=['active', 'inactive', 'pending'])
})

podcasts_update_model = api.model('PodcastsUpdate', {
    'name': fields.String(description='podcasts name'),
    'description': fields.String(description='podcasts description'),
    'status': fields.String(description='podcasts status', enum=['active', 'inactive', 'pending'])
})

podcasts_response_model = api.model('PodcastsResponse', {
    'id': fields.String(description='podcasts ID'),
    'name': fields.String(description='podcasts name'),
    'description': fields.String(description='podcasts description'),
    'status': fields.String(description='podcasts status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPodcastsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class PodcastsList(Resource):
        @api.doc('list_podcastss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(podcasts_response_model)
        @token_required
        async def get(self):
            """List all podcastss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [podcasts_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting podcastss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_podcasts')
        @api.expect(podcasts_create_model)
        @api.marshal_with(podcasts_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new podcasts"""
            try:
                data = api.payload
                validated_data = validate_podcasts_create(data)
                entity = podcasts_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return podcasts_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating podcasts: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The podcasts identifier')
    @api.response(404, 'Podcasts not found')
    class PodcastsResource(Resource):
        @api.doc('get_podcasts')
        @api.marshal_with(podcasts_response_model)
        @token_required
        async def get(self, id):
            """Get a podcasts given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Podcasts not found")
                return podcasts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting podcasts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_podcasts')
        @api.expect(podcasts_update_model)
        @api.marshal_with(podcasts_response_model)
        @token_required
        async def put(self, id):
            """Update a podcasts given its identifier"""
            try:
                data = api.payload
                validated_data = validate_podcasts_update(data)
                entity = podcasts_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Podcasts not found")
                return podcasts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating podcasts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_podcasts')
        @api.response(204, 'Podcasts deleted')
        @token_required
        async def delete(self, id):
            """Delete a podcasts given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Podcasts not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting podcasts {id}: {str(e)}")
                api.abort(400, str(e))

    return api
