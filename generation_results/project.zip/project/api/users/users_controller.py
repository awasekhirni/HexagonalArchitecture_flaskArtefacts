from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.users.users_entity import Users
from domain.users.users_service_interface import IAsyncUsersService
from api.dtos.users_dto import UsersCreate, UsersUpdate, UsersResponse
from api.mappers.users_mapper import users_mapper
from api.validations.users_validation_schemas import validate_users_create, validate_users_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('users', description='Users operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
users_create_model = api.model('UsersCreate', {
    'name': fields.String(required=True, description='users name'),
    'description': fields.String(description='users description'),
    'status': fields.String(description='users status', enum=['active', 'inactive', 'pending'])
})

users_update_model = api.model('UsersUpdate', {
    'name': fields.String(description='users name'),
    'description': fields.String(description='users description'),
    'status': fields.String(description='users status', enum=['active', 'inactive', 'pending'])
})

users_response_model = api.model('UsersResponse', {
    'id': fields.String(description='users ID'),
    'name': fields.String(description='users name'),
    'description': fields.String(description='users description'),
    'status': fields.String(description='users status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUsersService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class UsersList(Resource):
        @api.doc('list_userss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(users_response_model)
        @token_required
        async def get(self):
            """List all userss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [users_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting userss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_users')
        @api.expect(users_create_model)
        @api.marshal_with(users_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new users"""
            try:
                data = api.payload
                validated_data = validate_users_create(data)
                entity = users_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return users_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating users: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The users identifier')
    @api.response(404, 'Users not found')
    class UsersResource(Resource):
        @api.doc('get_users')
        @api.marshal_with(users_response_model)
        @token_required
        async def get(self, id):
            """Get a users given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Users not found")
                return users_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting users {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_users')
        @api.expect(users_update_model)
        @api.marshal_with(users_response_model)
        @token_required
        async def put(self, id):
            """Update a users given its identifier"""
            try:
                data = api.payload
                validated_data = validate_users_update(data)
                entity = users_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Users not found")
                return users_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating users {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_users')
        @api.response(204, 'Users deleted')
        @token_required
        async def delete(self, id):
            """Delete a users given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Users not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting users {id}: {str(e)}")
                api.abort(400, str(e))

    return api
