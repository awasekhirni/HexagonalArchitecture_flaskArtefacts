from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class UsersStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class UsersBase(BaseModel):
    """Base schema for users"""
    pass

class UsersCreate(UsersBase):
    """Schema for creating users"""
    name: str
    description: Optional[str] = None
    status: UsersStatus = UsersStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class UsersUpdate(UsersBase):
    """Schema for updating users"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[UsersStatus] = None

class UsersResponse(UsersBase):
    """Response schema for users"""
    id: str
    name: str
    description: Optional[str] = None
    status: UsersStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_users_create(data: UsersCreate) -> UsersCreate:
    """Validate users creation data"""
    return data

def validate_users_update(data: UsersUpdate) -> UsersUpdate:
    """Validate users update data"""
    return data
