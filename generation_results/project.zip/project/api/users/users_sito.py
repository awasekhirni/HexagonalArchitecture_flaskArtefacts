from typing import List, Optional
from domain.users.users_entity import Users
from domain.users.users_service_interface import IAsyncUsersService
from infrastructure.repositories.users.users_repository import UsersRepository
from api.mappers.users_mapper import users_mapper
from shared.utils.logger import logger

class UsersService(IAsyncUsersService):
    """Service implementation for Users"""

    def __init__(self):
        self.repository = UsersRepository()

    async def get_by_id(self, id: str) -> Optional[Users]:
        """Get users by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting users by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Users]:
        """Get all userss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all userss: {str(e)}")
            raise

    async def create(self, data: Users) -> Users:
        """Create new users"""
        try:
            return await self.repository.create(users_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating users: {str(e)}")
            raise

    async def update(self, id: str, data: Users) -> Optional[Users]:
        """Update users"""
        try:
            return await self.repository.update(id, users_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating users: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete users"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting users: {str(e)}")
            raise
