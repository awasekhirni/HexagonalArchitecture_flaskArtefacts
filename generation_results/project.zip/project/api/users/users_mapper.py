from domain.users.users_entity import Users
from api.dtos.users_dto import UsersCreate, UsersUpdate, UsersResponse
from typing import Union

class UsersMapper:
    """Mapper for Users between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Users) -> UsersResponse:
        """Convert entity to response DTO"""
        return UsersResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[UsersCreate, UsersUpdate]) -> Users:
        """Convert DTO to entity"""
        return Users(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Users, dto: UsersUpdate) -> Users:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

users_mapper = UsersMapper()
