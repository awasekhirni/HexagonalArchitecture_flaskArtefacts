from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Freelance_requestsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Freelance_requestsBase(BaseModel):
    """Base schema for freelance_requests"""
    pass

class Freelance_requestsCreate(Freelance_requestsBase):
    """Schema for creating freelance_requests"""
    name: str
    description: Optional[str] = None
    status: Freelance_requestsStatus = Freelance_requestsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Freelance_requestsUpdate(Freelance_requestsBase):
    """Schema for updating freelance_requests"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Freelance_requestsStatus] = None

class Freelance_requestsResponse(Freelance_requestsBase):
    """Response schema for freelance_requests"""
    id: str
    name: str
    description: Optional[str] = None
    status: Freelance_requestsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_freelance_requests_create(data: Freelance_requestsCreate) -> Freelance_requestsCreate:
    """Validate freelance_requests creation data"""
    return data

def validate_freelance_requests_update(data: Freelance_requestsUpdate) -> Freelance_requestsUpdate:
    """Validate freelance_requests update data"""
    return data
