from typing import List, Optional
from domain.freelance_requests.freelance_requests_entity import Freelance_requests
from domain.freelance_requests.freelance_requests_service_interface import IAsyncFreelance_requestsService
from infrastructure.repositories.freelance_requests.freelance_requests_repository import Freelance_requestsRepository
from api.mappers.freelance_requests_mapper import freelance_requests_mapper
from shared.utils.logger import logger

class Freelance_requestsService(IAsyncFreelance_requestsService):
    """Service implementation for Freelance_requests"""

    def __init__(self):
        self.repository = Freelance_requestsRepository()

    async def get_by_id(self, id: str) -> Optional[Freelance_requests]:
        """Get freelance_requests by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting freelance_requests by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Freelance_requests]:
        """Get all freelance_requestss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all freelance_requestss: {str(e)}")
            raise

    async def create(self, data: Freelance_requests) -> Freelance_requests:
        """Create new freelance_requests"""
        try:
            return await self.repository.create(freelance_requests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating freelance_requests: {str(e)}")
            raise

    async def update(self, id: str, data: Freelance_requests) -> Optional[Freelance_requests]:
        """Update freelance_requests"""
        try:
            return await self.repository.update(id, freelance_requests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating freelance_requests: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete freelance_requests"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting freelance_requests: {str(e)}")
            raise
