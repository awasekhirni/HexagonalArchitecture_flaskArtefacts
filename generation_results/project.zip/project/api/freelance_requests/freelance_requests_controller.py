from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.freelance_requests.freelance_requests_entity import Freelance_requests
from domain.freelance_requests.freelance_requests_service_interface import IAsyncFreelance_requestsService
from api.dtos.freelance_requests_dto import Freelance_requestsCreate, Freelance_requestsUpdate, Freelance_requestsResponse
from api.mappers.freelance_requests_mapper import freelance_requests_mapper
from api.validations.freelance_requests_validation_schemas import validate_freelance_requests_create, validate_freelance_requests_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('freelance_requests', description='Freelance_requests operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
freelance_requests_create_model = api.model('Freelance_requestsCreate', {
    'name': fields.String(required=True, description='freelance_requests name'),
    'description': fields.String(description='freelance_requests description'),
    'status': fields.String(description='freelance_requests status', enum=['active', 'inactive', 'pending'])
})

freelance_requests_update_model = api.model('Freelance_requestsUpdate', {
    'name': fields.String(description='freelance_requests name'),
    'description': fields.String(description='freelance_requests description'),
    'status': fields.String(description='freelance_requests status', enum=['active', 'inactive', 'pending'])
})

freelance_requests_response_model = api.model('Freelance_requestsResponse', {
    'id': fields.String(description='freelance_requests ID'),
    'name': fields.String(description='freelance_requests name'),
    'description': fields.String(description='freelance_requests description'),
    'status': fields.String(description='freelance_requests status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncFreelance_requestsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Freelance_requestsList(Resource):
        @api.doc('list_freelance_requestss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(freelance_requests_response_model)
        @token_required
        async def get(self):
            """List all freelance_requestss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [freelance_requests_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting freelance_requestss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_freelance_requests')
        @api.expect(freelance_requests_create_model)
        @api.marshal_with(freelance_requests_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new freelance_requests"""
            try:
                data = api.payload
                validated_data = validate_freelance_requests_create(data)
                entity = freelance_requests_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return freelance_requests_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating freelance_requests: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The freelance_requests identifier')
    @api.response(404, 'Freelance_requests not found')
    class Freelance_requestsResource(Resource):
        @api.doc('get_freelance_requests')
        @api.marshal_with(freelance_requests_response_model)
        @token_required
        async def get(self, id):
            """Get a freelance_requests given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Freelance_requests not found")
                return freelance_requests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting freelance_requests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_freelance_requests')
        @api.expect(freelance_requests_update_model)
        @api.marshal_with(freelance_requests_response_model)
        @token_required
        async def put(self, id):
            """Update a freelance_requests given its identifier"""
            try:
                data = api.payload
                validated_data = validate_freelance_requests_update(data)
                entity = freelance_requests_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Freelance_requests not found")
                return freelance_requests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating freelance_requests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_freelance_requests')
        @api.response(204, 'Freelance_requests deleted')
        @token_required
        async def delete(self, id):
            """Delete a freelance_requests given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Freelance_requests not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting freelance_requests {id}: {str(e)}")
                api.abort(400, str(e))

    return api
