from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.job_tag_map.job_tag_map_entity import Job_tag_map
from domain.job_tag_map.job_tag_map_service_interface import IAsyncJob_tag_mapService
from api.dtos.job_tag_map_dto import Job_tag_mapCreate, Job_tag_mapUpdate, Job_tag_mapResponse
from api.mappers.job_tag_map_mapper import job_tag_map_mapper
from api.validations.job_tag_map_validation_schemas import validate_job_tag_map_create, validate_job_tag_map_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('job_tag_map', description='Job_tag_map operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
job_tag_map_create_model = api.model('Job_tag_mapCreate', {
    'name': fields.String(required=True, description='job_tag_map name'),
    'description': fields.String(description='job_tag_map description'),
    'status': fields.String(description='job_tag_map status', enum=['active', 'inactive', 'pending'])
})

job_tag_map_update_model = api.model('Job_tag_mapUpdate', {
    'name': fields.String(description='job_tag_map name'),
    'description': fields.String(description='job_tag_map description'),
    'status': fields.String(description='job_tag_map status', enum=['active', 'inactive', 'pending'])
})

job_tag_map_response_model = api.model('Job_tag_mapResponse', {
    'id': fields.String(description='job_tag_map ID'),
    'name': fields.String(description='job_tag_map name'),
    'description': fields.String(description='job_tag_map description'),
    'status': fields.String(description='job_tag_map status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncJob_tag_mapService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Job_tag_mapList(Resource):
        @api.doc('list_job_tag_maps')
        @api.expect(pagination_parser)
        @api.marshal_list_with(job_tag_map_response_model)
        @token_required
        async def get(self):
            """List all job_tag_maps"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [job_tag_map_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting job_tag_maps: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_job_tag_map')
        @api.expect(job_tag_map_create_model)
        @api.marshal_with(job_tag_map_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new job_tag_map"""
            try:
                data = api.payload
                validated_data = validate_job_tag_map_create(data)
                entity = job_tag_map_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return job_tag_map_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating job_tag_map: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The job_tag_map identifier')
    @api.response(404, 'Job_tag_map not found')
    class Job_tag_mapResource(Resource):
        @api.doc('get_job_tag_map')
        @api.marshal_with(job_tag_map_response_model)
        @token_required
        async def get(self, id):
            """Get a job_tag_map given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Job_tag_map not found")
                return job_tag_map_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting job_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_job_tag_map')
        @api.expect(job_tag_map_update_model)
        @api.marshal_with(job_tag_map_response_model)
        @token_required
        async def put(self, id):
            """Update a job_tag_map given its identifier"""
            try:
                data = api.payload
                validated_data = validate_job_tag_map_update(data)
                entity = job_tag_map_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Job_tag_map not found")
                return job_tag_map_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating job_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_job_tag_map')
        @api.response(204, 'Job_tag_map deleted')
        @token_required
        async def delete(self, id):
            """Delete a job_tag_map given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Job_tag_map not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting job_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

    return api
