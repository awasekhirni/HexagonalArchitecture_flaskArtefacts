from typing import List, Optional
from domain.job_tag_map.job_tag_map_entity import Job_tag_map
from domain.job_tag_map.job_tag_map_service_interface import IAsyncJob_tag_mapService
from infrastructure.repositories.job_tag_map.job_tag_map_repository import Job_tag_mapRepository
from api.mappers.job_tag_map_mapper import job_tag_map_mapper
from shared.utils.logger import logger

class Job_tag_mapService(IAsyncJob_tag_mapService):
    """Service implementation for Job_tag_map"""

    def __init__(self):
        self.repository = Job_tag_mapRepository()

    async def get_by_id(self, id: str) -> Optional[Job_tag_map]:
        """Get job_tag_map by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_tag_map by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_tag_map]:
        """Get all job_tag_maps"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_tag_maps: {str(e)}")
            raise

    async def create(self, data: Job_tag_map) -> Job_tag_map:
        """Create new job_tag_map"""
        try:
            return await self.repository.create(job_tag_map_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_tag_map: {str(e)}")
            raise

    async def update(self, id: str, data: Job_tag_map) -> Optional[Job_tag_map]:
        """Update job_tag_map"""
        try:
            return await self.repository.update(id, job_tag_map_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_tag_map: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_tag_map"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_tag_map: {str(e)}")
            raise
