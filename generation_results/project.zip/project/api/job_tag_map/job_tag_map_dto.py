from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_tag_mapStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_tag_mapBase(BaseModel):
    """Base schema for job_tag_map"""
    pass

class Job_tag_mapCreate(Job_tag_mapBase):
    """Schema for creating job_tag_map"""
    name: str
    description: Optional[str] = None
    status: Job_tag_mapStatus = Job_tag_mapStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_tag_mapUpdate(Job_tag_mapBase):
    """Schema for updating job_tag_map"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_tag_mapStatus] = None

class Job_tag_mapResponse(Job_tag_mapBase):
    """Response schema for job_tag_map"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_tag_mapStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_tag_map_create(data: Job_tag_mapCreate) -> Job_tag_mapCreate:
    """Validate job_tag_map creation data"""
    return data

def validate_job_tag_map_update(data: Job_tag_mapUpdate) -> Job_tag_mapUpdate:
    """Validate job_tag_map update data"""
    return data
