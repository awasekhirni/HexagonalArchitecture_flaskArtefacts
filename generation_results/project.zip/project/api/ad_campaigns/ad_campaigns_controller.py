from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.ad_campaigns.ad_campaigns_entity import Ad_campaigns
from domain.ad_campaigns.ad_campaigns_service_interface import IAsyncAd_campaignsService
from api.dtos.ad_campaigns_dto import Ad_campaignsCreate, Ad_campaignsUpdate, Ad_campaignsResponse
from api.mappers.ad_campaigns_mapper import ad_campaigns_mapper
from api.validations.ad_campaigns_validation_schemas import validate_ad_campaigns_create, validate_ad_campaigns_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('ad_campaigns', description='Ad_campaigns operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
ad_campaigns_create_model = api.model('Ad_campaignsCreate', {
    'name': fields.String(required=True, description='ad_campaigns name'),
    'description': fields.String(description='ad_campaigns description'),
    'status': fields.String(description='ad_campaigns status', enum=['active', 'inactive', 'pending'])
})

ad_campaigns_update_model = api.model('Ad_campaignsUpdate', {
    'name': fields.String(description='ad_campaigns name'),
    'description': fields.String(description='ad_campaigns description'),
    'status': fields.String(description='ad_campaigns status', enum=['active', 'inactive', 'pending'])
})

ad_campaigns_response_model = api.model('Ad_campaignsResponse', {
    'id': fields.String(description='ad_campaigns ID'),
    'name': fields.String(description='ad_campaigns name'),
    'description': fields.String(description='ad_campaigns description'),
    'status': fields.String(description='ad_campaigns status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncAd_campaignsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Ad_campaignsList(Resource):
        @api.doc('list_ad_campaignss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(ad_campaigns_response_model)
        @token_required
        async def get(self):
            """List all ad_campaignss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [ad_campaigns_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting ad_campaignss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_ad_campaigns')
        @api.expect(ad_campaigns_create_model)
        @api.marshal_with(ad_campaigns_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new ad_campaigns"""
            try:
                data = api.payload
                validated_data = validate_ad_campaigns_create(data)
                entity = ad_campaigns_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return ad_campaigns_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating ad_campaigns: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The ad_campaigns identifier')
    @api.response(404, 'Ad_campaigns not found')
    class Ad_campaignsResource(Resource):
        @api.doc('get_ad_campaigns')
        @api.marshal_with(ad_campaigns_response_model)
        @token_required
        async def get(self, id):
            """Get a ad_campaigns given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Ad_campaigns not found")
                return ad_campaigns_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting ad_campaigns {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_ad_campaigns')
        @api.expect(ad_campaigns_update_model)
        @api.marshal_with(ad_campaigns_response_model)
        @token_required
        async def put(self, id):
            """Update a ad_campaigns given its identifier"""
            try:
                data = api.payload
                validated_data = validate_ad_campaigns_update(data)
                entity = ad_campaigns_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Ad_campaigns not found")
                return ad_campaigns_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating ad_campaigns {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_ad_campaigns')
        @api.response(204, 'Ad_campaigns deleted')
        @token_required
        async def delete(self, id):
            """Delete a ad_campaigns given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Ad_campaigns not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting ad_campaigns {id}: {str(e)}")
                api.abort(400, str(e))

    return api
