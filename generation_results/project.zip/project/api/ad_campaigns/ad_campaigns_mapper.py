from domain.ad_campaigns.ad_campaigns_entity import Ad_campaigns
from api.dtos.ad_campaigns_dto import Ad_campaignsCreate, Ad_campaignsUpdate, Ad_campaignsResponse
from typing import Union

class Ad_campaignsMapper:
    """Mapper for Ad_campaigns between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Ad_campaigns) -> Ad_campaignsResponse:
        """Convert entity to response DTO"""
        return Ad_campaignsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Ad_campaignsCreate, Ad_campaignsUpdate]) -> Ad_campaigns:
        """Convert DTO to entity"""
        return Ad_campaigns(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Ad_campaigns, dto: Ad_campaignsUpdate) -> Ad_campaigns:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

ad_campaigns_mapper = Ad_campaignsMapper()
