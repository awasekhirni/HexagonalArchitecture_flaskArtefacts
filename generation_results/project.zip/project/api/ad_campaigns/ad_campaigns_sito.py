from typing import List, Optional
from domain.ad_campaigns.ad_campaigns_entity import Ad_campaigns
from domain.ad_campaigns.ad_campaigns_service_interface import IAsyncAd_campaignsService
from infrastructure.repositories.ad_campaigns.ad_campaigns_repository import Ad_campaignsRepository
from api.mappers.ad_campaigns_mapper import ad_campaigns_mapper
from shared.utils.logger import logger

class Ad_campaignsService(IAsyncAd_campaignsService):
    """Service implementation for Ad_campaigns"""

    def __init__(self):
        self.repository = Ad_campaignsRepository()

    async def get_by_id(self, id: str) -> Optional[Ad_campaigns]:
        """Get ad_campaigns by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting ad_campaigns by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Ad_campaigns]:
        """Get all ad_campaignss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all ad_campaignss: {str(e)}")
            raise

    async def create(self, data: Ad_campaigns) -> Ad_campaigns:
        """Create new ad_campaigns"""
        try:
            return await self.repository.create(ad_campaigns_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating ad_campaigns: {str(e)}")
            raise

    async def update(self, id: str, data: Ad_campaigns) -> Optional[Ad_campaigns]:
        """Update ad_campaigns"""
        try:
            return await self.repository.update(id, ad_campaigns_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating ad_campaigns: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete ad_campaigns"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting ad_campaigns: {str(e)}")
            raise
