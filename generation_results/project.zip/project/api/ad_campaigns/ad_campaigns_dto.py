from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Ad_campaignsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Ad_campaignsBase(BaseModel):
    """Base schema for ad_campaigns"""
    pass

class Ad_campaignsCreate(Ad_campaignsBase):
    """Schema for creating ad_campaigns"""
    name: str
    description: Optional[str] = None
    status: Ad_campaignsStatus = Ad_campaignsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Ad_campaignsUpdate(Ad_campaignsBase):
    """Schema for updating ad_campaigns"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Ad_campaignsStatus] = None

class Ad_campaignsResponse(Ad_campaignsBase):
    """Response schema for ad_campaigns"""
    id: str
    name: str
    description: Optional[str] = None
    status: Ad_campaignsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_ad_campaigns_create(data: Ad_campaignsCreate) -> Ad_campaignsCreate:
    """Validate ad_campaigns creation data"""
    return data

def validate_ad_campaigns_update(data: Ad_campaignsUpdate) -> Ad_campaignsUpdate:
    """Validate ad_campaigns update data"""
    return data
