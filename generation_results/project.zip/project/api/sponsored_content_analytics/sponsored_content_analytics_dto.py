from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Sponsored_content_analyticsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Sponsored_content_analyticsBase(BaseModel):
    """Base schema for sponsored_content_analytics"""
    pass

class Sponsored_content_analyticsCreate(Sponsored_content_analyticsBase):
    """Schema for creating sponsored_content_analytics"""
    name: str
    description: Optional[str] = None
    status: Sponsored_content_analyticsStatus = Sponsored_content_analyticsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Sponsored_content_analyticsUpdate(Sponsored_content_analyticsBase):
    """Schema for updating sponsored_content_analytics"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Sponsored_content_analyticsStatus] = None

class Sponsored_content_analyticsResponse(Sponsored_content_analyticsBase):
    """Response schema for sponsored_content_analytics"""
    id: str
    name: str
    description: Optional[str] = None
    status: Sponsored_content_analyticsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_sponsored_content_analytics_create(data: Sponsored_content_analyticsCreate) -> Sponsored_content_analyticsCreate:
    """Validate sponsored_content_analytics creation data"""
    return data

def validate_sponsored_content_analytics_update(data: Sponsored_content_analyticsUpdate) -> Sponsored_content_analyticsUpdate:
    """Validate sponsored_content_analytics update data"""
    return data
