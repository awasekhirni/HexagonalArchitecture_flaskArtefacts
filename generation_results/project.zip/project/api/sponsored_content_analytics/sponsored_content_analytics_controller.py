from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.sponsored_content_analytics.sponsored_content_analytics_entity import Sponsored_content_analytics
from domain.sponsored_content_analytics.sponsored_content_analytics_service_interface import IAsyncSponsored_content_analyticsService
from api.dtos.sponsored_content_analytics_dto import Sponsored_content_analyticsCreate, Sponsored_content_analyticsUpdate, Sponsored_content_analyticsResponse
from api.mappers.sponsored_content_analytics_mapper import sponsored_content_analytics_mapper
from api.validations.sponsored_content_analytics_validation_schemas import validate_sponsored_content_analytics_create, validate_sponsored_content_analytics_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('sponsored_content_analytics', description='Sponsored_content_analytics operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
sponsored_content_analytics_create_model = api.model('Sponsored_content_analyticsCreate', {
    'name': fields.String(required=True, description='sponsored_content_analytics name'),
    'description': fields.String(description='sponsored_content_analytics description'),
    'status': fields.String(description='sponsored_content_analytics status', enum=['active', 'inactive', 'pending'])
})

sponsored_content_analytics_update_model = api.model('Sponsored_content_analyticsUpdate', {
    'name': fields.String(description='sponsored_content_analytics name'),
    'description': fields.String(description='sponsored_content_analytics description'),
    'status': fields.String(description='sponsored_content_analytics status', enum=['active', 'inactive', 'pending'])
})

sponsored_content_analytics_response_model = api.model('Sponsored_content_analyticsResponse', {
    'id': fields.String(description='sponsored_content_analytics ID'),
    'name': fields.String(description='sponsored_content_analytics name'),
    'description': fields.String(description='sponsored_content_analytics description'),
    'status': fields.String(description='sponsored_content_analytics status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncSponsored_content_analyticsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Sponsored_content_analyticsList(Resource):
        @api.doc('list_sponsored_content_analyticss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(sponsored_content_analytics_response_model)
        @token_required
        async def get(self):
            """List all sponsored_content_analyticss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [sponsored_content_analytics_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting sponsored_content_analyticss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_sponsored_content_analytics')
        @api.expect(sponsored_content_analytics_create_model)
        @api.marshal_with(sponsored_content_analytics_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new sponsored_content_analytics"""
            try:
                data = api.payload
                validated_data = validate_sponsored_content_analytics_create(data)
                entity = sponsored_content_analytics_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return sponsored_content_analytics_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating sponsored_content_analytics: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The sponsored_content_analytics identifier')
    @api.response(404, 'Sponsored_content_analytics not found')
    class Sponsored_content_analyticsResource(Resource):
        @api.doc('get_sponsored_content_analytics')
        @api.marshal_with(sponsored_content_analytics_response_model)
        @token_required
        async def get(self, id):
            """Get a sponsored_content_analytics given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Sponsored_content_analytics not found")
                return sponsored_content_analytics_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting sponsored_content_analytics {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_sponsored_content_analytics')
        @api.expect(sponsored_content_analytics_update_model)
        @api.marshal_with(sponsored_content_analytics_response_model)
        @token_required
        async def put(self, id):
            """Update a sponsored_content_analytics given its identifier"""
            try:
                data = api.payload
                validated_data = validate_sponsored_content_analytics_update(data)
                entity = sponsored_content_analytics_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Sponsored_content_analytics not found")
                return sponsored_content_analytics_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating sponsored_content_analytics {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_sponsored_content_analytics')
        @api.response(204, 'Sponsored_content_analytics deleted')
        @token_required
        async def delete(self, id):
            """Delete a sponsored_content_analytics given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Sponsored_content_analytics not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting sponsored_content_analytics {id}: {str(e)}")
                api.abort(400, str(e))

    return api
