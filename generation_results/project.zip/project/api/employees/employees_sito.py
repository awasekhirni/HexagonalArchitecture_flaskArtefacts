from typing import List, Optional
from domain.employees.employees_entity import Employees
from domain.employees.employees_service_interface import IAsyncEmployeesService
from infrastructure.repositories.employees.employees_repository import EmployeesRepository
from api.mappers.employees_mapper import employees_mapper
from shared.utils.logger import logger

class EmployeesService(IAsyncEmployeesService):
    """Service implementation for Employees"""

    def __init__(self):
        self.repository = EmployeesRepository()

    async def get_by_id(self, id: str) -> Optional[Employees]:
        """Get employees by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting employees by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Employees]:
        """Get all employeess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all employeess: {str(e)}")
            raise

    async def create(self, data: Employees) -> Employees:
        """Create new employees"""
        try:
            return await self.repository.create(employees_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating employees: {str(e)}")
            raise

    async def update(self, id: str, data: Employees) -> Optional[Employees]:
        """Update employees"""
        try:
            return await self.repository.update(id, employees_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating employees: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete employees"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting employees: {str(e)}")
            raise
