from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class EmployeesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class EmployeesBase(BaseModel):
    """Base schema for employees"""
    pass

class EmployeesCreate(EmployeesBase):
    """Schema for creating employees"""
    name: str
    description: Optional[str] = None
    status: EmployeesStatus = EmployeesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class EmployeesUpdate(EmployeesBase):
    """Schema for updating employees"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[EmployeesStatus] = None

class EmployeesResponse(EmployeesBase):
    """Response schema for employees"""
    id: str
    name: str
    description: Optional[str] = None
    status: EmployeesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_employees_create(data: EmployeesCreate) -> EmployeesCreate:
    """Validate employees creation data"""
    return data

def validate_employees_update(data: EmployeesUpdate) -> EmployeesUpdate:
    """Validate employees update data"""
    return data
