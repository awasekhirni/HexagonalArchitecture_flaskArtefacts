from domain.job_reviews.job_reviews_entity import Job_reviews
from api.dtos.job_reviews_dto import Job_reviewsCreate, Job_reviewsUpdate, Job_reviewsResponse
from typing import Union

class Job_reviewsMapper:
    """Mapper for Job_reviews between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Job_reviews) -> Job_reviewsResponse:
        """Convert entity to response DTO"""
        return Job_reviewsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Job_reviewsCreate, Job_reviewsUpdate]) -> Job_reviews:
        """Convert DTO to entity"""
        return Job_reviews(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Job_reviews, dto: Job_reviewsUpdate) -> Job_reviews:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

job_reviews_mapper = Job_reviewsMapper()
