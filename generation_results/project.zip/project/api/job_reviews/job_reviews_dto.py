from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_reviewsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_reviewsBase(BaseModel):
    """Base schema for job_reviews"""
    pass

class Job_reviewsCreate(Job_reviewsBase):
    """Schema for creating job_reviews"""
    name: str
    description: Optional[str] = None
    status: Job_reviewsStatus = Job_reviewsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_reviewsUpdate(Job_reviewsBase):
    """Schema for updating job_reviews"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_reviewsStatus] = None

class Job_reviewsResponse(Job_reviewsBase):
    """Response schema for job_reviews"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_reviewsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_reviews_create(data: Job_reviewsCreate) -> Job_reviewsCreate:
    """Validate job_reviews creation data"""
    return data

def validate_job_reviews_update(data: Job_reviewsUpdate) -> Job_reviewsUpdate:
    """Validate job_reviews update data"""
    return data
