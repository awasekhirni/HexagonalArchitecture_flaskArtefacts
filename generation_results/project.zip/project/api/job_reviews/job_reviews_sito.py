from typing import List, Optional
from domain.job_reviews.job_reviews_entity import Job_reviews
from domain.job_reviews.job_reviews_service_interface import IAsyncJob_reviewsService
from infrastructure.repositories.job_reviews.job_reviews_repository import Job_reviewsRepository
from api.mappers.job_reviews_mapper import job_reviews_mapper
from shared.utils.logger import logger

class Job_reviewsService(IAsyncJob_reviewsService):
    """Service implementation for Job_reviews"""

    def __init__(self):
        self.repository = Job_reviewsRepository()

    async def get_by_id(self, id: str) -> Optional[Job_reviews]:
        """Get job_reviews by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_reviews by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_reviews]:
        """Get all job_reviewss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_reviewss: {str(e)}")
            raise

    async def create(self, data: Job_reviews) -> Job_reviews:
        """Create new job_reviews"""
        try:
            return await self.repository.create(job_reviews_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_reviews: {str(e)}")
            raise

    async def update(self, id: str, data: Job_reviews) -> Optional[Job_reviews]:
        """Update job_reviews"""
        try:
            return await self.repository.update(id, job_reviews_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_reviews: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_reviews"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_reviews: {str(e)}")
            raise
