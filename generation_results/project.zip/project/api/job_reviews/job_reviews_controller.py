from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.job_reviews.job_reviews_entity import Job_reviews
from domain.job_reviews.job_reviews_service_interface import IAsyncJob_reviewsService
from api.dtos.job_reviews_dto import Job_reviewsCreate, Job_reviewsUpdate, Job_reviewsResponse
from api.mappers.job_reviews_mapper import job_reviews_mapper
from api.validations.job_reviews_validation_schemas import validate_job_reviews_create, validate_job_reviews_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('job_reviews', description='Job_reviews operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
job_reviews_create_model = api.model('Job_reviewsCreate', {
    'name': fields.String(required=True, description='job_reviews name'),
    'description': fields.String(description='job_reviews description'),
    'status': fields.String(description='job_reviews status', enum=['active', 'inactive', 'pending'])
})

job_reviews_update_model = api.model('Job_reviewsUpdate', {
    'name': fields.String(description='job_reviews name'),
    'description': fields.String(description='job_reviews description'),
    'status': fields.String(description='job_reviews status', enum=['active', 'inactive', 'pending'])
})

job_reviews_response_model = api.model('Job_reviewsResponse', {
    'id': fields.String(description='job_reviews ID'),
    'name': fields.String(description='job_reviews name'),
    'description': fields.String(description='job_reviews description'),
    'status': fields.String(description='job_reviews status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncJob_reviewsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Job_reviewsList(Resource):
        @api.doc('list_job_reviewss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(job_reviews_response_model)
        @token_required
        async def get(self):
            """List all job_reviewss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [job_reviews_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting job_reviewss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_job_reviews')
        @api.expect(job_reviews_create_model)
        @api.marshal_with(job_reviews_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new job_reviews"""
            try:
                data = api.payload
                validated_data = validate_job_reviews_create(data)
                entity = job_reviews_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return job_reviews_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating job_reviews: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The job_reviews identifier')
    @api.response(404, 'Job_reviews not found')
    class Job_reviewsResource(Resource):
        @api.doc('get_job_reviews')
        @api.marshal_with(job_reviews_response_model)
        @token_required
        async def get(self, id):
            """Get a job_reviews given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Job_reviews not found")
                return job_reviews_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting job_reviews {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_job_reviews')
        @api.expect(job_reviews_update_model)
        @api.marshal_with(job_reviews_response_model)
        @token_required
        async def put(self, id):
            """Update a job_reviews given its identifier"""
            try:
                data = api.payload
                validated_data = validate_job_reviews_update(data)
                entity = job_reviews_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Job_reviews not found")
                return job_reviews_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating job_reviews {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_job_reviews')
        @api.response(204, 'Job_reviews deleted')
        @token_required
        async def delete(self, id):
            """Delete a job_reviews given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Job_reviews not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting job_reviews {id}: {str(e)}")
                api.abort(400, str(e))

    return api
