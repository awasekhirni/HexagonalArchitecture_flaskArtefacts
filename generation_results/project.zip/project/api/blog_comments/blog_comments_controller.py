from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.blog_comments.blog_comments_entity import Blog_comments
from domain.blog_comments.blog_comments_service_interface import IAsyncBlog_commentsService
from api.dtos.blog_comments_dto import Blog_commentsCreate, Blog_commentsUpdate, Blog_commentsResponse
from api.mappers.blog_comments_mapper import blog_comments_mapper
from api.validations.blog_comments_validation_schemas import validate_blog_comments_create, validate_blog_comments_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('blog_comments', description='Blog_comments operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
blog_comments_create_model = api.model('Blog_commentsCreate', {
    'name': fields.String(required=True, description='blog_comments name'),
    'description': fields.String(description='blog_comments description'),
    'status': fields.String(description='blog_comments status', enum=['active', 'inactive', 'pending'])
})

blog_comments_update_model = api.model('Blog_commentsUpdate', {
    'name': fields.String(description='blog_comments name'),
    'description': fields.String(description='blog_comments description'),
    'status': fields.String(description='blog_comments status', enum=['active', 'inactive', 'pending'])
})

blog_comments_response_model = api.model('Blog_commentsResponse', {
    'id': fields.String(description='blog_comments ID'),
    'name': fields.String(description='blog_comments name'),
    'description': fields.String(description='blog_comments description'),
    'status': fields.String(description='blog_comments status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncBlog_commentsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Blog_commentsList(Resource):
        @api.doc('list_blog_commentss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(blog_comments_response_model)
        @token_required
        async def get(self):
            """List all blog_commentss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [blog_comments_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting blog_commentss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_blog_comments')
        @api.expect(blog_comments_create_model)
        @api.marshal_with(blog_comments_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new blog_comments"""
            try:
                data = api.payload
                validated_data = validate_blog_comments_create(data)
                entity = blog_comments_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return blog_comments_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating blog_comments: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The blog_comments identifier')
    @api.response(404, 'Blog_comments not found')
    class Blog_commentsResource(Resource):
        @api.doc('get_blog_comments')
        @api.marshal_with(blog_comments_response_model)
        @token_required
        async def get(self, id):
            """Get a blog_comments given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Blog_comments not found")
                return blog_comments_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting blog_comments {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_blog_comments')
        @api.expect(blog_comments_update_model)
        @api.marshal_with(blog_comments_response_model)
        @token_required
        async def put(self, id):
            """Update a blog_comments given its identifier"""
            try:
                data = api.payload
                validated_data = validate_blog_comments_update(data)
                entity = blog_comments_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Blog_comments not found")
                return blog_comments_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating blog_comments {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_blog_comments')
        @api.response(204, 'Blog_comments deleted')
        @token_required
        async def delete(self, id):
            """Delete a blog_comments given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Blog_comments not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting blog_comments {id}: {str(e)}")
                api.abort(400, str(e))

    return api
