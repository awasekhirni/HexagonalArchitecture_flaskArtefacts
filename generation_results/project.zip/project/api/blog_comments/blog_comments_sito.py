from typing import List, Optional
from domain.blog_comments.blog_comments_entity import Blog_comments
from domain.blog_comments.blog_comments_service_interface import IAsyncBlog_commentsService
from infrastructure.repositories.blog_comments.blog_comments_repository import Blog_commentsRepository
from api.mappers.blog_comments_mapper import blog_comments_mapper
from shared.utils.logger import logger

class Blog_commentsService(IAsyncBlog_commentsService):
    """Service implementation for Blog_comments"""

    def __init__(self):
        self.repository = Blog_commentsRepository()

    async def get_by_id(self, id: str) -> Optional[Blog_comments]:
        """Get blog_comments by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting blog_comments by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Blog_comments]:
        """Get all blog_commentss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all blog_commentss: {str(e)}")
            raise

    async def create(self, data: Blog_comments) -> Blog_comments:
        """Create new blog_comments"""
        try:
            return await self.repository.create(blog_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating blog_comments: {str(e)}")
            raise

    async def update(self, id: str, data: Blog_comments) -> Optional[Blog_comments]:
        """Update blog_comments"""
        try:
            return await self.repository.update(id, blog_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating blog_comments: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete blog_comments"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting blog_comments: {str(e)}")
            raise
