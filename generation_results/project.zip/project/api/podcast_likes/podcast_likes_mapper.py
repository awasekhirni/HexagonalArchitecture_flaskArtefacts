from domain.podcast_likes.podcast_likes_entity import Podcast_likes
from api.dtos.podcast_likes_dto import Podcast_likesCreate, Podcast_likesUpdate, Podcast_likesResponse
from typing import Union

class Podcast_likesMapper:
    """Mapper for Podcast_likes between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Podcast_likes) -> Podcast_likesResponse:
        """Convert entity to response DTO"""
        return Podcast_likesResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Podcast_likesCreate, Podcast_likesUpdate]) -> Podcast_likes:
        """Convert DTO to entity"""
        return Podcast_likes(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Podcast_likes, dto: Podcast_likesUpdate) -> Podcast_likes:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

podcast_likes_mapper = Podcast_likesMapper()
