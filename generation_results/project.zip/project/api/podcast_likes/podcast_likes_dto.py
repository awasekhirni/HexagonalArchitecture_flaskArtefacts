from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Podcast_likesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Podcast_likesBase(BaseModel):
    """Base schema for podcast_likes"""
    pass

class Podcast_likesCreate(Podcast_likesBase):
    """Schema for creating podcast_likes"""
    name: str
    description: Optional[str] = None
    status: Podcast_likesStatus = Podcast_likesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Podcast_likesUpdate(Podcast_likesBase):
    """Schema for updating podcast_likes"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Podcast_likesStatus] = None

class Podcast_likesResponse(Podcast_likesBase):
    """Response schema for podcast_likes"""
    id: str
    name: str
    description: Optional[str] = None
    status: Podcast_likesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_podcast_likes_create(data: Podcast_likesCreate) -> Podcast_likesCreate:
    """Validate podcast_likes creation data"""
    return data

def validate_podcast_likes_update(data: Podcast_likesUpdate) -> Podcast_likesUpdate:
    """Validate podcast_likes update data"""
    return data
