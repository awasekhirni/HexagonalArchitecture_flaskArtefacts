from typing import List, Optional
from domain.podcast_likes.podcast_likes_entity import Podcast_likes
from domain.podcast_likes.podcast_likes_service_interface import IAsyncPodcast_likesService
from infrastructure.repositories.podcast_likes.podcast_likes_repository import Podcast_likesRepository
from api.mappers.podcast_likes_mapper import podcast_likes_mapper
from shared.utils.logger import logger

class Podcast_likesService(IAsyncPodcast_likesService):
    """Service implementation for Podcast_likes"""

    def __init__(self):
        self.repository = Podcast_likesRepository()

    async def get_by_id(self, id: str) -> Optional[Podcast_likes]:
        """Get podcast_likes by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting podcast_likes by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Podcast_likes]:
        """Get all podcast_likess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all podcast_likess: {str(e)}")
            raise

    async def create(self, data: Podcast_likes) -> Podcast_likes:
        """Create new podcast_likes"""
        try:
            return await self.repository.create(podcast_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating podcast_likes: {str(e)}")
            raise

    async def update(self, id: str, data: Podcast_likes) -> Optional[Podcast_likes]:
        """Update podcast_likes"""
        try:
            return await self.repository.update(id, podcast_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating podcast_likes: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete podcast_likes"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting podcast_likes: {str(e)}")
            raise
