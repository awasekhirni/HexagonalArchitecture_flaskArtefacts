from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_tagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_tagsBase(BaseModel):
    """Base schema for job_tags"""
    pass

class Job_tagsCreate(Job_tagsBase):
    """Schema for creating job_tags"""
    name: str
    description: Optional[str] = None
    status: Job_tagsStatus = Job_tagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_tagsUpdate(Job_tagsBase):
    """Schema for updating job_tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_tagsStatus] = None

class Job_tagsResponse(Job_tagsBase):
    """Response schema for job_tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_tagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_tags_create(data: Job_tagsCreate) -> Job_tagsCreate:
    """Validate job_tags creation data"""
    return data

def validate_job_tags_update(data: Job_tagsUpdate) -> Job_tagsUpdate:
    """Validate job_tags update data"""
    return data
