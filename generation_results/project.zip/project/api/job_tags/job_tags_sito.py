from typing import List, Optional
from domain.job_tags.job_tags_entity import Job_tags
from domain.job_tags.job_tags_service_interface import IAsyncJob_tagsService
from infrastructure.repositories.job_tags.job_tags_repository import Job_tagsRepository
from api.mappers.job_tags_mapper import job_tags_mapper
from shared.utils.logger import logger

class Job_tagsService(IAsyncJob_tagsService):
    """Service implementation for Job_tags"""

    def __init__(self):
        self.repository = Job_tagsRepository()

    async def get_by_id(self, id: str) -> Optional[Job_tags]:
        """Get job_tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_tags]:
        """Get all job_tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_tagss: {str(e)}")
            raise

    async def create(self, data: Job_tags) -> Job_tags:
        """Create new job_tags"""
        try:
            return await self.repository.create(job_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_tags: {str(e)}")
            raise

    async def update(self, id: str, data: Job_tags) -> Optional[Job_tags]:
        """Update job_tags"""
        try:
            return await self.repository.update(id, job_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_tags: {str(e)}")
            raise
