from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Employee_documentsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Employee_documentsBase(BaseModel):
    """Base schema for employee_documents"""
    pass

class Employee_documentsCreate(Employee_documentsBase):
    """Schema for creating employee_documents"""
    name: str
    description: Optional[str] = None
    status: Employee_documentsStatus = Employee_documentsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Employee_documentsUpdate(Employee_documentsBase):
    """Schema for updating employee_documents"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Employee_documentsStatus] = None

class Employee_documentsResponse(Employee_documentsBase):
    """Response schema for employee_documents"""
    id: str
    name: str
    description: Optional[str] = None
    status: Employee_documentsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_employee_documents_create(data: Employee_documentsCreate) -> Employee_documentsCreate:
    """Validate employee_documents creation data"""
    return data

def validate_employee_documents_update(data: Employee_documentsUpdate) -> Employee_documentsUpdate:
    """Validate employee_documents update data"""
    return data
