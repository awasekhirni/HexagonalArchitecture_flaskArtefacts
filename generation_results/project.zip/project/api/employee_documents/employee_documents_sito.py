from typing import List, Optional
from domain.employee_documents.employee_documents_entity import Employee_documents
from domain.employee_documents.employee_documents_service_interface import IAsyncEmployee_documentsService
from infrastructure.repositories.employee_documents.employee_documents_repository import Employee_documentsRepository
from api.mappers.employee_documents_mapper import employee_documents_mapper
from shared.utils.logger import logger

class Employee_documentsService(IAsyncEmployee_documentsService):
    """Service implementation for Employee_documents"""

    def __init__(self):
        self.repository = Employee_documentsRepository()

    async def get_by_id(self, id: str) -> Optional[Employee_documents]:
        """Get employee_documents by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting employee_documents by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Employee_documents]:
        """Get all employee_documentss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all employee_documentss: {str(e)}")
            raise

    async def create(self, data: Employee_documents) -> Employee_documents:
        """Create new employee_documents"""
        try:
            return await self.repository.create(employee_documents_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating employee_documents: {str(e)}")
            raise

    async def update(self, id: str, data: Employee_documents) -> Optional[Employee_documents]:
        """Update employee_documents"""
        try:
            return await self.repository.update(id, employee_documents_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating employee_documents: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete employee_documents"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting employee_documents: {str(e)}")
            raise
