from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.employee_documents.employee_documents_entity import Employee_documents
from domain.employee_documents.employee_documents_service_interface import IAsyncEmployee_documentsService
from api.dtos.employee_documents_dto import Employee_documentsCreate, Employee_documentsUpdate, Employee_documentsResponse
from api.mappers.employee_documents_mapper import employee_documents_mapper
from api.validations.employee_documents_validation_schemas import validate_employee_documents_create, validate_employee_documents_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('employee_documents', description='Employee_documents operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
employee_documents_create_model = api.model('Employee_documentsCreate', {
    'name': fields.String(required=True, description='employee_documents name'),
    'description': fields.String(description='employee_documents description'),
    'status': fields.String(description='employee_documents status', enum=['active', 'inactive', 'pending'])
})

employee_documents_update_model = api.model('Employee_documentsUpdate', {
    'name': fields.String(description='employee_documents name'),
    'description': fields.String(description='employee_documents description'),
    'status': fields.String(description='employee_documents status', enum=['active', 'inactive', 'pending'])
})

employee_documents_response_model = api.model('Employee_documentsResponse', {
    'id': fields.String(description='employee_documents ID'),
    'name': fields.String(description='employee_documents name'),
    'description': fields.String(description='employee_documents description'),
    'status': fields.String(description='employee_documents status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncEmployee_documentsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Employee_documentsList(Resource):
        @api.doc('list_employee_documentss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(employee_documents_response_model)
        @token_required
        async def get(self):
            """List all employee_documentss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [employee_documents_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting employee_documentss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_employee_documents')
        @api.expect(employee_documents_create_model)
        @api.marshal_with(employee_documents_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new employee_documents"""
            try:
                data = api.payload
                validated_data = validate_employee_documents_create(data)
                entity = employee_documents_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return employee_documents_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating employee_documents: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The employee_documents identifier')
    @api.response(404, 'Employee_documents not found')
    class Employee_documentsResource(Resource):
        @api.doc('get_employee_documents')
        @api.marshal_with(employee_documents_response_model)
        @token_required
        async def get(self, id):
            """Get a employee_documents given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Employee_documents not found")
                return employee_documents_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting employee_documents {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_employee_documents')
        @api.expect(employee_documents_update_model)
        @api.marshal_with(employee_documents_response_model)
        @token_required
        async def put(self, id):
            """Update a employee_documents given its identifier"""
            try:
                data = api.payload
                validated_data = validate_employee_documents_update(data)
                entity = employee_documents_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Employee_documents not found")
                return employee_documents_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating employee_documents {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_employee_documents')
        @api.response(204, 'Employee_documents deleted')
        @token_required
        async def delete(self, id):
            """Delete a employee_documents given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Employee_documents not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting employee_documents {id}: {str(e)}")
                api.abort(400, str(e))

    return api
