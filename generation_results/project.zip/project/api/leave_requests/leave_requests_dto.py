from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Leave_requestsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Leave_requestsBase(BaseModel):
    """Base schema for leave_requests"""
    pass

class Leave_requestsCreate(Leave_requestsBase):
    """Schema for creating leave_requests"""
    name: str
    description: Optional[str] = None
    status: Leave_requestsStatus = Leave_requestsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Leave_requestsUpdate(Leave_requestsBase):
    """Schema for updating leave_requests"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Leave_requestsStatus] = None

class Leave_requestsResponse(Leave_requestsBase):
    """Response schema for leave_requests"""
    id: str
    name: str
    description: Optional[str] = None
    status: Leave_requestsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_leave_requests_create(data: Leave_requestsCreate) -> Leave_requestsCreate:
    """Validate leave_requests creation data"""
    return data

def validate_leave_requests_update(data: Leave_requestsUpdate) -> Leave_requestsUpdate:
    """Validate leave_requests update data"""
    return data
