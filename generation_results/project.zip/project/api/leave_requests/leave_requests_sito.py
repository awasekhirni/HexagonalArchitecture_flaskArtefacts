from typing import List, Optional
from domain.leave_requests.leave_requests_entity import Leave_requests
from domain.leave_requests.leave_requests_service_interface import IAsyncLeave_requestsService
from infrastructure.repositories.leave_requests.leave_requests_repository import Leave_requestsRepository
from api.mappers.leave_requests_mapper import leave_requests_mapper
from shared.utils.logger import logger

class Leave_requestsService(IAsyncLeave_requestsService):
    """Service implementation for Leave_requests"""

    def __init__(self):
        self.repository = Leave_requestsRepository()

    async def get_by_id(self, id: str) -> Optional[Leave_requests]:
        """Get leave_requests by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting leave_requests by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Leave_requests]:
        """Get all leave_requestss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all leave_requestss: {str(e)}")
            raise

    async def create(self, data: Leave_requests) -> Leave_requests:
        """Create new leave_requests"""
        try:
            return await self.repository.create(leave_requests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating leave_requests: {str(e)}")
            raise

    async def update(self, id: str, data: Leave_requests) -> Optional[Leave_requests]:
        """Update leave_requests"""
        try:
            return await self.repository.update(id, leave_requests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating leave_requests: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete leave_requests"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting leave_requests: {str(e)}")
            raise
