from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.leave_requests.leave_requests_entity import Leave_requests
from domain.leave_requests.leave_requests_service_interface import IAsyncLeave_requestsService
from api.dtos.leave_requests_dto import Leave_requestsCreate, Leave_requestsUpdate, Leave_requestsResponse
from api.mappers.leave_requests_mapper import leave_requests_mapper
from api.validations.leave_requests_validation_schemas import validate_leave_requests_create, validate_leave_requests_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('leave_requests', description='Leave_requests operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
leave_requests_create_model = api.model('Leave_requestsCreate', {
    'name': fields.String(required=True, description='leave_requests name'),
    'description': fields.String(description='leave_requests description'),
    'status': fields.String(description='leave_requests status', enum=['active', 'inactive', 'pending'])
})

leave_requests_update_model = api.model('Leave_requestsUpdate', {
    'name': fields.String(description='leave_requests name'),
    'description': fields.String(description='leave_requests description'),
    'status': fields.String(description='leave_requests status', enum=['active', 'inactive', 'pending'])
})

leave_requests_response_model = api.model('Leave_requestsResponse', {
    'id': fields.String(description='leave_requests ID'),
    'name': fields.String(description='leave_requests name'),
    'description': fields.String(description='leave_requests description'),
    'status': fields.String(description='leave_requests status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncLeave_requestsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Leave_requestsList(Resource):
        @api.doc('list_leave_requestss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(leave_requests_response_model)
        @token_required
        async def get(self):
            """List all leave_requestss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [leave_requests_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting leave_requestss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_leave_requests')
        @api.expect(leave_requests_create_model)
        @api.marshal_with(leave_requests_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new leave_requests"""
            try:
                data = api.payload
                validated_data = validate_leave_requests_create(data)
                entity = leave_requests_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return leave_requests_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating leave_requests: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The leave_requests identifier')
    @api.response(404, 'Leave_requests not found')
    class Leave_requestsResource(Resource):
        @api.doc('get_leave_requests')
        @api.marshal_with(leave_requests_response_model)
        @token_required
        async def get(self, id):
            """Get a leave_requests given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Leave_requests not found")
                return leave_requests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting leave_requests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_leave_requests')
        @api.expect(leave_requests_update_model)
        @api.marshal_with(leave_requests_response_model)
        @token_required
        async def put(self, id):
            """Update a leave_requests given its identifier"""
            try:
                data = api.payload
                validated_data = validate_leave_requests_update(data)
                entity = leave_requests_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Leave_requests not found")
                return leave_requests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating leave_requests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_leave_requests')
        @api.response(204, 'Leave_requests deleted')
        @token_required
        async def delete(self, id):
            """Delete a leave_requests given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Leave_requests not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting leave_requests {id}: {str(e)}")
                api.abort(400, str(e))

    return api
