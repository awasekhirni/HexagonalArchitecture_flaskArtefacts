from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_skillsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_skillsBase(BaseModel):
    """Base schema for user_skills"""
    pass

class User_skillsCreate(User_skillsBase):
    """Schema for creating user_skills"""
    name: str
    description: Optional[str] = None
    status: User_skillsStatus = User_skillsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_skillsUpdate(User_skillsBase):
    """Schema for updating user_skills"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_skillsStatus] = None

class User_skillsResponse(User_skillsBase):
    """Response schema for user_skills"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_skillsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_skills_create(data: User_skillsCreate) -> User_skillsCreate:
    """Validate user_skills creation data"""
    return data

def validate_user_skills_update(data: User_skillsUpdate) -> User_skillsUpdate:
    """Validate user_skills update data"""
    return data
