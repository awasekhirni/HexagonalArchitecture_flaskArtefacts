from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_skills.user_skills_entity import User_skills
from domain.user_skills.user_skills_service_interface import IAsyncUser_skillsService
from api.dtos.user_skills_dto import User_skillsCreate, User_skillsUpdate, User_skillsResponse
from api.mappers.user_skills_mapper import user_skills_mapper
from api.validations.user_skills_validation_schemas import validate_user_skills_create, validate_user_skills_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_skills', description='User_skills operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_skills_create_model = api.model('User_skillsCreate', {
    'name': fields.String(required=True, description='user_skills name'),
    'description': fields.String(description='user_skills description'),
    'status': fields.String(description='user_skills status', enum=['active', 'inactive', 'pending'])
})

user_skills_update_model = api.model('User_skillsUpdate', {
    'name': fields.String(description='user_skills name'),
    'description': fields.String(description='user_skills description'),
    'status': fields.String(description='user_skills status', enum=['active', 'inactive', 'pending'])
})

user_skills_response_model = api.model('User_skillsResponse', {
    'id': fields.String(description='user_skills ID'),
    'name': fields.String(description='user_skills name'),
    'description': fields.String(description='user_skills description'),
    'status': fields.String(description='user_skills status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_skillsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_skillsList(Resource):
        @api.doc('list_user_skillss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_skills_response_model)
        @token_required
        async def get(self):
            """List all user_skillss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_skills_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_skillss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_skills')
        @api.expect(user_skills_create_model)
        @api.marshal_with(user_skills_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_skills"""
            try:
                data = api.payload
                validated_data = validate_user_skills_create(data)
                entity = user_skills_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_skills_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_skills: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_skills identifier')
    @api.response(404, 'User_skills not found')
    class User_skillsResource(Resource):
        @api.doc('get_user_skills')
        @api.marshal_with(user_skills_response_model)
        @token_required
        async def get(self, id):
            """Get a user_skills given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_skills not found")
                return user_skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_skills')
        @api.expect(user_skills_update_model)
        @api.marshal_with(user_skills_response_model)
        @token_required
        async def put(self, id):
            """Update a user_skills given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_skills_update(data)
                entity = user_skills_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_skills not found")
                return user_skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_skills')
        @api.response(204, 'User_skills deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_skills given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_skills not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_skills {id}: {str(e)}")
                api.abort(400, str(e))

    return api
