from typing import List, Optional
from domain.influencer_article_comments.influencer_article_comments_entity import Influencer_article_comments
from domain.influencer_article_comments.influencer_article_comments_service_interface import IAsyncInfluencer_article_commentsService
from infrastructure.repositories.influencer_article_comments.influencer_article_comments_repository import Influencer_article_commentsRepository
from api.mappers.influencer_article_comments_mapper import influencer_article_comments_mapper
from shared.utils.logger import logger

class Influencer_article_commentsService(IAsyncInfluencer_article_commentsService):
    """Service implementation for Influencer_article_comments"""

    def __init__(self):
        self.repository = Influencer_article_commentsRepository()

    async def get_by_id(self, id: str) -> Optional[Influencer_article_comments]:
        """Get influencer_article_comments by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting influencer_article_comments by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Influencer_article_comments]:
        """Get all influencer_article_commentss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all influencer_article_commentss: {str(e)}")
            raise

    async def create(self, data: Influencer_article_comments) -> Influencer_article_comments:
        """Create new influencer_article_comments"""
        try:
            return await self.repository.create(influencer_article_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating influencer_article_comments: {str(e)}")
            raise

    async def update(self, id: str, data: Influencer_article_comments) -> Optional[Influencer_article_comments]:
        """Update influencer_article_comments"""
        try:
            return await self.repository.update(id, influencer_article_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating influencer_article_comments: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete influencer_article_comments"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting influencer_article_comments: {str(e)}")
            raise
