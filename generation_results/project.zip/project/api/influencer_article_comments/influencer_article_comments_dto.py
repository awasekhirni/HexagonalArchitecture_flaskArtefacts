from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Influencer_article_commentsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Influencer_article_commentsBase(BaseModel):
    """Base schema for influencer_article_comments"""
    pass

class Influencer_article_commentsCreate(Influencer_article_commentsBase):
    """Schema for creating influencer_article_comments"""
    name: str
    description: Optional[str] = None
    status: Influencer_article_commentsStatus = Influencer_article_commentsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Influencer_article_commentsUpdate(Influencer_article_commentsBase):
    """Schema for updating influencer_article_comments"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Influencer_article_commentsStatus] = None

class Influencer_article_commentsResponse(Influencer_article_commentsBase):
    """Response schema for influencer_article_comments"""
    id: str
    name: str
    description: Optional[str] = None
    status: Influencer_article_commentsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_influencer_article_comments_create(data: Influencer_article_commentsCreate) -> Influencer_article_commentsCreate:
    """Validate influencer_article_comments creation data"""
    return data

def validate_influencer_article_comments_update(data: Influencer_article_commentsUpdate) -> Influencer_article_commentsUpdate:
    """Validate influencer_article_comments update data"""
    return data
