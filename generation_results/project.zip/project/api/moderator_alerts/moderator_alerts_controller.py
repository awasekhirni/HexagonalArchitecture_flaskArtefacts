from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.moderator_alerts.moderator_alerts_entity import Moderator_alerts
from domain.moderator_alerts.moderator_alerts_service_interface import IAsyncModerator_alertsService
from api.dtos.moderator_alerts_dto import Moderator_alertsCreate, Moderator_alertsUpdate, Moderator_alertsResponse
from api.mappers.moderator_alerts_mapper import moderator_alerts_mapper
from api.validations.moderator_alerts_validation_schemas import validate_moderator_alerts_create, validate_moderator_alerts_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('moderator_alerts', description='Moderator_alerts operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
moderator_alerts_create_model = api.model('Moderator_alertsCreate', {
    'name': fields.String(required=True, description='moderator_alerts name'),
    'description': fields.String(description='moderator_alerts description'),
    'status': fields.String(description='moderator_alerts status', enum=['active', 'inactive', 'pending'])
})

moderator_alerts_update_model = api.model('Moderator_alertsUpdate', {
    'name': fields.String(description='moderator_alerts name'),
    'description': fields.String(description='moderator_alerts description'),
    'status': fields.String(description='moderator_alerts status', enum=['active', 'inactive', 'pending'])
})

moderator_alerts_response_model = api.model('Moderator_alertsResponse', {
    'id': fields.String(description='moderator_alerts ID'),
    'name': fields.String(description='moderator_alerts name'),
    'description': fields.String(description='moderator_alerts description'),
    'status': fields.String(description='moderator_alerts status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncModerator_alertsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Moderator_alertsList(Resource):
        @api.doc('list_moderator_alertss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(moderator_alerts_response_model)
        @token_required
        async def get(self):
            """List all moderator_alertss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [moderator_alerts_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting moderator_alertss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_moderator_alerts')
        @api.expect(moderator_alerts_create_model)
        @api.marshal_with(moderator_alerts_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new moderator_alerts"""
            try:
                data = api.payload
                validated_data = validate_moderator_alerts_create(data)
                entity = moderator_alerts_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return moderator_alerts_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating moderator_alerts: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The moderator_alerts identifier')
    @api.response(404, 'Moderator_alerts not found')
    class Moderator_alertsResource(Resource):
        @api.doc('get_moderator_alerts')
        @api.marshal_with(moderator_alerts_response_model)
        @token_required
        async def get(self, id):
            """Get a moderator_alerts given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Moderator_alerts not found")
                return moderator_alerts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting moderator_alerts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_moderator_alerts')
        @api.expect(moderator_alerts_update_model)
        @api.marshal_with(moderator_alerts_response_model)
        @token_required
        async def put(self, id):
            """Update a moderator_alerts given its identifier"""
            try:
                data = api.payload
                validated_data = validate_moderator_alerts_update(data)
                entity = moderator_alerts_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Moderator_alerts not found")
                return moderator_alerts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating moderator_alerts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_moderator_alerts')
        @api.response(204, 'Moderator_alerts deleted')
        @token_required
        async def delete(self, id):
            """Delete a moderator_alerts given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Moderator_alerts not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting moderator_alerts {id}: {str(e)}")
                api.abort(400, str(e))

    return api
