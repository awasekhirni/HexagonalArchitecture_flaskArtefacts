from domain.moderator_alerts.moderator_alerts_entity import Moderator_alerts
from api.dtos.moderator_alerts_dto import Moderator_alertsCreate, Moderator_alertsUpdate, Moderator_alertsResponse
from typing import Union

class Moderator_alertsMapper:
    """Mapper for Moderator_alerts between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Moderator_alerts) -> Moderator_alertsResponse:
        """Convert entity to response DTO"""
        return Moderator_alertsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Moderator_alertsCreate, Moderator_alertsUpdate]) -> Moderator_alerts:
        """Convert DTO to entity"""
        return Moderator_alerts(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Moderator_alerts, dto: Moderator_alertsUpdate) -> Moderator_alerts:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

moderator_alerts_mapper = Moderator_alertsMapper()
