from typing import List, Optional
from domain.moderator_alerts.moderator_alerts_entity import Moderator_alerts
from domain.moderator_alerts.moderator_alerts_service_interface import IAsyncModerator_alertsService
from infrastructure.repositories.moderator_alerts.moderator_alerts_repository import Moderator_alertsRepository
from api.mappers.moderator_alerts_mapper import moderator_alerts_mapper
from shared.utils.logger import logger

class Moderator_alertsService(IAsyncModerator_alertsService):
    """Service implementation for Moderator_alerts"""

    def __init__(self):
        self.repository = Moderator_alertsRepository()

    async def get_by_id(self, id: str) -> Optional[Moderator_alerts]:
        """Get moderator_alerts by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting moderator_alerts by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Moderator_alerts]:
        """Get all moderator_alertss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all moderator_alertss: {str(e)}")
            raise

    async def create(self, data: Moderator_alerts) -> Moderator_alerts:
        """Create new moderator_alerts"""
        try:
            return await self.repository.create(moderator_alerts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating moderator_alerts: {str(e)}")
            raise

    async def update(self, id: str, data: Moderator_alerts) -> Optional[Moderator_alerts]:
        """Update moderator_alerts"""
        try:
            return await self.repository.update(id, moderator_alerts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating moderator_alerts: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete moderator_alerts"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting moderator_alerts: {str(e)}")
            raise
