from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Moderator_alertsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Moderator_alertsBase(BaseModel):
    """Base schema for moderator_alerts"""
    pass

class Moderator_alertsCreate(Moderator_alertsBase):
    """Schema for creating moderator_alerts"""
    name: str
    description: Optional[str] = None
    status: Moderator_alertsStatus = Moderator_alertsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Moderator_alertsUpdate(Moderator_alertsBase):
    """Schema for updating moderator_alerts"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Moderator_alertsStatus] = None

class Moderator_alertsResponse(Moderator_alertsBase):
    """Response schema for moderator_alerts"""
    id: str
    name: str
    description: Optional[str] = None
    status: Moderator_alertsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_moderator_alerts_create(data: Moderator_alertsCreate) -> Moderator_alertsCreate:
    """Validate moderator_alerts creation data"""
    return data

def validate_moderator_alerts_update(data: Moderator_alertsUpdate) -> Moderator_alertsUpdate:
    """Validate moderator_alerts update data"""
    return data
