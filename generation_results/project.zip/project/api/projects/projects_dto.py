from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class ProjectsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class ProjectsBase(BaseModel):
    """Base schema for projects"""
    pass

class ProjectsCreate(ProjectsBase):
    """Schema for creating projects"""
    name: str
    description: Optional[str] = None
    status: ProjectsStatus = ProjectsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class ProjectsUpdate(ProjectsBase):
    """Schema for updating projects"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectsStatus] = None

class ProjectsResponse(ProjectsBase):
    """Response schema for projects"""
    id: str
    name: str
    description: Optional[str] = None
    status: ProjectsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_projects_create(data: ProjectsCreate) -> ProjectsCreate:
    """Validate projects creation data"""
    return data

def validate_projects_update(data: ProjectsUpdate) -> ProjectsUpdate:
    """Validate projects update data"""
    return data
