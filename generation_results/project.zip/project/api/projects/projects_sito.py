from typing import List, Optional
from domain.projects.projects_entity import Projects
from domain.projects.projects_service_interface import IAsyncProjectsService
from infrastructure.repositories.projects.projects_repository import ProjectsRepository
from api.mappers.projects_mapper import projects_mapper
from shared.utils.logger import logger

class ProjectsService(IAsyncProjectsService):
    """Service implementation for Projects"""

    def __init__(self):
        self.repository = ProjectsRepository()

    async def get_by_id(self, id: str) -> Optional[Projects]:
        """Get projects by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting projects by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Projects]:
        """Get all projectss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all projectss: {str(e)}")
            raise

    async def create(self, data: Projects) -> Projects:
        """Create new projects"""
        try:
            return await self.repository.create(projects_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating projects: {str(e)}")
            raise

    async def update(self, id: str, data: Projects) -> Optional[Projects]:
        """Update projects"""
        try:
            return await self.repository.update(id, projects_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating projects: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete projects"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting projects: {str(e)}")
            raise
