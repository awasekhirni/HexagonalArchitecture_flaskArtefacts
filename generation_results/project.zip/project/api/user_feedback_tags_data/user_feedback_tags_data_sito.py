from typing import List, Optional
from domain.user_feedback_tags_data.user_feedback_tags_data_entity import User_feedback_tags_data
from domain.user_feedback_tags_data.user_feedback_tags_data_service_interface import IAsyncUser_feedback_tags_dataService
from infrastructure.repositories.user_feedback_tags_data.user_feedback_tags_data_repository import User_feedback_tags_dataRepository
from api.mappers.user_feedback_tags_data_mapper import user_feedback_tags_data_mapper
from shared.utils.logger import logger

class User_feedback_tags_dataService(IAsyncUser_feedback_tags_dataService):
    """Service implementation for User_feedback_tags_data"""

    def __init__(self):
        self.repository = User_feedback_tags_dataRepository()

    async def get_by_id(self, id: str) -> Optional[User_feedback_tags_data]:
        """Get user_feedback_tags_data by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_feedback_tags_data by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_feedback_tags_data]:
        """Get all user_feedback_tags_datas"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_feedback_tags_datas: {str(e)}")
            raise

    async def create(self, data: User_feedback_tags_data) -> User_feedback_tags_data:
        """Create new user_feedback_tags_data"""
        try:
            return await self.repository.create(user_feedback_tags_data_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_feedback_tags_data: {str(e)}")
            raise

    async def update(self, id: str, data: User_feedback_tags_data) -> Optional[User_feedback_tags_data]:
        """Update user_feedback_tags_data"""
        try:
            return await self.repository.update(id, user_feedback_tags_data_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_feedback_tags_data: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_feedback_tags_data"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_feedback_tags_data: {str(e)}")
            raise
