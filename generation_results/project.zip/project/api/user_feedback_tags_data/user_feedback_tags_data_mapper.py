from domain.user_feedback_tags_data.user_feedback_tags_data_entity import User_feedback_tags_data
from api.dtos.user_feedback_tags_data_dto import User_feedback_tags_dataCreate, User_feedback_tags_dataUpdate, User_feedback_tags_dataResponse
from typing import Union

class User_feedback_tags_dataMapper:
    """Mapper for User_feedback_tags_data between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_feedback_tags_data) -> User_feedback_tags_dataResponse:
        """Convert entity to response DTO"""
        return User_feedback_tags_dataResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_feedback_tags_dataCreate, User_feedback_tags_dataUpdate]) -> User_feedback_tags_data:
        """Convert DTO to entity"""
        return User_feedback_tags_data(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_feedback_tags_data, dto: User_feedback_tags_dataUpdate) -> User_feedback_tags_data:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_feedback_tags_data_mapper = User_feedback_tags_dataMapper()
