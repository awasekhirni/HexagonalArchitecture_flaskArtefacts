from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_feedback_tags_data.user_feedback_tags_data_entity import User_feedback_tags_data
from domain.user_feedback_tags_data.user_feedback_tags_data_service_interface import IAsyncUser_feedback_tags_dataService
from api.dtos.user_feedback_tags_data_dto import User_feedback_tags_dataCreate, User_feedback_tags_dataUpdate, User_feedback_tags_dataResponse
from api.mappers.user_feedback_tags_data_mapper import user_feedback_tags_data_mapper
from api.validations.user_feedback_tags_data_validation_schemas import validate_user_feedback_tags_data_create, validate_user_feedback_tags_data_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_feedback_tags_data', description='User_feedback_tags_data operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_feedback_tags_data_create_model = api.model('User_feedback_tags_dataCreate', {
    'name': fields.String(required=True, description='user_feedback_tags_data name'),
    'description': fields.String(description='user_feedback_tags_data description'),
    'status': fields.String(description='user_feedback_tags_data status', enum=['active', 'inactive', 'pending'])
})

user_feedback_tags_data_update_model = api.model('User_feedback_tags_dataUpdate', {
    'name': fields.String(description='user_feedback_tags_data name'),
    'description': fields.String(description='user_feedback_tags_data description'),
    'status': fields.String(description='user_feedback_tags_data status', enum=['active', 'inactive', 'pending'])
})

user_feedback_tags_data_response_model = api.model('User_feedback_tags_dataResponse', {
    'id': fields.String(description='user_feedback_tags_data ID'),
    'name': fields.String(description='user_feedback_tags_data name'),
    'description': fields.String(description='user_feedback_tags_data description'),
    'status': fields.String(description='user_feedback_tags_data status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_feedback_tags_dataService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_feedback_tags_dataList(Resource):
        @api.doc('list_user_feedback_tags_datas')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_feedback_tags_data_response_model)
        @token_required
        async def get(self):
            """List all user_feedback_tags_datas"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_feedback_tags_data_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_feedback_tags_datas: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_feedback_tags_data')
        @api.expect(user_feedback_tags_data_create_model)
        @api.marshal_with(user_feedback_tags_data_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_feedback_tags_data"""
            try:
                data = api.payload
                validated_data = validate_user_feedback_tags_data_create(data)
                entity = user_feedback_tags_data_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_feedback_tags_data_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_feedback_tags_data: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_feedback_tags_data identifier')
    @api.response(404, 'User_feedback_tags_data not found')
    class User_feedback_tags_dataResource(Resource):
        @api.doc('get_user_feedback_tags_data')
        @api.marshal_with(user_feedback_tags_data_response_model)
        @token_required
        async def get(self, id):
            """Get a user_feedback_tags_data given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_feedback_tags_data not found")
                return user_feedback_tags_data_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_feedback_tags_data {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_feedback_tags_data')
        @api.expect(user_feedback_tags_data_update_model)
        @api.marshal_with(user_feedback_tags_data_response_model)
        @token_required
        async def put(self, id):
            """Update a user_feedback_tags_data given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_feedback_tags_data_update(data)
                entity = user_feedback_tags_data_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_feedback_tags_data not found")
                return user_feedback_tags_data_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_feedback_tags_data {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_feedback_tags_data')
        @api.response(204, 'User_feedback_tags_data deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_feedback_tags_data given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_feedback_tags_data not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_feedback_tags_data {id}: {str(e)}")
                api.abort(400, str(e))

    return api
