from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_feedback_tags_dataStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_feedback_tags_dataBase(BaseModel):
    """Base schema for user_feedback_tags_data"""
    pass

class User_feedback_tags_dataCreate(User_feedback_tags_dataBase):
    """Schema for creating user_feedback_tags_data"""
    name: str
    description: Optional[str] = None
    status: User_feedback_tags_dataStatus = User_feedback_tags_dataStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_feedback_tags_dataUpdate(User_feedback_tags_dataBase):
    """Schema for updating user_feedback_tags_data"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_feedback_tags_dataStatus] = None

class User_feedback_tags_dataResponse(User_feedback_tags_dataBase):
    """Response schema for user_feedback_tags_data"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_feedback_tags_dataStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_feedback_tags_data_create(data: User_feedback_tags_dataCreate) -> User_feedback_tags_dataCreate:
    """Validate user_feedback_tags_data creation data"""
    return data

def validate_user_feedback_tags_data_update(data: User_feedback_tags_dataUpdate) -> User_feedback_tags_dataUpdate:
    """Validate user_feedback_tags_data update data"""
    return data
