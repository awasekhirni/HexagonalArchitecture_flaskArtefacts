from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.skills.skills_entity import Skills
from domain.skills.skills_service_interface import IAsyncSkillsService
from api.dtos.skills_dto import SkillsCreate, SkillsUpdate, SkillsResponse
from api.mappers.skills_mapper import skills_mapper
from api.validations.skills_validation_schemas import validate_skills_create, validate_skills_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('skills', description='Skills operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
skills_create_model = api.model('SkillsCreate', {
    'name': fields.String(required=True, description='skills name'),
    'description': fields.String(description='skills description'),
    'status': fields.String(description='skills status', enum=['active', 'inactive', 'pending'])
})

skills_update_model = api.model('SkillsUpdate', {
    'name': fields.String(description='skills name'),
    'description': fields.String(description='skills description'),
    'status': fields.String(description='skills status', enum=['active', 'inactive', 'pending'])
})

skills_response_model = api.model('SkillsResponse', {
    'id': fields.String(description='skills ID'),
    'name': fields.String(description='skills name'),
    'description': fields.String(description='skills description'),
    'status': fields.String(description='skills status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncSkillsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class SkillsList(Resource):
        @api.doc('list_skillss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(skills_response_model)
        @token_required
        async def get(self):
            """List all skillss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [skills_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting skillss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_skills')
        @api.expect(skills_create_model)
        @api.marshal_with(skills_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new skills"""
            try:
                data = api.payload
                validated_data = validate_skills_create(data)
                entity = skills_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return skills_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating skills: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The skills identifier')
    @api.response(404, 'Skills not found')
    class SkillsResource(Resource):
        @api.doc('get_skills')
        @api.marshal_with(skills_response_model)
        @token_required
        async def get(self, id):
            """Get a skills given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Skills not found")
                return skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_skills')
        @api.expect(skills_update_model)
        @api.marshal_with(skills_response_model)
        @token_required
        async def put(self, id):
            """Update a skills given its identifier"""
            try:
                data = api.payload
                validated_data = validate_skills_update(data)
                entity = skills_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Skills not found")
                return skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_skills')
        @api.response(204, 'Skills deleted')
        @token_required
        async def delete(self, id):
            """Delete a skills given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Skills not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting skills {id}: {str(e)}")
                api.abort(400, str(e))

    return api
