from typing import List, Optional
from domain.skills.skills_entity import Skills
from domain.skills.skills_service_interface import IAsyncSkillsService
from infrastructure.repositories.skills.skills_repository import SkillsRepository
from api.mappers.skills_mapper import skills_mapper
from shared.utils.logger import logger

class SkillsService(IAsyncSkillsService):
    """Service implementation for Skills"""

    def __init__(self):
        self.repository = SkillsRepository()

    async def get_by_id(self, id: str) -> Optional[Skills]:
        """Get skills by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting skills by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Skills]:
        """Get all skillss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all skillss: {str(e)}")
            raise

    async def create(self, data: Skills) -> Skills:
        """Create new skills"""
        try:
            return await self.repository.create(skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating skills: {str(e)}")
            raise

    async def update(self, id: str, data: Skills) -> Optional[Skills]:
        """Update skills"""
        try:
            return await self.repository.update(id, skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating skills: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete skills"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting skills: {str(e)}")
            raise
