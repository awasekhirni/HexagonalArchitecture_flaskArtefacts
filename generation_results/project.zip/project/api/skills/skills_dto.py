from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class SkillsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class SkillsBase(BaseModel):
    """Base schema for skills"""
    pass

class SkillsCreate(SkillsBase):
    """Schema for creating skills"""
    name: str
    description: Optional[str] = None
    status: SkillsStatus = SkillsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class SkillsUpdate(SkillsBase):
    """Schema for updating skills"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[SkillsStatus] = None

class SkillsResponse(SkillsBase):
    """Response schema for skills"""
    id: str
    name: str
    description: Optional[str] = None
    status: SkillsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_skills_create(data: SkillsCreate) -> SkillsCreate:
    """Validate skills creation data"""
    return data

def validate_skills_update(data: SkillsUpdate) -> SkillsUpdate:
    """Validate skills update data"""
    return data
