from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_job_historyStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_job_historyBase(BaseModel):
    """Base schema for user_job_history"""
    pass

class User_job_historyCreate(User_job_historyBase):
    """Schema for creating user_job_history"""
    name: str
    description: Optional[str] = None
    status: User_job_historyStatus = User_job_historyStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_job_historyUpdate(User_job_historyBase):
    """Schema for updating user_job_history"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_job_historyStatus] = None

class User_job_historyResponse(User_job_historyBase):
    """Response schema for user_job_history"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_job_historyStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_job_history_create(data: User_job_historyCreate) -> User_job_historyCreate:
    """Validate user_job_history creation data"""
    return data

def validate_user_job_history_update(data: User_job_historyUpdate) -> User_job_historyUpdate:
    """Validate user_job_history update data"""
    return data
