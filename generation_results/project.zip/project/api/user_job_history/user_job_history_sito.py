from typing import List, Optional
from domain.user_job_history.user_job_history_entity import User_job_history
from domain.user_job_history.user_job_history_service_interface import IAsyncUser_job_historyService
from infrastructure.repositories.user_job_history.user_job_history_repository import User_job_historyRepository
from api.mappers.user_job_history_mapper import user_job_history_mapper
from shared.utils.logger import logger

class User_job_historyService(IAsyncUser_job_historyService):
    """Service implementation for User_job_history"""

    def __init__(self):
        self.repository = User_job_historyRepository()

    async def get_by_id(self, id: str) -> Optional[User_job_history]:
        """Get user_job_history by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_job_history by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_job_history]:
        """Get all user_job_historys"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_job_historys: {str(e)}")
            raise

    async def create(self, data: User_job_history) -> User_job_history:
        """Create new user_job_history"""
        try:
            return await self.repository.create(user_job_history_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_job_history: {str(e)}")
            raise

    async def update(self, id: str, data: User_job_history) -> Optional[User_job_history]:
        """Update user_job_history"""
        try:
            return await self.repository.update(id, user_job_history_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_job_history: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_job_history"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_job_history: {str(e)}")
            raise
