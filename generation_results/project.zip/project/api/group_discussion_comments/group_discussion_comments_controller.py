from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.group_discussion_comments.group_discussion_comments_entity import Group_discussion_comments
from domain.group_discussion_comments.group_discussion_comments_service_interface import IAsyncGroup_discussion_commentsService
from api.dtos.group_discussion_comments_dto import Group_discussion_commentsCreate, Group_discussion_commentsUpdate, Group_discussion_commentsResponse
from api.mappers.group_discussion_comments_mapper import group_discussion_comments_mapper
from api.validations.group_discussion_comments_validation_schemas import validate_group_discussion_comments_create, validate_group_discussion_comments_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('group_discussion_comments', description='Group_discussion_comments operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
group_discussion_comments_create_model = api.model('Group_discussion_commentsCreate', {
    'name': fields.String(required=True, description='group_discussion_comments name'),
    'description': fields.String(description='group_discussion_comments description'),
    'status': fields.String(description='group_discussion_comments status', enum=['active', 'inactive', 'pending'])
})

group_discussion_comments_update_model = api.model('Group_discussion_commentsUpdate', {
    'name': fields.String(description='group_discussion_comments name'),
    'description': fields.String(description='group_discussion_comments description'),
    'status': fields.String(description='group_discussion_comments status', enum=['active', 'inactive', 'pending'])
})

group_discussion_comments_response_model = api.model('Group_discussion_commentsResponse', {
    'id': fields.String(description='group_discussion_comments ID'),
    'name': fields.String(description='group_discussion_comments name'),
    'description': fields.String(description='group_discussion_comments description'),
    'status': fields.String(description='group_discussion_comments status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncGroup_discussion_commentsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Group_discussion_commentsList(Resource):
        @api.doc('list_group_discussion_commentss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(group_discussion_comments_response_model)
        @token_required
        async def get(self):
            """List all group_discussion_commentss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [group_discussion_comments_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting group_discussion_commentss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_group_discussion_comments')
        @api.expect(group_discussion_comments_create_model)
        @api.marshal_with(group_discussion_comments_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new group_discussion_comments"""
            try:
                data = api.payload
                validated_data = validate_group_discussion_comments_create(data)
                entity = group_discussion_comments_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return group_discussion_comments_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating group_discussion_comments: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The group_discussion_comments identifier')
    @api.response(404, 'Group_discussion_comments not found')
    class Group_discussion_commentsResource(Resource):
        @api.doc('get_group_discussion_comments')
        @api.marshal_with(group_discussion_comments_response_model)
        @token_required
        async def get(self, id):
            """Get a group_discussion_comments given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Group_discussion_comments not found")
                return group_discussion_comments_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting group_discussion_comments {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_group_discussion_comments')
        @api.expect(group_discussion_comments_update_model)
        @api.marshal_with(group_discussion_comments_response_model)
        @token_required
        async def put(self, id):
            """Update a group_discussion_comments given its identifier"""
            try:
                data = api.payload
                validated_data = validate_group_discussion_comments_update(data)
                entity = group_discussion_comments_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Group_discussion_comments not found")
                return group_discussion_comments_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating group_discussion_comments {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_group_discussion_comments')
        @api.response(204, 'Group_discussion_comments deleted')
        @token_required
        async def delete(self, id):
            """Delete a group_discussion_comments given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Group_discussion_comments not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting group_discussion_comments {id}: {str(e)}")
                api.abort(400, str(e))

    return api
