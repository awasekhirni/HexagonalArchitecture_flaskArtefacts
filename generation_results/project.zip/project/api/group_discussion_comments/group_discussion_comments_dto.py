from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Group_discussion_commentsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Group_discussion_commentsBase(BaseModel):
    """Base schema for group_discussion_comments"""
    pass

class Group_discussion_commentsCreate(Group_discussion_commentsBase):
    """Schema for creating group_discussion_comments"""
    name: str
    description: Optional[str] = None
    status: Group_discussion_commentsStatus = Group_discussion_commentsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Group_discussion_commentsUpdate(Group_discussion_commentsBase):
    """Schema for updating group_discussion_comments"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Group_discussion_commentsStatus] = None

class Group_discussion_commentsResponse(Group_discussion_commentsBase):
    """Response schema for group_discussion_comments"""
    id: str
    name: str
    description: Optional[str] = None
    status: Group_discussion_commentsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_group_discussion_comments_create(data: Group_discussion_commentsCreate) -> Group_discussion_commentsCreate:
    """Validate group_discussion_comments creation data"""
    return data

def validate_group_discussion_comments_update(data: Group_discussion_commentsUpdate) -> Group_discussion_commentsUpdate:
    """Validate group_discussion_comments update data"""
    return data
