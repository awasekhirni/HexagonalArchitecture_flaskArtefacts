from typing import List, Optional
from domain.group_discussion_comments.group_discussion_comments_entity import Group_discussion_comments
from domain.group_discussion_comments.group_discussion_comments_service_interface import IAsyncGroup_discussion_commentsService
from infrastructure.repositories.group_discussion_comments.group_discussion_comments_repository import Group_discussion_commentsRepository
from api.mappers.group_discussion_comments_mapper import group_discussion_comments_mapper
from shared.utils.logger import logger

class Group_discussion_commentsService(IAsyncGroup_discussion_commentsService):
    """Service implementation for Group_discussion_comments"""

    def __init__(self):
        self.repository = Group_discussion_commentsRepository()

    async def get_by_id(self, id: str) -> Optional[Group_discussion_comments]:
        """Get group_discussion_comments by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting group_discussion_comments by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Group_discussion_comments]:
        """Get all group_discussion_commentss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all group_discussion_commentss: {str(e)}")
            raise

    async def create(self, data: Group_discussion_comments) -> Group_discussion_comments:
        """Create new group_discussion_comments"""
        try:
            return await self.repository.create(group_discussion_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating group_discussion_comments: {str(e)}")
            raise

    async def update(self, id: str, data: Group_discussion_comments) -> Optional[Group_discussion_comments]:
        """Update group_discussion_comments"""
        try:
            return await self.repository.update(id, group_discussion_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating group_discussion_comments: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete group_discussion_comments"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting group_discussion_comments: {str(e)}")
            raise
