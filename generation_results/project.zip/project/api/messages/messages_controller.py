from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.messages.messages_entity import Messages
from domain.messages.messages_service_interface import IAsyncMessagesService
from api.dtos.messages_dto import MessagesCreate, MessagesUpdate, MessagesResponse
from api.mappers.messages_mapper import messages_mapper
from api.validations.messages_validation_schemas import validate_messages_create, validate_messages_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('messages', description='Messages operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
messages_create_model = api.model('MessagesCreate', {
    'name': fields.String(required=True, description='messages name'),
    'description': fields.String(description='messages description'),
    'status': fields.String(description='messages status', enum=['active', 'inactive', 'pending'])
})

messages_update_model = api.model('MessagesUpdate', {
    'name': fields.String(description='messages name'),
    'description': fields.String(description='messages description'),
    'status': fields.String(description='messages status', enum=['active', 'inactive', 'pending'])
})

messages_response_model = api.model('MessagesResponse', {
    'id': fields.String(description='messages ID'),
    'name': fields.String(description='messages name'),
    'description': fields.String(description='messages description'),
    'status': fields.String(description='messages status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncMessagesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class MessagesList(Resource):
        @api.doc('list_messagess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(messages_response_model)
        @token_required
        async def get(self):
            """List all messagess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [messages_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting messagess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_messages')
        @api.expect(messages_create_model)
        @api.marshal_with(messages_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new messages"""
            try:
                data = api.payload
                validated_data = validate_messages_create(data)
                entity = messages_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return messages_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating messages: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The messages identifier')
    @api.response(404, 'Messages not found')
    class MessagesResource(Resource):
        @api.doc('get_messages')
        @api.marshal_with(messages_response_model)
        @token_required
        async def get(self, id):
            """Get a messages given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Messages not found")
                return messages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting messages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_messages')
        @api.expect(messages_update_model)
        @api.marshal_with(messages_response_model)
        @token_required
        async def put(self, id):
            """Update a messages given its identifier"""
            try:
                data = api.payload
                validated_data = validate_messages_update(data)
                entity = messages_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Messages not found")
                return messages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating messages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_messages')
        @api.response(204, 'Messages deleted')
        @token_required
        async def delete(self, id):
            """Delete a messages given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Messages not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting messages {id}: {str(e)}")
                api.abort(400, str(e))

    return api
