from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class MessagesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class MessagesBase(BaseModel):
    """Base schema for messages"""
    pass

class MessagesCreate(MessagesBase):
    """Schema for creating messages"""
    name: str
    description: Optional[str] = None
    status: MessagesStatus = MessagesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class MessagesUpdate(MessagesBase):
    """Schema for updating messages"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[MessagesStatus] = None

class MessagesResponse(MessagesBase):
    """Response schema for messages"""
    id: str
    name: str
    description: Optional[str] = None
    status: MessagesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_messages_create(data: MessagesCreate) -> MessagesCreate:
    """Validate messages creation data"""
    return data

def validate_messages_update(data: MessagesUpdate) -> MessagesUpdate:
    """Validate messages update data"""
    return data
