from typing import List, Optional
from domain.messages.messages_entity import Messages
from domain.messages.messages_service_interface import IAsyncMessagesService
from infrastructure.repositories.messages.messages_repository import MessagesRepository
from api.mappers.messages_mapper import messages_mapper
from shared.utils.logger import logger

class MessagesService(IAsyncMessagesService):
    """Service implementation for Messages"""

    def __init__(self):
        self.repository = MessagesRepository()

    async def get_by_id(self, id: str) -> Optional[Messages]:
        """Get messages by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting messages by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Messages]:
        """Get all messagess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all messagess: {str(e)}")
            raise

    async def create(self, data: Messages) -> Messages:
        """Create new messages"""
        try:
            return await self.repository.create(messages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating messages: {str(e)}")
            raise

    async def update(self, id: str, data: Messages) -> Optional[Messages]:
        """Update messages"""
        try:
            return await self.repository.update(id, messages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating messages: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete messages"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting messages: {str(e)}")
            raise
