from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Audit_logsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Audit_logsBase(BaseModel):
    """Base schema for audit_logs"""
    pass

class Audit_logsCreate(Audit_logsBase):
    """Schema for creating audit_logs"""
    name: str
    description: Optional[str] = None
    status: Audit_logsStatus = Audit_logsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Audit_logsUpdate(Audit_logsBase):
    """Schema for updating audit_logs"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Audit_logsStatus] = None

class Audit_logsResponse(Audit_logsBase):
    """Response schema for audit_logs"""
    id: str
    name: str
    description: Optional[str] = None
    status: Audit_logsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_audit_logs_create(data: Audit_logsCreate) -> Audit_logsCreate:
    """Validate audit_logs creation data"""
    return data

def validate_audit_logs_update(data: Audit_logsUpdate) -> Audit_logsUpdate:
    """Validate audit_logs update data"""
    return data
