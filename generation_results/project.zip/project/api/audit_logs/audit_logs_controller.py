from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.audit_logs.audit_logs_entity import Audit_logs
from domain.audit_logs.audit_logs_service_interface import IAsyncAudit_logsService
from api.dtos.audit_logs_dto import Audit_logsCreate, Audit_logsUpdate, Audit_logsResponse
from api.mappers.audit_logs_mapper import audit_logs_mapper
from api.validations.audit_logs_validation_schemas import validate_audit_logs_create, validate_audit_logs_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('audit_logs', description='Audit_logs operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
audit_logs_create_model = api.model('Audit_logsCreate', {
    'name': fields.String(required=True, description='audit_logs name'),
    'description': fields.String(description='audit_logs description'),
    'status': fields.String(description='audit_logs status', enum=['active', 'inactive', 'pending'])
})

audit_logs_update_model = api.model('Audit_logsUpdate', {
    'name': fields.String(description='audit_logs name'),
    'description': fields.String(description='audit_logs description'),
    'status': fields.String(description='audit_logs status', enum=['active', 'inactive', 'pending'])
})

audit_logs_response_model = api.model('Audit_logsResponse', {
    'id': fields.String(description='audit_logs ID'),
    'name': fields.String(description='audit_logs name'),
    'description': fields.String(description='audit_logs description'),
    'status': fields.String(description='audit_logs status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncAudit_logsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Audit_logsList(Resource):
        @api.doc('list_audit_logss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(audit_logs_response_model)
        @token_required
        async def get(self):
            """List all audit_logss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [audit_logs_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting audit_logss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_audit_logs')
        @api.expect(audit_logs_create_model)
        @api.marshal_with(audit_logs_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new audit_logs"""
            try:
                data = api.payload
                validated_data = validate_audit_logs_create(data)
                entity = audit_logs_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return audit_logs_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating audit_logs: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The audit_logs identifier')
    @api.response(404, 'Audit_logs not found')
    class Audit_logsResource(Resource):
        @api.doc('get_audit_logs')
        @api.marshal_with(audit_logs_response_model)
        @token_required
        async def get(self, id):
            """Get a audit_logs given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Audit_logs not found")
                return audit_logs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting audit_logs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_audit_logs')
        @api.expect(audit_logs_update_model)
        @api.marshal_with(audit_logs_response_model)
        @token_required
        async def put(self, id):
            """Update a audit_logs given its identifier"""
            try:
                data = api.payload
                validated_data = validate_audit_logs_update(data)
                entity = audit_logs_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Audit_logs not found")
                return audit_logs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating audit_logs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_audit_logs')
        @api.response(204, 'Audit_logs deleted')
        @token_required
        async def delete(self, id):
            """Delete a audit_logs given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Audit_logs not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting audit_logs {id}: {str(e)}")
                api.abort(400, str(e))

    return api
