from typing import List, Optional
from domain.audit_logs.audit_logs_entity import Audit_logs
from domain.audit_logs.audit_logs_service_interface import IAsyncAudit_logsService
from infrastructure.repositories.audit_logs.audit_logs_repository import Audit_logsRepository
from api.mappers.audit_logs_mapper import audit_logs_mapper
from shared.utils.logger import logger

class Audit_logsService(IAsyncAudit_logsService):
    """Service implementation for Audit_logs"""

    def __init__(self):
        self.repository = Audit_logsRepository()

    async def get_by_id(self, id: str) -> Optional[Audit_logs]:
        """Get audit_logs by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting audit_logs by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Audit_logs]:
        """Get all audit_logss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all audit_logss: {str(e)}")
            raise

    async def create(self, data: Audit_logs) -> Audit_logs:
        """Create new audit_logs"""
        try:
            return await self.repository.create(audit_logs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating audit_logs: {str(e)}")
            raise

    async def update(self, id: str, data: Audit_logs) -> Optional[Audit_logs]:
        """Update audit_logs"""
        try:
            return await self.repository.update(id, audit_logs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating audit_logs: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete audit_logs"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting audit_logs: {str(e)}")
            raise
