from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.skill_endorsements.skill_endorsements_entity import Skill_endorsements
from domain.skill_endorsements.skill_endorsements_service_interface import IAsyncSkill_endorsementsService
from api.dtos.skill_endorsements_dto import Skill_endorsementsCreate, Skill_endorsementsUpdate, Skill_endorsementsResponse
from api.mappers.skill_endorsements_mapper import skill_endorsements_mapper
from api.validations.skill_endorsements_validation_schemas import validate_skill_endorsements_create, validate_skill_endorsements_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('skill_endorsements', description='Skill_endorsements operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
skill_endorsements_create_model = api.model('Skill_endorsementsCreate', {
    'name': fields.String(required=True, description='skill_endorsements name'),
    'description': fields.String(description='skill_endorsements description'),
    'status': fields.String(description='skill_endorsements status', enum=['active', 'inactive', 'pending'])
})

skill_endorsements_update_model = api.model('Skill_endorsementsUpdate', {
    'name': fields.String(description='skill_endorsements name'),
    'description': fields.String(description='skill_endorsements description'),
    'status': fields.String(description='skill_endorsements status', enum=['active', 'inactive', 'pending'])
})

skill_endorsements_response_model = api.model('Skill_endorsementsResponse', {
    'id': fields.String(description='skill_endorsements ID'),
    'name': fields.String(description='skill_endorsements name'),
    'description': fields.String(description='skill_endorsements description'),
    'status': fields.String(description='skill_endorsements status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncSkill_endorsementsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Skill_endorsementsList(Resource):
        @api.doc('list_skill_endorsementss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(skill_endorsements_response_model)
        @token_required
        async def get(self):
            """List all skill_endorsementss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [skill_endorsements_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting skill_endorsementss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_skill_endorsements')
        @api.expect(skill_endorsements_create_model)
        @api.marshal_with(skill_endorsements_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new skill_endorsements"""
            try:
                data = api.payload
                validated_data = validate_skill_endorsements_create(data)
                entity = skill_endorsements_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return skill_endorsements_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating skill_endorsements: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The skill_endorsements identifier')
    @api.response(404, 'Skill_endorsements not found')
    class Skill_endorsementsResource(Resource):
        @api.doc('get_skill_endorsements')
        @api.marshal_with(skill_endorsements_response_model)
        @token_required
        async def get(self, id):
            """Get a skill_endorsements given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Skill_endorsements not found")
                return skill_endorsements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting skill_endorsements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_skill_endorsements')
        @api.expect(skill_endorsements_update_model)
        @api.marshal_with(skill_endorsements_response_model)
        @token_required
        async def put(self, id):
            """Update a skill_endorsements given its identifier"""
            try:
                data = api.payload
                validated_data = validate_skill_endorsements_update(data)
                entity = skill_endorsements_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Skill_endorsements not found")
                return skill_endorsements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating skill_endorsements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_skill_endorsements')
        @api.response(204, 'Skill_endorsements deleted')
        @token_required
        async def delete(self, id):
            """Delete a skill_endorsements given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Skill_endorsements not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting skill_endorsements {id}: {str(e)}")
                api.abort(400, str(e))

    return api
