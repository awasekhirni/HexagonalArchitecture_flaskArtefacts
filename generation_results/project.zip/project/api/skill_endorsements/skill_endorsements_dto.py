from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Skill_endorsementsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Skill_endorsementsBase(BaseModel):
    """Base schema for skill_endorsements"""
    pass

class Skill_endorsementsCreate(Skill_endorsementsBase):
    """Schema for creating skill_endorsements"""
    name: str
    description: Optional[str] = None
    status: Skill_endorsementsStatus = Skill_endorsementsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Skill_endorsementsUpdate(Skill_endorsementsBase):
    """Schema for updating skill_endorsements"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Skill_endorsementsStatus] = None

class Skill_endorsementsResponse(Skill_endorsementsBase):
    """Response schema for skill_endorsements"""
    id: str
    name: str
    description: Optional[str] = None
    status: Skill_endorsementsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_skill_endorsements_create(data: Skill_endorsementsCreate) -> Skill_endorsementsCreate:
    """Validate skill_endorsements creation data"""
    return data

def validate_skill_endorsements_update(data: Skill_endorsementsUpdate) -> Skill_endorsementsUpdate:
    """Validate skill_endorsements update data"""
    return data
