from typing import List, Optional
from domain.skill_endorsements.skill_endorsements_entity import Skill_endorsements
from domain.skill_endorsements.skill_endorsements_service_interface import IAsyncSkill_endorsementsService
from infrastructure.repositories.skill_endorsements.skill_endorsements_repository import Skill_endorsementsRepository
from api.mappers.skill_endorsements_mapper import skill_endorsements_mapper
from shared.utils.logger import logger

class Skill_endorsementsService(IAsyncSkill_endorsementsService):
    """Service implementation for Skill_endorsements"""

    def __init__(self):
        self.repository = Skill_endorsementsRepository()

    async def get_by_id(self, id: str) -> Optional[Skill_endorsements]:
        """Get skill_endorsements by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting skill_endorsements by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Skill_endorsements]:
        """Get all skill_endorsementss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all skill_endorsementss: {str(e)}")
            raise

    async def create(self, data: Skill_endorsements) -> Skill_endorsements:
        """Create new skill_endorsements"""
        try:
            return await self.repository.create(skill_endorsements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating skill_endorsements: {str(e)}")
            raise

    async def update(self, id: str, data: Skill_endorsements) -> Optional[Skill_endorsements]:
        """Update skill_endorsements"""
        try:
            return await self.repository.update(id, skill_endorsements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating skill_endorsements: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete skill_endorsements"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting skill_endorsements: {str(e)}")
            raise
