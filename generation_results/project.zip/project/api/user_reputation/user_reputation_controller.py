from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_reputation.user_reputation_entity import User_reputation
from domain.user_reputation.user_reputation_service_interface import IAsyncUser_reputationService
from api.dtos.user_reputation_dto import User_reputationCreate, User_reputationUpdate, User_reputationResponse
from api.mappers.user_reputation_mapper import user_reputation_mapper
from api.validations.user_reputation_validation_schemas import validate_user_reputation_create, validate_user_reputation_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_reputation', description='User_reputation operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_reputation_create_model = api.model('User_reputationCreate', {
    'name': fields.String(required=True, description='user_reputation name'),
    'description': fields.String(description='user_reputation description'),
    'status': fields.String(description='user_reputation status', enum=['active', 'inactive', 'pending'])
})

user_reputation_update_model = api.model('User_reputationUpdate', {
    'name': fields.String(description='user_reputation name'),
    'description': fields.String(description='user_reputation description'),
    'status': fields.String(description='user_reputation status', enum=['active', 'inactive', 'pending'])
})

user_reputation_response_model = api.model('User_reputationResponse', {
    'id': fields.String(description='user_reputation ID'),
    'name': fields.String(description='user_reputation name'),
    'description': fields.String(description='user_reputation description'),
    'status': fields.String(description='user_reputation status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_reputationService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_reputationList(Resource):
        @api.doc('list_user_reputations')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_reputation_response_model)
        @token_required
        async def get(self):
            """List all user_reputations"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_reputation_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_reputations: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_reputation')
        @api.expect(user_reputation_create_model)
        @api.marshal_with(user_reputation_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_reputation"""
            try:
                data = api.payload
                validated_data = validate_user_reputation_create(data)
                entity = user_reputation_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_reputation_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_reputation: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_reputation identifier')
    @api.response(404, 'User_reputation not found')
    class User_reputationResource(Resource):
        @api.doc('get_user_reputation')
        @api.marshal_with(user_reputation_response_model)
        @token_required
        async def get(self, id):
            """Get a user_reputation given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_reputation not found")
                return user_reputation_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_reputation {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_reputation')
        @api.expect(user_reputation_update_model)
        @api.marshal_with(user_reputation_response_model)
        @token_required
        async def put(self, id):
            """Update a user_reputation given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_reputation_update(data)
                entity = user_reputation_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_reputation not found")
                return user_reputation_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_reputation {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_reputation')
        @api.response(204, 'User_reputation deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_reputation given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_reputation not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_reputation {id}: {str(e)}")
                api.abort(400, str(e))

    return api
