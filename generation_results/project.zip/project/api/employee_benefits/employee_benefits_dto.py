from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Employee_benefitsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Employee_benefitsBase(BaseModel):
    """Base schema for employee_benefits"""
    pass

class Employee_benefitsCreate(Employee_benefitsBase):
    """Schema for creating employee_benefits"""
    name: str
    description: Optional[str] = None
    status: Employee_benefitsStatus = Employee_benefitsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Employee_benefitsUpdate(Employee_benefitsBase):
    """Schema for updating employee_benefits"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Employee_benefitsStatus] = None

class Employee_benefitsResponse(Employee_benefitsBase):
    """Response schema for employee_benefits"""
    id: str
    name: str
    description: Optional[str] = None
    status: Employee_benefitsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_employee_benefits_create(data: Employee_benefitsCreate) -> Employee_benefitsCreate:
    """Validate employee_benefits creation data"""
    return data

def validate_employee_benefits_update(data: Employee_benefitsUpdate) -> Employee_benefitsUpdate:
    """Validate employee_benefits update data"""
    return data
