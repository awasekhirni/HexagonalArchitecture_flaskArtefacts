from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.employee_benefits.employee_benefits_entity import Employee_benefits
from domain.employee_benefits.employee_benefits_service_interface import IAsyncEmployee_benefitsService
from api.dtos.employee_benefits_dto import Employee_benefitsCreate, Employee_benefitsUpdate, Employee_benefitsResponse
from api.mappers.employee_benefits_mapper import employee_benefits_mapper
from api.validations.employee_benefits_validation_schemas import validate_employee_benefits_create, validate_employee_benefits_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('employee_benefits', description='Employee_benefits operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
employee_benefits_create_model = api.model('Employee_benefitsCreate', {
    'name': fields.String(required=True, description='employee_benefits name'),
    'description': fields.String(description='employee_benefits description'),
    'status': fields.String(description='employee_benefits status', enum=['active', 'inactive', 'pending'])
})

employee_benefits_update_model = api.model('Employee_benefitsUpdate', {
    'name': fields.String(description='employee_benefits name'),
    'description': fields.String(description='employee_benefits description'),
    'status': fields.String(description='employee_benefits status', enum=['active', 'inactive', 'pending'])
})

employee_benefits_response_model = api.model('Employee_benefitsResponse', {
    'id': fields.String(description='employee_benefits ID'),
    'name': fields.String(description='employee_benefits name'),
    'description': fields.String(description='employee_benefits description'),
    'status': fields.String(description='employee_benefits status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncEmployee_benefitsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Employee_benefitsList(Resource):
        @api.doc('list_employee_benefitss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(employee_benefits_response_model)
        @token_required
        async def get(self):
            """List all employee_benefitss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [employee_benefits_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting employee_benefitss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_employee_benefits')
        @api.expect(employee_benefits_create_model)
        @api.marshal_with(employee_benefits_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new employee_benefits"""
            try:
                data = api.payload
                validated_data = validate_employee_benefits_create(data)
                entity = employee_benefits_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return employee_benefits_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating employee_benefits: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The employee_benefits identifier')
    @api.response(404, 'Employee_benefits not found')
    class Employee_benefitsResource(Resource):
        @api.doc('get_employee_benefits')
        @api.marshal_with(employee_benefits_response_model)
        @token_required
        async def get(self, id):
            """Get a employee_benefits given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Employee_benefits not found")
                return employee_benefits_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting employee_benefits {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_employee_benefits')
        @api.expect(employee_benefits_update_model)
        @api.marshal_with(employee_benefits_response_model)
        @token_required
        async def put(self, id):
            """Update a employee_benefits given its identifier"""
            try:
                data = api.payload
                validated_data = validate_employee_benefits_update(data)
                entity = employee_benefits_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Employee_benefits not found")
                return employee_benefits_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating employee_benefits {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_employee_benefits')
        @api.response(204, 'Employee_benefits deleted')
        @token_required
        async def delete(self, id):
            """Delete a employee_benefits given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Employee_benefits not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting employee_benefits {id}: {str(e)}")
                api.abort(400, str(e))

    return api
