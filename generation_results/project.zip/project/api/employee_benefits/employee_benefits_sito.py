from typing import List, Optional
from domain.employee_benefits.employee_benefits_entity import Employee_benefits
from domain.employee_benefits.employee_benefits_service_interface import IAsyncEmployee_benefitsService
from infrastructure.repositories.employee_benefits.employee_benefits_repository import Employee_benefitsRepository
from api.mappers.employee_benefits_mapper import employee_benefits_mapper
from shared.utils.logger import logger

class Employee_benefitsService(IAsyncEmployee_benefitsService):
    """Service implementation for Employee_benefits"""

    def __init__(self):
        self.repository = Employee_benefitsRepository()

    async def get_by_id(self, id: str) -> Optional[Employee_benefits]:
        """Get employee_benefits by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting employee_benefits by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Employee_benefits]:
        """Get all employee_benefitss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all employee_benefitss: {str(e)}")
            raise

    async def create(self, data: Employee_benefits) -> Employee_benefits:
        """Create new employee_benefits"""
        try:
            return await self.repository.create(employee_benefits_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating employee_benefits: {str(e)}")
            raise

    async def update(self, id: str, data: Employee_benefits) -> Optional[Employee_benefits]:
        """Update employee_benefits"""
        try:
            return await self.repository.update(id, employee_benefits_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating employee_benefits: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete employee_benefits"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting employee_benefits: {str(e)}")
            raise
