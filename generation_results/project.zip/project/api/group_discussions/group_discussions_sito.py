from typing import List, Optional
from domain.group_discussions.group_discussions_entity import Group_discussions
from domain.group_discussions.group_discussions_service_interface import IAsyncGroup_discussionsService
from infrastructure.repositories.group_discussions.group_discussions_repository import Group_discussionsRepository
from api.mappers.group_discussions_mapper import group_discussions_mapper
from shared.utils.logger import logger

class Group_discussionsService(IAsyncGroup_discussionsService):
    """Service implementation for Group_discussions"""

    def __init__(self):
        self.repository = Group_discussionsRepository()

    async def get_by_id(self, id: str) -> Optional[Group_discussions]:
        """Get group_discussions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting group_discussions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Group_discussions]:
        """Get all group_discussionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all group_discussionss: {str(e)}")
            raise

    async def create(self, data: Group_discussions) -> Group_discussions:
        """Create new group_discussions"""
        try:
            return await self.repository.create(group_discussions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating group_discussions: {str(e)}")
            raise

    async def update(self, id: str, data: Group_discussions) -> Optional[Group_discussions]:
        """Update group_discussions"""
        try:
            return await self.repository.update(id, group_discussions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating group_discussions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete group_discussions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting group_discussions: {str(e)}")
            raise
