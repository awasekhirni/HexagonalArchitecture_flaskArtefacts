from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Group_discussionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Group_discussionsBase(BaseModel):
    """Base schema for group_discussions"""
    pass

class Group_discussionsCreate(Group_discussionsBase):
    """Schema for creating group_discussions"""
    name: str
    description: Optional[str] = None
    status: Group_discussionsStatus = Group_discussionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Group_discussionsUpdate(Group_discussionsBase):
    """Schema for updating group_discussions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Group_discussionsStatus] = None

class Group_discussionsResponse(Group_discussionsBase):
    """Response schema for group_discussions"""
    id: str
    name: str
    description: Optional[str] = None
    status: Group_discussionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_group_discussions_create(data: Group_discussionsCreate) -> Group_discussionsCreate:
    """Validate group_discussions creation data"""
    return data

def validate_group_discussions_update(data: Group_discussionsUpdate) -> Group_discussionsUpdate:
    """Validate group_discussions update data"""
    return data
