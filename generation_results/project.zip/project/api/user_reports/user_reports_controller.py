from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_reports.user_reports_entity import User_reports
from domain.user_reports.user_reports_service_interface import IAsyncUser_reportsService
from api.dtos.user_reports_dto import User_reportsCreate, User_reportsUpdate, User_reportsResponse
from api.mappers.user_reports_mapper import user_reports_mapper
from api.validations.user_reports_validation_schemas import validate_user_reports_create, validate_user_reports_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_reports', description='User_reports operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_reports_create_model = api.model('User_reportsCreate', {
    'name': fields.String(required=True, description='user_reports name'),
    'description': fields.String(description='user_reports description'),
    'status': fields.String(description='user_reports status', enum=['active', 'inactive', 'pending'])
})

user_reports_update_model = api.model('User_reportsUpdate', {
    'name': fields.String(description='user_reports name'),
    'description': fields.String(description='user_reports description'),
    'status': fields.String(description='user_reports status', enum=['active', 'inactive', 'pending'])
})

user_reports_response_model = api.model('User_reportsResponse', {
    'id': fields.String(description='user_reports ID'),
    'name': fields.String(description='user_reports name'),
    'description': fields.String(description='user_reports description'),
    'status': fields.String(description='user_reports status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_reportsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_reportsList(Resource):
        @api.doc('list_user_reportss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_reports_response_model)
        @token_required
        async def get(self):
            """List all user_reportss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_reports_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_reportss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_reports')
        @api.expect(user_reports_create_model)
        @api.marshal_with(user_reports_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_reports"""
            try:
                data = api.payload
                validated_data = validate_user_reports_create(data)
                entity = user_reports_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_reports_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_reports: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_reports identifier')
    @api.response(404, 'User_reports not found')
    class User_reportsResource(Resource):
        @api.doc('get_user_reports')
        @api.marshal_with(user_reports_response_model)
        @token_required
        async def get(self, id):
            """Get a user_reports given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_reports not found")
                return user_reports_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_reports {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_reports')
        @api.expect(user_reports_update_model)
        @api.marshal_with(user_reports_response_model)
        @token_required
        async def put(self, id):
            """Update a user_reports given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_reports_update(data)
                entity = user_reports_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_reports not found")
                return user_reports_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_reports {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_reports')
        @api.response(204, 'User_reports deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_reports given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_reports not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_reports {id}: {str(e)}")
                api.abort(400, str(e))

    return api
