from typing import List, Optional
from domain.user_reports.user_reports_entity import User_reports
from domain.user_reports.user_reports_service_interface import IAsyncUser_reportsService
from infrastructure.repositories.user_reports.user_reports_repository import User_reportsRepository
from api.mappers.user_reports_mapper import user_reports_mapper
from shared.utils.logger import logger

class User_reportsService(IAsyncUser_reportsService):
    """Service implementation for User_reports"""

    def __init__(self):
        self.repository = User_reportsRepository()

    async def get_by_id(self, id: str) -> Optional[User_reports]:
        """Get user_reports by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_reports by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_reports]:
        """Get all user_reportss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_reportss: {str(e)}")
            raise

    async def create(self, data: User_reports) -> User_reports:
        """Create new user_reports"""
        try:
            return await self.repository.create(user_reports_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_reports: {str(e)}")
            raise

    async def update(self, id: str, data: User_reports) -> Optional[User_reports]:
        """Update user_reports"""
        try:
            return await self.repository.update(id, user_reports_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_reports: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_reports"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_reports: {str(e)}")
            raise
