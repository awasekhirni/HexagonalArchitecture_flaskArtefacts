from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_reportsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_reportsBase(BaseModel):
    """Base schema for user_reports"""
    pass

class User_reportsCreate(User_reportsBase):
    """Schema for creating user_reports"""
    name: str
    description: Optional[str] = None
    status: User_reportsStatus = User_reportsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_reportsUpdate(User_reportsBase):
    """Schema for updating user_reports"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_reportsStatus] = None

class User_reportsResponse(User_reportsBase):
    """Response schema for user_reports"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_reportsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_reports_create(data: User_reportsCreate) -> User_reportsCreate:
    """Validate user_reports creation data"""
    return data

def validate_user_reports_update(data: User_reportsUpdate) -> User_reportsUpdate:
    """Validate user_reports update data"""
    return data
