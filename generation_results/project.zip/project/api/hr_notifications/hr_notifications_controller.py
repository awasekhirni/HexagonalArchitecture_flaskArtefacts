from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.hr_notifications.hr_notifications_entity import Hr_notifications
from domain.hr_notifications.hr_notifications_service_interface import IAsyncHr_notificationsService
from api.dtos.hr_notifications_dto import Hr_notificationsCreate, Hr_notificationsUpdate, Hr_notificationsResponse
from api.mappers.hr_notifications_mapper import hr_notifications_mapper
from api.validations.hr_notifications_validation_schemas import validate_hr_notifications_create, validate_hr_notifications_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('hr_notifications', description='Hr_notifications operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
hr_notifications_create_model = api.model('Hr_notificationsCreate', {
    'name': fields.String(required=True, description='hr_notifications name'),
    'description': fields.String(description='hr_notifications description'),
    'status': fields.String(description='hr_notifications status', enum=['active', 'inactive', 'pending'])
})

hr_notifications_update_model = api.model('Hr_notificationsUpdate', {
    'name': fields.String(description='hr_notifications name'),
    'description': fields.String(description='hr_notifications description'),
    'status': fields.String(description='hr_notifications status', enum=['active', 'inactive', 'pending'])
})

hr_notifications_response_model = api.model('Hr_notificationsResponse', {
    'id': fields.String(description='hr_notifications ID'),
    'name': fields.String(description='hr_notifications name'),
    'description': fields.String(description='hr_notifications description'),
    'status': fields.String(description='hr_notifications status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncHr_notificationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Hr_notificationsList(Resource):
        @api.doc('list_hr_notificationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(hr_notifications_response_model)
        @token_required
        async def get(self):
            """List all hr_notificationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [hr_notifications_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting hr_notificationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_hr_notifications')
        @api.expect(hr_notifications_create_model)
        @api.marshal_with(hr_notifications_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new hr_notifications"""
            try:
                data = api.payload
                validated_data = validate_hr_notifications_create(data)
                entity = hr_notifications_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return hr_notifications_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating hr_notifications: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The hr_notifications identifier')
    @api.response(404, 'Hr_notifications not found')
    class Hr_notificationsResource(Resource):
        @api.doc('get_hr_notifications')
        @api.marshal_with(hr_notifications_response_model)
        @token_required
        async def get(self, id):
            """Get a hr_notifications given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Hr_notifications not found")
                return hr_notifications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting hr_notifications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_hr_notifications')
        @api.expect(hr_notifications_update_model)
        @api.marshal_with(hr_notifications_response_model)
        @token_required
        async def put(self, id):
            """Update a hr_notifications given its identifier"""
            try:
                data = api.payload
                validated_data = validate_hr_notifications_update(data)
                entity = hr_notifications_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Hr_notifications not found")
                return hr_notifications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating hr_notifications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_hr_notifications')
        @api.response(204, 'Hr_notifications deleted')
        @token_required
        async def delete(self, id):
            """Delete a hr_notifications given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Hr_notifications not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting hr_notifications {id}: {str(e)}")
                api.abort(400, str(e))

    return api
