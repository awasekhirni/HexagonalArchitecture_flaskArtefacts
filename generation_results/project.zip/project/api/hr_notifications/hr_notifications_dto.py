from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Hr_notificationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Hr_notificationsBase(BaseModel):
    """Base schema for hr_notifications"""
    pass

class Hr_notificationsCreate(Hr_notificationsBase):
    """Schema for creating hr_notifications"""
    name: str
    description: Optional[str] = None
    status: Hr_notificationsStatus = Hr_notificationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Hr_notificationsUpdate(Hr_notificationsBase):
    """Schema for updating hr_notifications"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Hr_notificationsStatus] = None

class Hr_notificationsResponse(Hr_notificationsBase):
    """Response schema for hr_notifications"""
    id: str
    name: str
    description: Optional[str] = None
    status: Hr_notificationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_hr_notifications_create(data: Hr_notificationsCreate) -> Hr_notificationsCreate:
    """Validate hr_notifications creation data"""
    return data

def validate_hr_notifications_update(data: Hr_notificationsUpdate) -> Hr_notificationsUpdate:
    """Validate hr_notifications update data"""
    return data
