from typing import List, Optional
from domain.hr_notifications.hr_notifications_entity import Hr_notifications
from domain.hr_notifications.hr_notifications_service_interface import IAsyncHr_notificationsService
from infrastructure.repositories.hr_notifications.hr_notifications_repository import Hr_notificationsRepository
from api.mappers.hr_notifications_mapper import hr_notifications_mapper
from shared.utils.logger import logger

class Hr_notificationsService(IAsyncHr_notificationsService):
    """Service implementation for Hr_notifications"""

    def __init__(self):
        self.repository = Hr_notificationsRepository()

    async def get_by_id(self, id: str) -> Optional[Hr_notifications]:
        """Get hr_notifications by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting hr_notifications by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Hr_notifications]:
        """Get all hr_notificationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all hr_notificationss: {str(e)}")
            raise

    async def create(self, data: Hr_notifications) -> Hr_notifications:
        """Create new hr_notifications"""
        try:
            return await self.repository.create(hr_notifications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating hr_notifications: {str(e)}")
            raise

    async def update(self, id: str, data: Hr_notifications) -> Optional[Hr_notifications]:
        """Update hr_notifications"""
        try:
            return await self.repository.update(id, hr_notifications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating hr_notifications: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete hr_notifications"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting hr_notifications: {str(e)}")
            raise
