from typing import List, Optional
from domain.job_required_skills.job_required_skills_entity import Job_required_skills
from domain.job_required_skills.job_required_skills_service_interface import IAsyncJob_required_skillsService
from infrastructure.repositories.job_required_skills.job_required_skills_repository import Job_required_skillsRepository
from api.mappers.job_required_skills_mapper import job_required_skills_mapper
from shared.utils.logger import logger

class Job_required_skillsService(IAsyncJob_required_skillsService):
    """Service implementation for Job_required_skills"""

    def __init__(self):
        self.repository = Job_required_skillsRepository()

    async def get_by_id(self, id: str) -> Optional[Job_required_skills]:
        """Get job_required_skills by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_required_skills by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_required_skills]:
        """Get all job_required_skillss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_required_skillss: {str(e)}")
            raise

    async def create(self, data: Job_required_skills) -> Job_required_skills:
        """Create new job_required_skills"""
        try:
            return await self.repository.create(job_required_skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_required_skills: {str(e)}")
            raise

    async def update(self, id: str, data: Job_required_skills) -> Optional[Job_required_skills]:
        """Update job_required_skills"""
        try:
            return await self.repository.update(id, job_required_skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_required_skills: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_required_skills"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_required_skills: {str(e)}")
            raise
