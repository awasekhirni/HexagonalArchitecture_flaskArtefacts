from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_required_skillsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_required_skillsBase(BaseModel):
    """Base schema for job_required_skills"""
    pass

class Job_required_skillsCreate(Job_required_skillsBase):
    """Schema for creating job_required_skills"""
    name: str
    description: Optional[str] = None
    status: Job_required_skillsStatus = Job_required_skillsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_required_skillsUpdate(Job_required_skillsBase):
    """Schema for updating job_required_skills"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_required_skillsStatus] = None

class Job_required_skillsResponse(Job_required_skillsBase):
    """Response schema for job_required_skills"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_required_skillsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_required_skills_create(data: Job_required_skillsCreate) -> Job_required_skillsCreate:
    """Validate job_required_skills creation data"""
    return data

def validate_job_required_skills_update(data: Job_required_skillsUpdate) -> Job_required_skillsUpdate:
    """Validate job_required_skills update data"""
    return data
