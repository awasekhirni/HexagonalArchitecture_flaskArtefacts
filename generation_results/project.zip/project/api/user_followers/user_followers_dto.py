from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_followersStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_followersBase(BaseModel):
    """Base schema for user_followers"""
    pass

class User_followersCreate(User_followersBase):
    """Schema for creating user_followers"""
    name: str
    description: Optional[str] = None
    status: User_followersStatus = User_followersStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_followersUpdate(User_followersBase):
    """Schema for updating user_followers"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_followersStatus] = None

class User_followersResponse(User_followersBase):
    """Response schema for user_followers"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_followersStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_followers_create(data: User_followersCreate) -> User_followersCreate:
    """Validate user_followers creation data"""
    return data

def validate_user_followers_update(data: User_followersUpdate) -> User_followersUpdate:
    """Validate user_followers update data"""
    return data
