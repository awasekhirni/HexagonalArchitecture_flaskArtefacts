from typing import List, Optional
from domain.user_followers.user_followers_entity import User_followers
from domain.user_followers.user_followers_service_interface import IAsyncUser_followersService
from infrastructure.repositories.user_followers.user_followers_repository import User_followersRepository
from api.mappers.user_followers_mapper import user_followers_mapper
from shared.utils.logger import logger

class User_followersService(IAsyncUser_followersService):
    """Service implementation for User_followers"""

    def __init__(self):
        self.repository = User_followersRepository()

    async def get_by_id(self, id: str) -> Optional[User_followers]:
        """Get user_followers by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_followers by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_followers]:
        """Get all user_followerss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_followerss: {str(e)}")
            raise

    async def create(self, data: User_followers) -> User_followers:
        """Create new user_followers"""
        try:
            return await self.repository.create(user_followers_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_followers: {str(e)}")
            raise

    async def update(self, id: str, data: User_followers) -> Optional[User_followers]:
        """Update user_followers"""
        try:
            return await self.repository.update(id, user_followers_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_followers: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_followers"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_followers: {str(e)}")
            raise
