from domain.sponsored_content.sponsored_content_entity import Sponsored_content
from api.dtos.sponsored_content_dto import Sponsored_contentCreate, Sponsored_contentUpdate, Sponsored_contentResponse
from typing import Union

class Sponsored_contentMapper:
    """Mapper for Sponsored_content between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Sponsored_content) -> Sponsored_contentResponse:
        """Convert entity to response DTO"""
        return Sponsored_contentResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Sponsored_contentCreate, Sponsored_contentUpdate]) -> Sponsored_content:
        """Convert DTO to entity"""
        return Sponsored_content(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Sponsored_content, dto: Sponsored_contentUpdate) -> Sponsored_content:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

sponsored_content_mapper = Sponsored_contentMapper()
