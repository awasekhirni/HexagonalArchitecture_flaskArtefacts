from typing import List, Optional
from domain.sponsored_content.sponsored_content_entity import Sponsored_content
from domain.sponsored_content.sponsored_content_service_interface import IAsyncSponsored_contentService
from infrastructure.repositories.sponsored_content.sponsored_content_repository import Sponsored_contentRepository
from api.mappers.sponsored_content_mapper import sponsored_content_mapper
from shared.utils.logger import logger

class Sponsored_contentService(IAsyncSponsored_contentService):
    """Service implementation for Sponsored_content"""

    def __init__(self):
        self.repository = Sponsored_contentRepository()

    async def get_by_id(self, id: str) -> Optional[Sponsored_content]:
        """Get sponsored_content by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting sponsored_content by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Sponsored_content]:
        """Get all sponsored_contents"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all sponsored_contents: {str(e)}")
            raise

    async def create(self, data: Sponsored_content) -> Sponsored_content:
        """Create new sponsored_content"""
        try:
            return await self.repository.create(sponsored_content_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating sponsored_content: {str(e)}")
            raise

    async def update(self, id: str, data: Sponsored_content) -> Optional[Sponsored_content]:
        """Update sponsored_content"""
        try:
            return await self.repository.update(id, sponsored_content_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating sponsored_content: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete sponsored_content"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting sponsored_content: {str(e)}")
            raise
