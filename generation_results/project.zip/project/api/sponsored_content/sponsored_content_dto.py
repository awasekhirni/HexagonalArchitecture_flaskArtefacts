from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Sponsored_contentStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Sponsored_contentBase(BaseModel):
    """Base schema for sponsored_content"""
    pass

class Sponsored_contentCreate(Sponsored_contentBase):
    """Schema for creating sponsored_content"""
    name: str
    description: Optional[str] = None
    status: Sponsored_contentStatus = Sponsored_contentStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Sponsored_contentUpdate(Sponsored_contentBase):
    """Schema for updating sponsored_content"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Sponsored_contentStatus] = None

class Sponsored_contentResponse(Sponsored_contentBase):
    """Response schema for sponsored_content"""
    id: str
    name: str
    description: Optional[str] = None
    status: Sponsored_contentStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_sponsored_content_create(data: Sponsored_contentCreate) -> Sponsored_contentCreate:
    """Validate sponsored_content creation data"""
    return data

def validate_sponsored_content_update(data: Sponsored_contentUpdate) -> Sponsored_contentUpdate:
    """Validate sponsored_content update data"""
    return data
