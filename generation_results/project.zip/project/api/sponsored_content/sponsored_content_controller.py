from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.sponsored_content.sponsored_content_entity import Sponsored_content
from domain.sponsored_content.sponsored_content_service_interface import IAsyncSponsored_contentService
from api.dtos.sponsored_content_dto import Sponsored_contentCreate, Sponsored_contentUpdate, Sponsored_contentResponse
from api.mappers.sponsored_content_mapper import sponsored_content_mapper
from api.validations.sponsored_content_validation_schemas import validate_sponsored_content_create, validate_sponsored_content_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('sponsored_content', description='Sponsored_content operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
sponsored_content_create_model = api.model('Sponsored_contentCreate', {
    'name': fields.String(required=True, description='sponsored_content name'),
    'description': fields.String(description='sponsored_content description'),
    'status': fields.String(description='sponsored_content status', enum=['active', 'inactive', 'pending'])
})

sponsored_content_update_model = api.model('Sponsored_contentUpdate', {
    'name': fields.String(description='sponsored_content name'),
    'description': fields.String(description='sponsored_content description'),
    'status': fields.String(description='sponsored_content status', enum=['active', 'inactive', 'pending'])
})

sponsored_content_response_model = api.model('Sponsored_contentResponse', {
    'id': fields.String(description='sponsored_content ID'),
    'name': fields.String(description='sponsored_content name'),
    'description': fields.String(description='sponsored_content description'),
    'status': fields.String(description='sponsored_content status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncSponsored_contentService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Sponsored_contentList(Resource):
        @api.doc('list_sponsored_contents')
        @api.expect(pagination_parser)
        @api.marshal_list_with(sponsored_content_response_model)
        @token_required
        async def get(self):
            """List all sponsored_contents"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [sponsored_content_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting sponsored_contents: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_sponsored_content')
        @api.expect(sponsored_content_create_model)
        @api.marshal_with(sponsored_content_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new sponsored_content"""
            try:
                data = api.payload
                validated_data = validate_sponsored_content_create(data)
                entity = sponsored_content_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return sponsored_content_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating sponsored_content: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The sponsored_content identifier')
    @api.response(404, 'Sponsored_content not found')
    class Sponsored_contentResource(Resource):
        @api.doc('get_sponsored_content')
        @api.marshal_with(sponsored_content_response_model)
        @token_required
        async def get(self, id):
            """Get a sponsored_content given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Sponsored_content not found")
                return sponsored_content_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting sponsored_content {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_sponsored_content')
        @api.expect(sponsored_content_update_model)
        @api.marshal_with(sponsored_content_response_model)
        @token_required
        async def put(self, id):
            """Update a sponsored_content given its identifier"""
            try:
                data = api.payload
                validated_data = validate_sponsored_content_update(data)
                entity = sponsored_content_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Sponsored_content not found")
                return sponsored_content_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating sponsored_content {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_sponsored_content')
        @api.response(204, 'Sponsored_content deleted')
        @token_required
        async def delete(self, id):
            """Delete a sponsored_content given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Sponsored_content not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting sponsored_content {id}: {str(e)}")
                api.abort(400, str(e))

    return api
