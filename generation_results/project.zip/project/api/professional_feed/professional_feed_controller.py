from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.professional_feed.professional_feed_entity import Professional_feed
from domain.professional_feed.professional_feed_service_interface import IAsyncProfessional_feedService
from api.dtos.professional_feed_dto import Professional_feedCreate, Professional_feedUpdate, Professional_feedResponse
from api.mappers.professional_feed_mapper import professional_feed_mapper
from api.validations.professional_feed_validation_schemas import validate_professional_feed_create, validate_professional_feed_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('professional_feed', description='Professional_feed operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
professional_feed_create_model = api.model('Professional_feedCreate', {
    'name': fields.String(required=True, description='professional_feed name'),
    'description': fields.String(description='professional_feed description'),
    'status': fields.String(description='professional_feed status', enum=['active', 'inactive', 'pending'])
})

professional_feed_update_model = api.model('Professional_feedUpdate', {
    'name': fields.String(description='professional_feed name'),
    'description': fields.String(description='professional_feed description'),
    'status': fields.String(description='professional_feed status', enum=['active', 'inactive', 'pending'])
})

professional_feed_response_model = api.model('Professional_feedResponse', {
    'id': fields.String(description='professional_feed ID'),
    'name': fields.String(description='professional_feed name'),
    'description': fields.String(description='professional_feed description'),
    'status': fields.String(description='professional_feed status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProfessional_feedService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Professional_feedList(Resource):
        @api.doc('list_professional_feeds')
        @api.expect(pagination_parser)
        @api.marshal_list_with(professional_feed_response_model)
        @token_required
        async def get(self):
            """List all professional_feeds"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [professional_feed_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting professional_feeds: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_professional_feed')
        @api.expect(professional_feed_create_model)
        @api.marshal_with(professional_feed_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new professional_feed"""
            try:
                data = api.payload
                validated_data = validate_professional_feed_create(data)
                entity = professional_feed_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return professional_feed_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating professional_feed: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The professional_feed identifier')
    @api.response(404, 'Professional_feed not found')
    class Professional_feedResource(Resource):
        @api.doc('get_professional_feed')
        @api.marshal_with(professional_feed_response_model)
        @token_required
        async def get(self, id):
            """Get a professional_feed given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Professional_feed not found")
                return professional_feed_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting professional_feed {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_professional_feed')
        @api.expect(professional_feed_update_model)
        @api.marshal_with(professional_feed_response_model)
        @token_required
        async def put(self, id):
            """Update a professional_feed given its identifier"""
            try:
                data = api.payload
                validated_data = validate_professional_feed_update(data)
                entity = professional_feed_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Professional_feed not found")
                return professional_feed_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating professional_feed {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_professional_feed')
        @api.response(204, 'Professional_feed deleted')
        @token_required
        async def delete(self, id):
            """Delete a professional_feed given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Professional_feed not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting professional_feed {id}: {str(e)}")
                api.abort(400, str(e))

    return api
