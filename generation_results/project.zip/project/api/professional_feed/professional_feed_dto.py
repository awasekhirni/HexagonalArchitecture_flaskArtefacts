from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Professional_feedStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Professional_feedBase(BaseModel):
    """Base schema for professional_feed"""
    pass

class Professional_feedCreate(Professional_feedBase):
    """Schema for creating professional_feed"""
    name: str
    description: Optional[str] = None
    status: Professional_feedStatus = Professional_feedStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Professional_feedUpdate(Professional_feedBase):
    """Schema for updating professional_feed"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Professional_feedStatus] = None

class Professional_feedResponse(Professional_feedBase):
    """Response schema for professional_feed"""
    id: str
    name: str
    description: Optional[str] = None
    status: Professional_feedStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_professional_feed_create(data: Professional_feedCreate) -> Professional_feedCreate:
    """Validate professional_feed creation data"""
    return data

def validate_professional_feed_update(data: Professional_feedUpdate) -> Professional_feedUpdate:
    """Validate professional_feed update data"""
    return data
