from typing import List, Optional
from domain.professional_feed.professional_feed_entity import Professional_feed
from domain.professional_feed.professional_feed_service_interface import IAsyncProfessional_feedService
from infrastructure.repositories.professional_feed.professional_feed_repository import Professional_feedRepository
from api.mappers.professional_feed_mapper import professional_feed_mapper
from shared.utils.logger import logger

class Professional_feedService(IAsyncProfessional_feedService):
    """Service implementation for Professional_feed"""

    def __init__(self):
        self.repository = Professional_feedRepository()

    async def get_by_id(self, id: str) -> Optional[Professional_feed]:
        """Get professional_feed by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting professional_feed by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Professional_feed]:
        """Get all professional_feeds"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all professional_feeds: {str(e)}")
            raise

    async def create(self, data: Professional_feed) -> Professional_feed:
        """Create new professional_feed"""
        try:
            return await self.repository.create(professional_feed_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating professional_feed: {str(e)}")
            raise

    async def update(self, id: str, data: Professional_feed) -> Optional[Professional_feed]:
        """Update professional_feed"""
        try:
            return await self.repository.update(id, professional_feed_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating professional_feed: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete professional_feed"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting professional_feed: {str(e)}")
            raise
