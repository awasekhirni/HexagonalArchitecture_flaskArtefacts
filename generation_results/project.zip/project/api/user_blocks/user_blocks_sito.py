from typing import List, Optional
from domain.user_blocks.user_blocks_entity import User_blocks
from domain.user_blocks.user_blocks_service_interface import IAsyncUser_blocksService
from infrastructure.repositories.user_blocks.user_blocks_repository import User_blocksRepository
from api.mappers.user_blocks_mapper import user_blocks_mapper
from shared.utils.logger import logger

class User_blocksService(IAsyncUser_blocksService):
    """Service implementation for User_blocks"""

    def __init__(self):
        self.repository = User_blocksRepository()

    async def get_by_id(self, id: str) -> Optional[User_blocks]:
        """Get user_blocks by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_blocks by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_blocks]:
        """Get all user_blockss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_blockss: {str(e)}")
            raise

    async def create(self, data: User_blocks) -> User_blocks:
        """Create new user_blocks"""
        try:
            return await self.repository.create(user_blocks_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_blocks: {str(e)}")
            raise

    async def update(self, id: str, data: User_blocks) -> Optional[User_blocks]:
        """Update user_blocks"""
        try:
            return await self.repository.update(id, user_blocks_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_blocks: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_blocks"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_blocks: {str(e)}")
            raise
