from domain.user_blocks.user_blocks_entity import User_blocks
from api.dtos.user_blocks_dto import User_blocksCreate, User_blocksUpdate, User_blocksResponse
from typing import Union

class User_blocksMapper:
    """Mapper for User_blocks between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_blocks) -> User_blocksResponse:
        """Convert entity to response DTO"""
        return User_blocksResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_blocksCreate, User_blocksUpdate]) -> User_blocks:
        """Convert DTO to entity"""
        return User_blocks(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_blocks, dto: User_blocksUpdate) -> User_blocks:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_blocks_mapper = User_blocksMapper()
