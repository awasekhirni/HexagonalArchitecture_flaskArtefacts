from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_blocksStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_blocksBase(BaseModel):
    """Base schema for user_blocks"""
    pass

class User_blocksCreate(User_blocksBase):
    """Schema for creating user_blocks"""
    name: str
    description: Optional[str] = None
    status: User_blocksStatus = User_blocksStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_blocksUpdate(User_blocksBase):
    """Schema for updating user_blocks"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_blocksStatus] = None

class User_blocksResponse(User_blocksBase):
    """Response schema for user_blocks"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_blocksStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_blocks_create(data: User_blocksCreate) -> User_blocksCreate:
    """Validate user_blocks creation data"""
    return data

def validate_user_blocks_update(data: User_blocksUpdate) -> User_blocksUpdate:
    """Validate user_blocks update data"""
    return data
