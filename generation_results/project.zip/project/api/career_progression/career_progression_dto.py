from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Career_progressionStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Career_progressionBase(BaseModel):
    """Base schema for career_progression"""
    pass

class Career_progressionCreate(Career_progressionBase):
    """Schema for creating career_progression"""
    name: str
    description: Optional[str] = None
    status: Career_progressionStatus = Career_progressionStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Career_progressionUpdate(Career_progressionBase):
    """Schema for updating career_progression"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Career_progressionStatus] = None

class Career_progressionResponse(Career_progressionBase):
    """Response schema for career_progression"""
    id: str
    name: str
    description: Optional[str] = None
    status: Career_progressionStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_career_progression_create(data: Career_progressionCreate) -> Career_progressionCreate:
    """Validate career_progression creation data"""
    return data

def validate_career_progression_update(data: Career_progressionUpdate) -> Career_progressionUpdate:
    """Validate career_progression update data"""
    return data
