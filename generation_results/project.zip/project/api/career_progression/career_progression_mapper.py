from domain.career_progression.career_progression_entity import Career_progression
from api.dtos.career_progression_dto import Career_progressionCreate, Career_progressionUpdate, Career_progressionResponse
from typing import Union

class Career_progressionMapper:
    """Mapper for Career_progression between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Career_progression) -> Career_progressionResponse:
        """Convert entity to response DTO"""
        return Career_progressionResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Career_progressionCreate, Career_progressionUpdate]) -> Career_progression:
        """Convert DTO to entity"""
        return Career_progression(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Career_progression, dto: Career_progressionUpdate) -> Career_progression:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

career_progression_mapper = Career_progressionMapper()
