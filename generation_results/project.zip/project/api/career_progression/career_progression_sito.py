from typing import List, Optional
from domain.career_progression.career_progression_entity import Career_progression
from domain.career_progression.career_progression_service_interface import IAsyncCareer_progressionService
from infrastructure.repositories.career_progression.career_progression_repository import Career_progressionRepository
from api.mappers.career_progression_mapper import career_progression_mapper
from shared.utils.logger import logger

class Career_progressionService(IAsyncCareer_progressionService):
    """Service implementation for Career_progression"""

    def __init__(self):
        self.repository = Career_progressionRepository()

    async def get_by_id(self, id: str) -> Optional[Career_progression]:
        """Get career_progression by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting career_progression by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Career_progression]:
        """Get all career_progressions"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all career_progressions: {str(e)}")
            raise

    async def create(self, data: Career_progression) -> Career_progression:
        """Create new career_progression"""
        try:
            return await self.repository.create(career_progression_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating career_progression: {str(e)}")
            raise

    async def update(self, id: str, data: Career_progression) -> Optional[Career_progression]:
        """Update career_progression"""
        try:
            return await self.repository.update(id, career_progression_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating career_progression: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete career_progression"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting career_progression: {str(e)}")
            raise
