from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.career_progression.career_progression_entity import Career_progression
from domain.career_progression.career_progression_service_interface import IAsyncCareer_progressionService
from api.dtos.career_progression_dto import Career_progressionCreate, Career_progressionUpdate, Career_progressionResponse
from api.mappers.career_progression_mapper import career_progression_mapper
from api.validations.career_progression_validation_schemas import validate_career_progression_create, validate_career_progression_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('career_progression', description='Career_progression operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
career_progression_create_model = api.model('Career_progressionCreate', {
    'name': fields.String(required=True, description='career_progression name'),
    'description': fields.String(description='career_progression description'),
    'status': fields.String(description='career_progression status', enum=['active', 'inactive', 'pending'])
})

career_progression_update_model = api.model('Career_progressionUpdate', {
    'name': fields.String(description='career_progression name'),
    'description': fields.String(description='career_progression description'),
    'status': fields.String(description='career_progression status', enum=['active', 'inactive', 'pending'])
})

career_progression_response_model = api.model('Career_progressionResponse', {
    'id': fields.String(description='career_progression ID'),
    'name': fields.String(description='career_progression name'),
    'description': fields.String(description='career_progression description'),
    'status': fields.String(description='career_progression status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncCareer_progressionService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Career_progressionList(Resource):
        @api.doc('list_career_progressions')
        @api.expect(pagination_parser)
        @api.marshal_list_with(career_progression_response_model)
        @token_required
        async def get(self):
            """List all career_progressions"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [career_progression_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting career_progressions: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_career_progression')
        @api.expect(career_progression_create_model)
        @api.marshal_with(career_progression_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new career_progression"""
            try:
                data = api.payload
                validated_data = validate_career_progression_create(data)
                entity = career_progression_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return career_progression_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating career_progression: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The career_progression identifier')
    @api.response(404, 'Career_progression not found')
    class Career_progressionResource(Resource):
        @api.doc('get_career_progression')
        @api.marshal_with(career_progression_response_model)
        @token_required
        async def get(self, id):
            """Get a career_progression given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Career_progression not found")
                return career_progression_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting career_progression {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_career_progression')
        @api.expect(career_progression_update_model)
        @api.marshal_with(career_progression_response_model)
        @token_required
        async def put(self, id):
            """Update a career_progression given its identifier"""
            try:
                data = api.payload
                validated_data = validate_career_progression_update(data)
                entity = career_progression_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Career_progression not found")
                return career_progression_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating career_progression {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_career_progression')
        @api.response(204, 'Career_progression deleted')
        @token_required
        async def delete(self, id):
            """Delete a career_progression given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Career_progression not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting career_progression {id}: {str(e)}")
                api.abort(400, str(e))

    return api
