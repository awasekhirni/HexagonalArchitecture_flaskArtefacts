from domain.review_tags.review_tags_entity import Review_tags
from api.dtos.review_tags_dto import Review_tagsCreate, Review_tagsUpdate, Review_tagsResponse
from typing import Union

class Review_tagsMapper:
    """Mapper for Review_tags between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Review_tags) -> Review_tagsResponse:
        """Convert entity to response DTO"""
        return Review_tagsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Review_tagsCreate, Review_tagsUpdate]) -> Review_tags:
        """Convert DTO to entity"""
        return Review_tags(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Review_tags, dto: Review_tagsUpdate) -> Review_tags:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

review_tags_mapper = Review_tagsMapper()
