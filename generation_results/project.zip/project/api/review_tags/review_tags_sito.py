from typing import List, Optional
from domain.review_tags.review_tags_entity import Review_tags
from domain.review_tags.review_tags_service_interface import IAsyncReview_tagsService
from infrastructure.repositories.review_tags.review_tags_repository import Review_tagsRepository
from api.mappers.review_tags_mapper import review_tags_mapper
from shared.utils.logger import logger

class Review_tagsService(IAsyncReview_tagsService):
    """Service implementation for Review_tags"""

    def __init__(self):
        self.repository = Review_tagsRepository()

    async def get_by_id(self, id: str) -> Optional[Review_tags]:
        """Get review_tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting review_tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Review_tags]:
        """Get all review_tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all review_tagss: {str(e)}")
            raise

    async def create(self, data: Review_tags) -> Review_tags:
        """Create new review_tags"""
        try:
            return await self.repository.create(review_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating review_tags: {str(e)}")
            raise

    async def update(self, id: str, data: Review_tags) -> Optional[Review_tags]:
        """Update review_tags"""
        try:
            return await self.repository.update(id, review_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating review_tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete review_tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting review_tags: {str(e)}")
            raise
