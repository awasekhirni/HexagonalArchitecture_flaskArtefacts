from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.review_tags.review_tags_entity import Review_tags
from domain.review_tags.review_tags_service_interface import IAsyncReview_tagsService
from api.dtos.review_tags_dto import Review_tagsCreate, Review_tagsUpdate, Review_tagsResponse
from api.mappers.review_tags_mapper import review_tags_mapper
from api.validations.review_tags_validation_schemas import validate_review_tags_create, validate_review_tags_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('review_tags', description='Review_tags operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
review_tags_create_model = api.model('Review_tagsCreate', {
    'name': fields.String(required=True, description='review_tags name'),
    'description': fields.String(description='review_tags description'),
    'status': fields.String(description='review_tags status', enum=['active', 'inactive', 'pending'])
})

review_tags_update_model = api.model('Review_tagsUpdate', {
    'name': fields.String(description='review_tags name'),
    'description': fields.String(description='review_tags description'),
    'status': fields.String(description='review_tags status', enum=['active', 'inactive', 'pending'])
})

review_tags_response_model = api.model('Review_tagsResponse', {
    'id': fields.String(description='review_tags ID'),
    'name': fields.String(description='review_tags name'),
    'description': fields.String(description='review_tags description'),
    'status': fields.String(description='review_tags status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncReview_tagsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Review_tagsList(Resource):
        @api.doc('list_review_tagss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(review_tags_response_model)
        @token_required
        async def get(self):
            """List all review_tagss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [review_tags_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting review_tagss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_review_tags')
        @api.expect(review_tags_create_model)
        @api.marshal_with(review_tags_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new review_tags"""
            try:
                data = api.payload
                validated_data = validate_review_tags_create(data)
                entity = review_tags_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return review_tags_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating review_tags: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The review_tags identifier')
    @api.response(404, 'Review_tags not found')
    class Review_tagsResource(Resource):
        @api.doc('get_review_tags')
        @api.marshal_with(review_tags_response_model)
        @token_required
        async def get(self, id):
            """Get a review_tags given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Review_tags not found")
                return review_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting review_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_review_tags')
        @api.expect(review_tags_update_model)
        @api.marshal_with(review_tags_response_model)
        @token_required
        async def put(self, id):
            """Update a review_tags given its identifier"""
            try:
                data = api.payload
                validated_data = validate_review_tags_update(data)
                entity = review_tags_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Review_tags not found")
                return review_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating review_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_review_tags')
        @api.response(204, 'Review_tags deleted')
        @token_required
        async def delete(self, id):
            """Delete a review_tags given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Review_tags not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting review_tags {id}: {str(e)}")
                api.abort(400, str(e))

    return api
