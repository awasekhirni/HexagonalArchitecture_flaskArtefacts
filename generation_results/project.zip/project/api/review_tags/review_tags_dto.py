from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Review_tagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Review_tagsBase(BaseModel):
    """Base schema for review_tags"""
    pass

class Review_tagsCreate(Review_tagsBase):
    """Schema for creating review_tags"""
    name: str
    description: Optional[str] = None
    status: Review_tagsStatus = Review_tagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Review_tagsUpdate(Review_tagsBase):
    """Schema for updating review_tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Review_tagsStatus] = None

class Review_tagsResponse(Review_tagsBase):
    """Response schema for review_tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: Review_tagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_review_tags_create(data: Review_tagsCreate) -> Review_tagsCreate:
    """Validate review_tags creation data"""
    return data

def validate_review_tags_update(data: Review_tagsUpdate) -> Review_tagsUpdate:
    """Validate review_tags update data"""
    return data
