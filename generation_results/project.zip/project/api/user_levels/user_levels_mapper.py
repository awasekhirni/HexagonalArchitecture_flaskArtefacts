from domain.user_levels.user_levels_entity import User_levels
from api.dtos.user_levels_dto import User_levelsCreate, User_levelsUpdate, User_levelsResponse
from typing import Union

class User_levelsMapper:
    """Mapper for User_levels between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_levels) -> User_levelsResponse:
        """Convert entity to response DTO"""
        return User_levelsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_levelsCreate, User_levelsUpdate]) -> User_levels:
        """Convert DTO to entity"""
        return User_levels(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_levels, dto: User_levelsUpdate) -> User_levels:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_levels_mapper = User_levelsMapper()
