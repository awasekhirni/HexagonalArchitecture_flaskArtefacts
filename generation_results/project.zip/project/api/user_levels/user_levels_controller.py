from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_levels.user_levels_entity import User_levels
from domain.user_levels.user_levels_service_interface import IAsyncUser_levelsService
from api.dtos.user_levels_dto import User_levelsCreate, User_levelsUpdate, User_levelsResponse
from api.mappers.user_levels_mapper import user_levels_mapper
from api.validations.user_levels_validation_schemas import validate_user_levels_create, validate_user_levels_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_levels', description='User_levels operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_levels_create_model = api.model('User_levelsCreate', {
    'name': fields.String(required=True, description='user_levels name'),
    'description': fields.String(description='user_levels description'),
    'status': fields.String(description='user_levels status', enum=['active', 'inactive', 'pending'])
})

user_levels_update_model = api.model('User_levelsUpdate', {
    'name': fields.String(description='user_levels name'),
    'description': fields.String(description='user_levels description'),
    'status': fields.String(description='user_levels status', enum=['active', 'inactive', 'pending'])
})

user_levels_response_model = api.model('User_levelsResponse', {
    'id': fields.String(description='user_levels ID'),
    'name': fields.String(description='user_levels name'),
    'description': fields.String(description='user_levels description'),
    'status': fields.String(description='user_levels status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_levelsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_levelsList(Resource):
        @api.doc('list_user_levelss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_levels_response_model)
        @token_required
        async def get(self):
            """List all user_levelss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_levels_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_levelss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_levels')
        @api.expect(user_levels_create_model)
        @api.marshal_with(user_levels_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_levels"""
            try:
                data = api.payload
                validated_data = validate_user_levels_create(data)
                entity = user_levels_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_levels_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_levels: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_levels identifier')
    @api.response(404, 'User_levels not found')
    class User_levelsResource(Resource):
        @api.doc('get_user_levels')
        @api.marshal_with(user_levels_response_model)
        @token_required
        async def get(self, id):
            """Get a user_levels given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_levels not found")
                return user_levels_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_levels {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_levels')
        @api.expect(user_levels_update_model)
        @api.marshal_with(user_levels_response_model)
        @token_required
        async def put(self, id):
            """Update a user_levels given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_levels_update(data)
                entity = user_levels_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_levels not found")
                return user_levels_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_levels {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_levels')
        @api.response(204, 'User_levels deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_levels given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_levels not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_levels {id}: {str(e)}")
                api.abort(400, str(e))

    return api
