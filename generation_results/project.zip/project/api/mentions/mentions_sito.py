from typing import List, Optional
from domain.mentions.mentions_entity import Mentions
from domain.mentions.mentions_service_interface import IAsyncMentionsService
from infrastructure.repositories.mentions.mentions_repository import MentionsRepository
from api.mappers.mentions_mapper import mentions_mapper
from shared.utils.logger import logger

class MentionsService(IAsyncMentionsService):
    """Service implementation for Mentions"""

    def __init__(self):
        self.repository = MentionsRepository()

    async def get_by_id(self, id: str) -> Optional[Mentions]:
        """Get mentions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting mentions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Mentions]:
        """Get all mentionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all mentionss: {str(e)}")
            raise

    async def create(self, data: Mentions) -> Mentions:
        """Create new mentions"""
        try:
            return await self.repository.create(mentions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating mentions: {str(e)}")
            raise

    async def update(self, id: str, data: Mentions) -> Optional[Mentions]:
        """Update mentions"""
        try:
            return await self.repository.update(id, mentions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating mentions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete mentions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting mentions: {str(e)}")
            raise
