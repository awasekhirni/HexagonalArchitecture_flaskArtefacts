from domain.mentions.mentions_entity import Mentions
from api.dtos.mentions_dto import MentionsCreate, MentionsUpdate, MentionsResponse
from typing import Union

class MentionsMapper:
    """Mapper for Mentions between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Mentions) -> MentionsResponse:
        """Convert entity to response DTO"""
        return MentionsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[MentionsCreate, MentionsUpdate]) -> Mentions:
        """Convert DTO to entity"""
        return Mentions(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Mentions, dto: MentionsUpdate) -> Mentions:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

mentions_mapper = MentionsMapper()
