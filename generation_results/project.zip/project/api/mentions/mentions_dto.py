from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class MentionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class MentionsBase(BaseModel):
    """Base schema for mentions"""
    pass

class MentionsCreate(MentionsBase):
    """Schema for creating mentions"""
    name: str
    description: Optional[str] = None
    status: MentionsStatus = MentionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class MentionsUpdate(MentionsBase):
    """Schema for updating mentions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[MentionsStatus] = None

class MentionsResponse(MentionsBase):
    """Response schema for mentions"""
    id: str
    name: str
    description: Optional[str] = None
    status: MentionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_mentions_create(data: MentionsCreate) -> MentionsCreate:
    """Validate mentions creation data"""
    return data

def validate_mentions_update(data: MentionsUpdate) -> MentionsUpdate:
    """Validate mentions update data"""
    return data
