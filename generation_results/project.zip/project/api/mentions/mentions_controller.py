from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.mentions.mentions_entity import Mentions
from domain.mentions.mentions_service_interface import IAsyncMentionsService
from api.dtos.mentions_dto import MentionsCreate, MentionsUpdate, MentionsResponse
from api.mappers.mentions_mapper import mentions_mapper
from api.validations.mentions_validation_schemas import validate_mentions_create, validate_mentions_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('mentions', description='Mentions operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
mentions_create_model = api.model('MentionsCreate', {
    'name': fields.String(required=True, description='mentions name'),
    'description': fields.String(description='mentions description'),
    'status': fields.String(description='mentions status', enum=['active', 'inactive', 'pending'])
})

mentions_update_model = api.model('MentionsUpdate', {
    'name': fields.String(description='mentions name'),
    'description': fields.String(description='mentions description'),
    'status': fields.String(description='mentions status', enum=['active', 'inactive', 'pending'])
})

mentions_response_model = api.model('MentionsResponse', {
    'id': fields.String(description='mentions ID'),
    'name': fields.String(description='mentions name'),
    'description': fields.String(description='mentions description'),
    'status': fields.String(description='mentions status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncMentionsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class MentionsList(Resource):
        @api.doc('list_mentionss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(mentions_response_model)
        @token_required
        async def get(self):
            """List all mentionss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [mentions_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting mentionss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_mentions')
        @api.expect(mentions_create_model)
        @api.marshal_with(mentions_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new mentions"""
            try:
                data = api.payload
                validated_data = validate_mentions_create(data)
                entity = mentions_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return mentions_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating mentions: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The mentions identifier')
    @api.response(404, 'Mentions not found')
    class MentionsResource(Resource):
        @api.doc('get_mentions')
        @api.marshal_with(mentions_response_model)
        @token_required
        async def get(self, id):
            """Get a mentions given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Mentions not found")
                return mentions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting mentions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_mentions')
        @api.expect(mentions_update_model)
        @api.marshal_with(mentions_response_model)
        @token_required
        async def put(self, id):
            """Update a mentions given its identifier"""
            try:
                data = api.payload
                validated_data = validate_mentions_update(data)
                entity = mentions_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Mentions not found")
                return mentions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating mentions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_mentions')
        @api.response(204, 'Mentions deleted')
        @token_required
        async def delete(self, id):
            """Delete a mentions given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Mentions not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting mentions {id}: {str(e)}")
                api.abort(400, str(e))

    return api
