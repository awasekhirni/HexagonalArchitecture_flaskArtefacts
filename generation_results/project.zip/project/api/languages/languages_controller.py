from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.languages.languages_entity import Languages
from domain.languages.languages_service_interface import IAsyncLanguagesService
from api.dtos.languages_dto import LanguagesCreate, LanguagesUpdate, LanguagesResponse
from api.mappers.languages_mapper import languages_mapper
from api.validations.languages_validation_schemas import validate_languages_create, validate_languages_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('languages', description='Languages operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
languages_create_model = api.model('LanguagesCreate', {
    'name': fields.String(required=True, description='languages name'),
    'description': fields.String(description='languages description'),
    'status': fields.String(description='languages status', enum=['active', 'inactive', 'pending'])
})

languages_update_model = api.model('LanguagesUpdate', {
    'name': fields.String(description='languages name'),
    'description': fields.String(description='languages description'),
    'status': fields.String(description='languages status', enum=['active', 'inactive', 'pending'])
})

languages_response_model = api.model('LanguagesResponse', {
    'id': fields.String(description='languages ID'),
    'name': fields.String(description='languages name'),
    'description': fields.String(description='languages description'),
    'status': fields.String(description='languages status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncLanguagesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class LanguagesList(Resource):
        @api.doc('list_languagess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(languages_response_model)
        @token_required
        async def get(self):
            """List all languagess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [languages_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting languagess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_languages')
        @api.expect(languages_create_model)
        @api.marshal_with(languages_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new languages"""
            try:
                data = api.payload
                validated_data = validate_languages_create(data)
                entity = languages_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return languages_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating languages: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The languages identifier')
    @api.response(404, 'Languages not found')
    class LanguagesResource(Resource):
        @api.doc('get_languages')
        @api.marshal_with(languages_response_model)
        @token_required
        async def get(self, id):
            """Get a languages given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Languages not found")
                return languages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting languages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_languages')
        @api.expect(languages_update_model)
        @api.marshal_with(languages_response_model)
        @token_required
        async def put(self, id):
            """Update a languages given its identifier"""
            try:
                data = api.payload
                validated_data = validate_languages_update(data)
                entity = languages_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Languages not found")
                return languages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating languages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_languages')
        @api.response(204, 'Languages deleted')
        @token_required
        async def delete(self, id):
            """Delete a languages given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Languages not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting languages {id}: {str(e)}")
                api.abort(400, str(e))

    return api
