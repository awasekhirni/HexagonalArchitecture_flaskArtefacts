from typing import List, Optional
from domain.languages.languages_entity import Languages
from domain.languages.languages_service_interface import IAsyncLanguagesService
from infrastructure.repositories.languages.languages_repository import LanguagesRepository
from api.mappers.languages_mapper import languages_mapper
from shared.utils.logger import logger

class LanguagesService(IAsyncLanguagesService):
    """Service implementation for Languages"""

    def __init__(self):
        self.repository = LanguagesRepository()

    async def get_by_id(self, id: str) -> Optional[Languages]:
        """Get languages by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting languages by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Languages]:
        """Get all languagess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all languagess: {str(e)}")
            raise

    async def create(self, data: Languages) -> Languages:
        """Create new languages"""
        try:
            return await self.repository.create(languages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating languages: {str(e)}")
            raise

    async def update(self, id: str, data: Languages) -> Optional[Languages]:
        """Update languages"""
        try:
            return await self.repository.update(id, languages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating languages: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete languages"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting languages: {str(e)}")
            raise
