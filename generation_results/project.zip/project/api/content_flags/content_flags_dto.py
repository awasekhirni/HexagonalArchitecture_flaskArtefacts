from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Content_flagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Content_flagsBase(BaseModel):
    """Base schema for content_flags"""
    pass

class Content_flagsCreate(Content_flagsBase):
    """Schema for creating content_flags"""
    name: str
    description: Optional[str] = None
    status: Content_flagsStatus = Content_flagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Content_flagsUpdate(Content_flagsBase):
    """Schema for updating content_flags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Content_flagsStatus] = None

class Content_flagsResponse(Content_flagsBase):
    """Response schema for content_flags"""
    id: str
    name: str
    description: Optional[str] = None
    status: Content_flagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_content_flags_create(data: Content_flagsCreate) -> Content_flagsCreate:
    """Validate content_flags creation data"""
    return data

def validate_content_flags_update(data: Content_flagsUpdate) -> Content_flagsUpdate:
    """Validate content_flags update data"""
    return data
