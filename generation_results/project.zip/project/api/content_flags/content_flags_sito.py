from typing import List, Optional
from domain.content_flags.content_flags_entity import Content_flags
from domain.content_flags.content_flags_service_interface import IAsyncContent_flagsService
from infrastructure.repositories.content_flags.content_flags_repository import Content_flagsRepository
from api.mappers.content_flags_mapper import content_flags_mapper
from shared.utils.logger import logger

class Content_flagsService(IAsyncContent_flagsService):
    """Service implementation for Content_flags"""

    def __init__(self):
        self.repository = Content_flagsRepository()

    async def get_by_id(self, id: str) -> Optional[Content_flags]:
        """Get content_flags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting content_flags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Content_flags]:
        """Get all content_flagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all content_flagss: {str(e)}")
            raise

    async def create(self, data: Content_flags) -> Content_flags:
        """Create new content_flags"""
        try:
            return await self.repository.create(content_flags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating content_flags: {str(e)}")
            raise

    async def update(self, id: str, data: Content_flags) -> Optional[Content_flags]:
        """Update content_flags"""
        try:
            return await self.repository.update(id, content_flags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating content_flags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete content_flags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting content_flags: {str(e)}")
            raise
