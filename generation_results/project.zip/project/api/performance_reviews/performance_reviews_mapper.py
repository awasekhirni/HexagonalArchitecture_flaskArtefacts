from domain.performance_reviews.performance_reviews_entity import Performance_reviews
from api.dtos.performance_reviews_dto import Performance_reviewsCreate, Performance_reviewsUpdate, Performance_reviewsResponse
from typing import Union

class Performance_reviewsMapper:
    """Mapper for Performance_reviews between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Performance_reviews) -> Performance_reviewsResponse:
        """Convert entity to response DTO"""
        return Performance_reviewsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Performance_reviewsCreate, Performance_reviewsUpdate]) -> Performance_reviews:
        """Convert DTO to entity"""
        return Performance_reviews(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Performance_reviews, dto: Performance_reviewsUpdate) -> Performance_reviews:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

performance_reviews_mapper = Performance_reviewsMapper()
