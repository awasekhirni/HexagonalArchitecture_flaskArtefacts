from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Performance_reviewsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Performance_reviewsBase(BaseModel):
    """Base schema for performance_reviews"""
    pass

class Performance_reviewsCreate(Performance_reviewsBase):
    """Schema for creating performance_reviews"""
    name: str
    description: Optional[str] = None
    status: Performance_reviewsStatus = Performance_reviewsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Performance_reviewsUpdate(Performance_reviewsBase):
    """Schema for updating performance_reviews"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Performance_reviewsStatus] = None

class Performance_reviewsResponse(Performance_reviewsBase):
    """Response schema for performance_reviews"""
    id: str
    name: str
    description: Optional[str] = None
    status: Performance_reviewsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_performance_reviews_create(data: Performance_reviewsCreate) -> Performance_reviewsCreate:
    """Validate performance_reviews creation data"""
    return data

def validate_performance_reviews_update(data: Performance_reviewsUpdate) -> Performance_reviewsUpdate:
    """Validate performance_reviews update data"""
    return data
