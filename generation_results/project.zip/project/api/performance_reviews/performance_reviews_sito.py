from typing import List, Optional
from domain.performance_reviews.performance_reviews_entity import Performance_reviews
from domain.performance_reviews.performance_reviews_service_interface import IAsyncPerformance_reviewsService
from infrastructure.repositories.performance_reviews.performance_reviews_repository import Performance_reviewsRepository
from api.mappers.performance_reviews_mapper import performance_reviews_mapper
from shared.utils.logger import logger

class Performance_reviewsService(IAsyncPerformance_reviewsService):
    """Service implementation for Performance_reviews"""

    def __init__(self):
        self.repository = Performance_reviewsRepository()

    async def get_by_id(self, id: str) -> Optional[Performance_reviews]:
        """Get performance_reviews by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting performance_reviews by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Performance_reviews]:
        """Get all performance_reviewss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all performance_reviewss: {str(e)}")
            raise

    async def create(self, data: Performance_reviews) -> Performance_reviews:
        """Create new performance_reviews"""
        try:
            return await self.repository.create(performance_reviews_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating performance_reviews: {str(e)}")
            raise

    async def update(self, id: str, data: Performance_reviews) -> Optional[Performance_reviews]:
        """Update performance_reviews"""
        try:
            return await self.repository.update(id, performance_reviews_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating performance_reviews: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete performance_reviews"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting performance_reviews: {str(e)}")
            raise
