from domain.regions.regions_entity import Regions
from api.dtos.regions_dto import RegionsCreate, RegionsUpdate, RegionsResponse
from typing import Union

class RegionsMapper:
    """Mapper for Regions between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Regions) -> RegionsResponse:
        """Convert entity to response DTO"""
        return RegionsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[RegionsCreate, RegionsUpdate]) -> Regions:
        """Convert DTO to entity"""
        return Regions(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Regions, dto: RegionsUpdate) -> Regions:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

regions_mapper = RegionsMapper()
