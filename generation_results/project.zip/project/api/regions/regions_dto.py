from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class RegionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class RegionsBase(BaseModel):
    """Base schema for regions"""
    pass

class RegionsCreate(RegionsBase):
    """Schema for creating regions"""
    name: str
    description: Optional[str] = None
    status: RegionsStatus = RegionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class RegionsUpdate(RegionsBase):
    """Schema for updating regions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[RegionsStatus] = None

class RegionsResponse(RegionsBase):
    """Response schema for regions"""
    id: str
    name: str
    description: Optional[str] = None
    status: RegionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_regions_create(data: RegionsCreate) -> RegionsCreate:
    """Validate regions creation data"""
    return data

def validate_regions_update(data: RegionsUpdate) -> RegionsUpdate:
    """Validate regions update data"""
    return data
