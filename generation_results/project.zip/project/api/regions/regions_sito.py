from typing import List, Optional
from domain.regions.regions_entity import Regions
from domain.regions.regions_service_interface import IAsyncRegionsService
from infrastructure.repositories.regions.regions_repository import RegionsRepository
from api.mappers.regions_mapper import regions_mapper
from shared.utils.logger import logger

class RegionsService(IAsyncRegionsService):
    """Service implementation for Regions"""

    def __init__(self):
        self.repository = RegionsRepository()

    async def get_by_id(self, id: str) -> Optional[Regions]:
        """Get regions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting regions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Regions]:
        """Get all regionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all regionss: {str(e)}")
            raise

    async def create(self, data: Regions) -> Regions:
        """Create new regions"""
        try:
            return await self.repository.create(regions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating regions: {str(e)}")
            raise

    async def update(self, id: str, data: Regions) -> Optional[Regions]:
        """Update regions"""
        try:
            return await self.repository.update(id, regions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating regions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete regions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting regions: {str(e)}")
            raise
