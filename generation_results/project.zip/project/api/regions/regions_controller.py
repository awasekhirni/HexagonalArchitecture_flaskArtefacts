from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.regions.regions_entity import Regions
from domain.regions.regions_service_interface import IAsyncRegionsService
from api.dtos.regions_dto import RegionsCreate, RegionsUpdate, RegionsResponse
from api.mappers.regions_mapper import regions_mapper
from api.validations.regions_validation_schemas import validate_regions_create, validate_regions_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('regions', description='Regions operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
regions_create_model = api.model('RegionsCreate', {
    'name': fields.String(required=True, description='regions name'),
    'description': fields.String(description='regions description'),
    'status': fields.String(description='regions status', enum=['active', 'inactive', 'pending'])
})

regions_update_model = api.model('RegionsUpdate', {
    'name': fields.String(description='regions name'),
    'description': fields.String(description='regions description'),
    'status': fields.String(description='regions status', enum=['active', 'inactive', 'pending'])
})

regions_response_model = api.model('RegionsResponse', {
    'id': fields.String(description='regions ID'),
    'name': fields.String(description='regions name'),
    'description': fields.String(description='regions description'),
    'status': fields.String(description='regions status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncRegionsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class RegionsList(Resource):
        @api.doc('list_regionss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(regions_response_model)
        @token_required
        async def get(self):
            """List all regionss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [regions_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting regionss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_regions')
        @api.expect(regions_create_model)
        @api.marshal_with(regions_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new regions"""
            try:
                data = api.payload
                validated_data = validate_regions_create(data)
                entity = regions_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return regions_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating regions: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The regions identifier')
    @api.response(404, 'Regions not found')
    class RegionsResource(Resource):
        @api.doc('get_regions')
        @api.marshal_with(regions_response_model)
        @token_required
        async def get(self, id):
            """Get a regions given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Regions not found")
                return regions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting regions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_regions')
        @api.expect(regions_update_model)
        @api.marshal_with(regions_response_model)
        @token_required
        async def put(self, id):
            """Update a regions given its identifier"""
            try:
                data = api.payload
                validated_data = validate_regions_update(data)
                entity = regions_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Regions not found")
                return regions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating regions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_regions')
        @api.response(204, 'Regions deleted')
        @token_required
        async def delete(self, id):
            """Delete a regions given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Regions not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting regions {id}: {str(e)}")
                api.abort(400, str(e))

    return api
