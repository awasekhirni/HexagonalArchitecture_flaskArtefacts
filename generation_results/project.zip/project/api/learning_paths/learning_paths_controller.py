from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.learning_paths.learning_paths_entity import Learning_paths
from domain.learning_paths.learning_paths_service_interface import IAsyncLearning_pathsService
from api.dtos.learning_paths_dto import Learning_pathsCreate, Learning_pathsUpdate, Learning_pathsResponse
from api.mappers.learning_paths_mapper import learning_paths_mapper
from api.validations.learning_paths_validation_schemas import validate_learning_paths_create, validate_learning_paths_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('learning_paths', description='Learning_paths operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
learning_paths_create_model = api.model('Learning_pathsCreate', {
    'name': fields.String(required=True, description='learning_paths name'),
    'description': fields.String(description='learning_paths description'),
    'status': fields.String(description='learning_paths status', enum=['active', 'inactive', 'pending'])
})

learning_paths_update_model = api.model('Learning_pathsUpdate', {
    'name': fields.String(description='learning_paths name'),
    'description': fields.String(description='learning_paths description'),
    'status': fields.String(description='learning_paths status', enum=['active', 'inactive', 'pending'])
})

learning_paths_response_model = api.model('Learning_pathsResponse', {
    'id': fields.String(description='learning_paths ID'),
    'name': fields.String(description='learning_paths name'),
    'description': fields.String(description='learning_paths description'),
    'status': fields.String(description='learning_paths status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncLearning_pathsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Learning_pathsList(Resource):
        @api.doc('list_learning_pathss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(learning_paths_response_model)
        @token_required
        async def get(self):
            """List all learning_pathss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [learning_paths_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting learning_pathss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_learning_paths')
        @api.expect(learning_paths_create_model)
        @api.marshal_with(learning_paths_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new learning_paths"""
            try:
                data = api.payload
                validated_data = validate_learning_paths_create(data)
                entity = learning_paths_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return learning_paths_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating learning_paths: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The learning_paths identifier')
    @api.response(404, 'Learning_paths not found')
    class Learning_pathsResource(Resource):
        @api.doc('get_learning_paths')
        @api.marshal_with(learning_paths_response_model)
        @token_required
        async def get(self, id):
            """Get a learning_paths given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Learning_paths not found")
                return learning_paths_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting learning_paths {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_learning_paths')
        @api.expect(learning_paths_update_model)
        @api.marshal_with(learning_paths_response_model)
        @token_required
        async def put(self, id):
            """Update a learning_paths given its identifier"""
            try:
                data = api.payload
                validated_data = validate_learning_paths_update(data)
                entity = learning_paths_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Learning_paths not found")
                return learning_paths_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating learning_paths {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_learning_paths')
        @api.response(204, 'Learning_paths deleted')
        @token_required
        async def delete(self, id):
            """Delete a learning_paths given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Learning_paths not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting learning_paths {id}: {str(e)}")
                api.abort(400, str(e))

    return api
