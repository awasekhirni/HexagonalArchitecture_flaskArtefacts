from typing import List, Optional
from domain.learning_paths.learning_paths_entity import Learning_paths
from domain.learning_paths.learning_paths_service_interface import IAsyncLearning_pathsService
from infrastructure.repositories.learning_paths.learning_paths_repository import Learning_pathsRepository
from api.mappers.learning_paths_mapper import learning_paths_mapper
from shared.utils.logger import logger

class Learning_pathsService(IAsyncLearning_pathsService):
    """Service implementation for Learning_paths"""

    def __init__(self):
        self.repository = Learning_pathsRepository()

    async def get_by_id(self, id: str) -> Optional[Learning_paths]:
        """Get learning_paths by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting learning_paths by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Learning_paths]:
        """Get all learning_pathss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all learning_pathss: {str(e)}")
            raise

    async def create(self, data: Learning_paths) -> Learning_paths:
        """Create new learning_paths"""
        try:
            return await self.repository.create(learning_paths_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating learning_paths: {str(e)}")
            raise

    async def update(self, id: str, data: Learning_paths) -> Optional[Learning_paths]:
        """Update learning_paths"""
        try:
            return await self.repository.update(id, learning_paths_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating learning_paths: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete learning_paths"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting learning_paths: {str(e)}")
            raise
