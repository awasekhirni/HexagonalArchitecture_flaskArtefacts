from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_resumesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_resumesBase(BaseModel):
    """Base schema for user_resumes"""
    pass

class User_resumesCreate(User_resumesBase):
    """Schema for creating user_resumes"""
    name: str
    description: Optional[str] = None
    status: User_resumesStatus = User_resumesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_resumesUpdate(User_resumesBase):
    """Schema for updating user_resumes"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_resumesStatus] = None

class User_resumesResponse(User_resumesBase):
    """Response schema for user_resumes"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_resumesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_resumes_create(data: User_resumesCreate) -> User_resumesCreate:
    """Validate user_resumes creation data"""
    return data

def validate_user_resumes_update(data: User_resumesUpdate) -> User_resumesUpdate:
    """Validate user_resumes update data"""
    return data
