from typing import List, Optional
from domain.user_resumes.user_resumes_entity import User_resumes
from domain.user_resumes.user_resumes_service_interface import IAsyncUser_resumesService
from infrastructure.repositories.user_resumes.user_resumes_repository import User_resumesRepository
from api.mappers.user_resumes_mapper import user_resumes_mapper
from shared.utils.logger import logger

class User_resumesService(IAsyncUser_resumesService):
    """Service implementation for User_resumes"""

    def __init__(self):
        self.repository = User_resumesRepository()

    async def get_by_id(self, id: str) -> Optional[User_resumes]:
        """Get user_resumes by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_resumes by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_resumes]:
        """Get all user_resumess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_resumess: {str(e)}")
            raise

    async def create(self, data: User_resumes) -> User_resumes:
        """Create new user_resumes"""
        try:
            return await self.repository.create(user_resumes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_resumes: {str(e)}")
            raise

    async def update(self, id: str, data: User_resumes) -> Optional[User_resumes]:
        """Update user_resumes"""
        try:
            return await self.repository.update(id, user_resumes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_resumes: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_resumes"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_resumes: {str(e)}")
            raise
