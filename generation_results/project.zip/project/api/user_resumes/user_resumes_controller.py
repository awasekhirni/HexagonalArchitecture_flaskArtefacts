from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_resumes.user_resumes_entity import User_resumes
from domain.user_resumes.user_resumes_service_interface import IAsyncUser_resumesService
from api.dtos.user_resumes_dto import User_resumesCreate, User_resumesUpdate, User_resumesResponse
from api.mappers.user_resumes_mapper import user_resumes_mapper
from api.validations.user_resumes_validation_schemas import validate_user_resumes_create, validate_user_resumes_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_resumes', description='User_resumes operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_resumes_create_model = api.model('User_resumesCreate', {
    'name': fields.String(required=True, description='user_resumes name'),
    'description': fields.String(description='user_resumes description'),
    'status': fields.String(description='user_resumes status', enum=['active', 'inactive', 'pending'])
})

user_resumes_update_model = api.model('User_resumesUpdate', {
    'name': fields.String(description='user_resumes name'),
    'description': fields.String(description='user_resumes description'),
    'status': fields.String(description='user_resumes status', enum=['active', 'inactive', 'pending'])
})

user_resumes_response_model = api.model('User_resumesResponse', {
    'id': fields.String(description='user_resumes ID'),
    'name': fields.String(description='user_resumes name'),
    'description': fields.String(description='user_resumes description'),
    'status': fields.String(description='user_resumes status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_resumesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_resumesList(Resource):
        @api.doc('list_user_resumess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_resumes_response_model)
        @token_required
        async def get(self):
            """List all user_resumess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_resumes_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_resumess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_resumes')
        @api.expect(user_resumes_create_model)
        @api.marshal_with(user_resumes_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_resumes"""
            try:
                data = api.payload
                validated_data = validate_user_resumes_create(data)
                entity = user_resumes_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_resumes_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_resumes: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_resumes identifier')
    @api.response(404, 'User_resumes not found')
    class User_resumesResource(Resource):
        @api.doc('get_user_resumes')
        @api.marshal_with(user_resumes_response_model)
        @token_required
        async def get(self, id):
            """Get a user_resumes given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_resumes not found")
                return user_resumes_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_resumes {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_resumes')
        @api.expect(user_resumes_update_model)
        @api.marshal_with(user_resumes_response_model)
        @token_required
        async def put(self, id):
            """Update a user_resumes given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_resumes_update(data)
                entity = user_resumes_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_resumes not found")
                return user_resumes_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_resumes {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_resumes')
        @api.response(204, 'User_resumes deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_resumes given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_resumes not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_resumes {id}: {str(e)}")
                api.abort(400, str(e))

    return api
