from domain.user_resumes.user_resumes_entity import User_resumes
from api.dtos.user_resumes_dto import User_resumesCreate, User_resumesUpdate, User_resumesResponse
from typing import Union

class User_resumesMapper:
    """Mapper for User_resumes between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_resumes) -> User_resumesResponse:
        """Convert entity to response DTO"""
        return User_resumesResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_resumesCreate, User_resumesUpdate]) -> User_resumes:
        """Convert DTO to entity"""
        return User_resumes(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_resumes, dto: User_resumesUpdate) -> User_resumes:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_resumes_mapper = User_resumesMapper()
