from typing import List, Optional
from domain.feedback.feedback_entity import Feedback
from domain.feedback.feedback_service_interface import IAsyncFeedbackService
from infrastructure.repositories.feedback.feedback_repository import FeedbackRepository
from api.mappers.feedback_mapper import feedback_mapper
from shared.utils.logger import logger

class FeedbackService(IAsyncFeedbackService):
    """Service implementation for Feedback"""

    def __init__(self):
        self.repository = FeedbackRepository()

    async def get_by_id(self, id: str) -> Optional[Feedback]:
        """Get feedback by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting feedback by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Feedback]:
        """Get all feedbacks"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all feedbacks: {str(e)}")
            raise

    async def create(self, data: Feedback) -> Feedback:
        """Create new feedback"""
        try:
            return await self.repository.create(feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating feedback: {str(e)}")
            raise

    async def update(self, id: str, data: Feedback) -> Optional[Feedback]:
        """Update feedback"""
        try:
            return await self.repository.update(id, feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating feedback: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete feedback"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting feedback: {str(e)}")
            raise
