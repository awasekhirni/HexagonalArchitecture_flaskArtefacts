from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.feedback.feedback_entity import Feedback
from domain.feedback.feedback_service_interface import IAsyncFeedbackService
from api.dtos.feedback_dto import FeedbackCreate, FeedbackUpdate, FeedbackResponse
from api.mappers.feedback_mapper import feedback_mapper
from api.validations.feedback_validation_schemas import validate_feedback_create, validate_feedback_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('feedback', description='Feedback operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
feedback_create_model = api.model('FeedbackCreate', {
    'name': fields.String(required=True, description='feedback name'),
    'description': fields.String(description='feedback description'),
    'status': fields.String(description='feedback status', enum=['active', 'inactive', 'pending'])
})

feedback_update_model = api.model('FeedbackUpdate', {
    'name': fields.String(description='feedback name'),
    'description': fields.String(description='feedback description'),
    'status': fields.String(description='feedback status', enum=['active', 'inactive', 'pending'])
})

feedback_response_model = api.model('FeedbackResponse', {
    'id': fields.String(description='feedback ID'),
    'name': fields.String(description='feedback name'),
    'description': fields.String(description='feedback description'),
    'status': fields.String(description='feedback status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncFeedbackService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class FeedbackList(Resource):
        @api.doc('list_feedbacks')
        @api.expect(pagination_parser)
        @api.marshal_list_with(feedback_response_model)
        @token_required
        async def get(self):
            """List all feedbacks"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [feedback_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting feedbacks: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_feedback')
        @api.expect(feedback_create_model)
        @api.marshal_with(feedback_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new feedback"""
            try:
                data = api.payload
                validated_data = validate_feedback_create(data)
                entity = feedback_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return feedback_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating feedback: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The feedback identifier')
    @api.response(404, 'Feedback not found')
    class FeedbackResource(Resource):
        @api.doc('get_feedback')
        @api.marshal_with(feedback_response_model)
        @token_required
        async def get(self, id):
            """Get a feedback given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Feedback not found")
                return feedback_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting feedback {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_feedback')
        @api.expect(feedback_update_model)
        @api.marshal_with(feedback_response_model)
        @token_required
        async def put(self, id):
            """Update a feedback given its identifier"""
            try:
                data = api.payload
                validated_data = validate_feedback_update(data)
                entity = feedback_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Feedback not found")
                return feedback_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating feedback {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_feedback')
        @api.response(204, 'Feedback deleted')
        @token_required
        async def delete(self, id):
            """Delete a feedback given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Feedback not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting feedback {id}: {str(e)}")
                api.abort(400, str(e))

    return api
