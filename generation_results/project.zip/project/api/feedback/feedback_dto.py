from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class FeedbackStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class FeedbackBase(BaseModel):
    """Base schema for feedback"""
    pass

class FeedbackCreate(FeedbackBase):
    """Schema for creating feedback"""
    name: str
    description: Optional[str] = None
    status: FeedbackStatus = FeedbackStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class FeedbackUpdate(FeedbackBase):
    """Schema for updating feedback"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[FeedbackStatus] = None

class FeedbackResponse(FeedbackBase):
    """Response schema for feedback"""
    id: str
    name: str
    description: Optional[str] = None
    status: FeedbackStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_feedback_create(data: FeedbackCreate) -> FeedbackCreate:
    """Validate feedback creation data"""
    return data

def validate_feedback_update(data: FeedbackUpdate) -> FeedbackUpdate:
    """Validate feedback update data"""
    return data
