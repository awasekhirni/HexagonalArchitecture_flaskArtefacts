from domain.job_applications.job_applications_entity import Job_applications
from api.dtos.job_applications_dto import Job_applicationsCreate, Job_applicationsUpdate, Job_applicationsResponse
from typing import Union

class Job_applicationsMapper:
    """Mapper for Job_applications between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Job_applications) -> Job_applicationsResponse:
        """Convert entity to response DTO"""
        return Job_applicationsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Job_applicationsCreate, Job_applicationsUpdate]) -> Job_applications:
        """Convert DTO to entity"""
        return Job_applications(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Job_applications, dto: Job_applicationsUpdate) -> Job_applications:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

job_applications_mapper = Job_applicationsMapper()
