from typing import List, Optional
from domain.job_applications.job_applications_entity import Job_applications
from domain.job_applications.job_applications_service_interface import IAsyncJob_applicationsService
from infrastructure.repositories.job_applications.job_applications_repository import Job_applicationsRepository
from api.mappers.job_applications_mapper import job_applications_mapper
from shared.utils.logger import logger

class Job_applicationsService(IAsyncJob_applicationsService):
    """Service implementation for Job_applications"""

    def __init__(self):
        self.repository = Job_applicationsRepository()

    async def get_by_id(self, id: str) -> Optional[Job_applications]:
        """Get job_applications by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_applications by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_applications]:
        """Get all job_applicationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_applicationss: {str(e)}")
            raise

    async def create(self, data: Job_applications) -> Job_applications:
        """Create new job_applications"""
        try:
            return await self.repository.create(job_applications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_applications: {str(e)}")
            raise

    async def update(self, id: str, data: Job_applications) -> Optional[Job_applications]:
        """Update job_applications"""
        try:
            return await self.repository.update(id, job_applications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_applications: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_applications"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_applications: {str(e)}")
            raise
