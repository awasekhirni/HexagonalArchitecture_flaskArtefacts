from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_applicationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_applicationsBase(BaseModel):
    """Base schema for job_applications"""
    pass

class Job_applicationsCreate(Job_applicationsBase):
    """Schema for creating job_applications"""
    name: str
    description: Optional[str] = None
    status: Job_applicationsStatus = Job_applicationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_applicationsUpdate(Job_applicationsBase):
    """Schema for updating job_applications"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_applicationsStatus] = None

class Job_applicationsResponse(Job_applicationsBase):
    """Response schema for job_applications"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_applicationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_applications_create(data: Job_applicationsCreate) -> Job_applicationsCreate:
    """Validate job_applications creation data"""
    return data

def validate_job_applications_update(data: Job_applicationsUpdate) -> Job_applicationsUpdate:
    """Validate job_applications update data"""
    return data
