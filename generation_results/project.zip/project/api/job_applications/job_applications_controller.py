from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.job_applications.job_applications_entity import Job_applications
from domain.job_applications.job_applications_service_interface import IAsyncJob_applicationsService
from api.dtos.job_applications_dto import Job_applicationsCreate, Job_applicationsUpdate, Job_applicationsResponse
from api.mappers.job_applications_mapper import job_applications_mapper
from api.validations.job_applications_validation_schemas import validate_job_applications_create, validate_job_applications_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('job_applications', description='Job_applications operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
job_applications_create_model = api.model('Job_applicationsCreate', {
    'name': fields.String(required=True, description='job_applications name'),
    'description': fields.String(description='job_applications description'),
    'status': fields.String(description='job_applications status', enum=['active', 'inactive', 'pending'])
})

job_applications_update_model = api.model('Job_applicationsUpdate', {
    'name': fields.String(description='job_applications name'),
    'description': fields.String(description='job_applications description'),
    'status': fields.String(description='job_applications status', enum=['active', 'inactive', 'pending'])
})

job_applications_response_model = api.model('Job_applicationsResponse', {
    'id': fields.String(description='job_applications ID'),
    'name': fields.String(description='job_applications name'),
    'description': fields.String(description='job_applications description'),
    'status': fields.String(description='job_applications status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncJob_applicationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Job_applicationsList(Resource):
        @api.doc('list_job_applicationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(job_applications_response_model)
        @token_required
        async def get(self):
            """List all job_applicationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [job_applications_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting job_applicationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_job_applications')
        @api.expect(job_applications_create_model)
        @api.marshal_with(job_applications_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new job_applications"""
            try:
                data = api.payload
                validated_data = validate_job_applications_create(data)
                entity = job_applications_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return job_applications_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating job_applications: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The job_applications identifier')
    @api.response(404, 'Job_applications not found')
    class Job_applicationsResource(Resource):
        @api.doc('get_job_applications')
        @api.marshal_with(job_applications_response_model)
        @token_required
        async def get(self, id):
            """Get a job_applications given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Job_applications not found")
                return job_applications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting job_applications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_job_applications')
        @api.expect(job_applications_update_model)
        @api.marshal_with(job_applications_response_model)
        @token_required
        async def put(self, id):
            """Update a job_applications given its identifier"""
            try:
                data = api.payload
                validated_data = validate_job_applications_update(data)
                entity = job_applications_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Job_applications not found")
                return job_applications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating job_applications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_job_applications')
        @api.response(204, 'Job_applications deleted')
        @token_required
        async def delete(self, id):
            """Delete a job_applications given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Job_applications not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting job_applications {id}: {str(e)}")
                api.abort(400, str(e))

    return api
