from domain.content_creator_monetization.content_creator_monetization_entity import Content_creator_monetization
from api.dtos.content_creator_monetization_dto import Content_creator_monetizationCreate, Content_creator_monetizationUpdate, Content_creator_monetizationResponse
from typing import Union

class Content_creator_monetizationMapper:
    """Mapper for Content_creator_monetization between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Content_creator_monetization) -> Content_creator_monetizationResponse:
        """Convert entity to response DTO"""
        return Content_creator_monetizationResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Content_creator_monetizationCreate, Content_creator_monetizationUpdate]) -> Content_creator_monetization:
        """Convert DTO to entity"""
        return Content_creator_monetization(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Content_creator_monetization, dto: Content_creator_monetizationUpdate) -> Content_creator_monetization:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

content_creator_monetization_mapper = Content_creator_monetizationMapper()
