from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.content_creator_monetization.content_creator_monetization_entity import Content_creator_monetization
from domain.content_creator_monetization.content_creator_monetization_service_interface import IAsyncContent_creator_monetizationService
from api.dtos.content_creator_monetization_dto import Content_creator_monetizationCreate, Content_creator_monetizationUpdate, Content_creator_monetizationResponse
from api.mappers.content_creator_monetization_mapper import content_creator_monetization_mapper
from api.validations.content_creator_monetization_validation_schemas import validate_content_creator_monetization_create, validate_content_creator_monetization_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('content_creator_monetization', description='Content_creator_monetization operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
content_creator_monetization_create_model = api.model('Content_creator_monetizationCreate', {
    'name': fields.String(required=True, description='content_creator_monetization name'),
    'description': fields.String(description='content_creator_monetization description'),
    'status': fields.String(description='content_creator_monetization status', enum=['active', 'inactive', 'pending'])
})

content_creator_monetization_update_model = api.model('Content_creator_monetizationUpdate', {
    'name': fields.String(description='content_creator_monetization name'),
    'description': fields.String(description='content_creator_monetization description'),
    'status': fields.String(description='content_creator_monetization status', enum=['active', 'inactive', 'pending'])
})

content_creator_monetization_response_model = api.model('Content_creator_monetizationResponse', {
    'id': fields.String(description='content_creator_monetization ID'),
    'name': fields.String(description='content_creator_monetization name'),
    'description': fields.String(description='content_creator_monetization description'),
    'status': fields.String(description='content_creator_monetization status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncContent_creator_monetizationService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Content_creator_monetizationList(Resource):
        @api.doc('list_content_creator_monetizations')
        @api.expect(pagination_parser)
        @api.marshal_list_with(content_creator_monetization_response_model)
        @token_required
        async def get(self):
            """List all content_creator_monetizations"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [content_creator_monetization_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting content_creator_monetizations: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_content_creator_monetization')
        @api.expect(content_creator_monetization_create_model)
        @api.marshal_with(content_creator_monetization_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new content_creator_monetization"""
            try:
                data = api.payload
                validated_data = validate_content_creator_monetization_create(data)
                entity = content_creator_monetization_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return content_creator_monetization_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating content_creator_monetization: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The content_creator_monetization identifier')
    @api.response(404, 'Content_creator_monetization not found')
    class Content_creator_monetizationResource(Resource):
        @api.doc('get_content_creator_monetization')
        @api.marshal_with(content_creator_monetization_response_model)
        @token_required
        async def get(self, id):
            """Get a content_creator_monetization given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Content_creator_monetization not found")
                return content_creator_monetization_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting content_creator_monetization {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_content_creator_monetization')
        @api.expect(content_creator_monetization_update_model)
        @api.marshal_with(content_creator_monetization_response_model)
        @token_required
        async def put(self, id):
            """Update a content_creator_monetization given its identifier"""
            try:
                data = api.payload
                validated_data = validate_content_creator_monetization_update(data)
                entity = content_creator_monetization_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Content_creator_monetization not found")
                return content_creator_monetization_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating content_creator_monetization {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_content_creator_monetization')
        @api.response(204, 'Content_creator_monetization deleted')
        @token_required
        async def delete(self, id):
            """Delete a content_creator_monetization given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Content_creator_monetization not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting content_creator_monetization {id}: {str(e)}")
                api.abort(400, str(e))

    return api
