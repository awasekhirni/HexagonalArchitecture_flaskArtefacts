from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Content_creator_monetizationStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Content_creator_monetizationBase(BaseModel):
    """Base schema for content_creator_monetization"""
    pass

class Content_creator_monetizationCreate(Content_creator_monetizationBase):
    """Schema for creating content_creator_monetization"""
    name: str
    description: Optional[str] = None
    status: Content_creator_monetizationStatus = Content_creator_monetizationStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Content_creator_monetizationUpdate(Content_creator_monetizationBase):
    """Schema for updating content_creator_monetization"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Content_creator_monetizationStatus] = None

class Content_creator_monetizationResponse(Content_creator_monetizationBase):
    """Response schema for content_creator_monetization"""
    id: str
    name: str
    description: Optional[str] = None
    status: Content_creator_monetizationStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_content_creator_monetization_create(data: Content_creator_monetizationCreate) -> Content_creator_monetizationCreate:
    """Validate content_creator_monetization creation data"""
    return data

def validate_content_creator_monetization_update(data: Content_creator_monetizationUpdate) -> Content_creator_monetizationUpdate:
    """Validate content_creator_monetization update data"""
    return data
