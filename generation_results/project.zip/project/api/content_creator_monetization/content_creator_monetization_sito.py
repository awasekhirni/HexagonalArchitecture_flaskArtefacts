from typing import List, Optional
from domain.content_creator_monetization.content_creator_monetization_entity import Content_creator_monetization
from domain.content_creator_monetization.content_creator_monetization_service_interface import IAsyncContent_creator_monetizationService
from infrastructure.repositories.content_creator_monetization.content_creator_monetization_repository import Content_creator_monetizationRepository
from api.mappers.content_creator_monetization_mapper import content_creator_monetization_mapper
from shared.utils.logger import logger

class Content_creator_monetizationService(IAsyncContent_creator_monetizationService):
    """Service implementation for Content_creator_monetization"""

    def __init__(self):
        self.repository = Content_creator_monetizationRepository()

    async def get_by_id(self, id: str) -> Optional[Content_creator_monetization]:
        """Get content_creator_monetization by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting content_creator_monetization by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Content_creator_monetization]:
        """Get all content_creator_monetizations"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all content_creator_monetizations: {str(e)}")
            raise

    async def create(self, data: Content_creator_monetization) -> Content_creator_monetization:
        """Create new content_creator_monetization"""
        try:
            return await self.repository.create(content_creator_monetization_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating content_creator_monetization: {str(e)}")
            raise

    async def update(self, id: str, data: Content_creator_monetization) -> Optional[Content_creator_monetization]:
        """Update content_creator_monetization"""
        try:
            return await self.repository.update(id, content_creator_monetization_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating content_creator_monetization: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete content_creator_monetization"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting content_creator_monetization: {str(e)}")
            raise
