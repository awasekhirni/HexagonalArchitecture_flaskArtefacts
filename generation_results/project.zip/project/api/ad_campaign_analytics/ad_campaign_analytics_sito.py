from typing import List, Optional
from domain.ad_campaign_analytics.ad_campaign_analytics_entity import Ad_campaign_analytics
from domain.ad_campaign_analytics.ad_campaign_analytics_service_interface import IAsyncAd_campaign_analyticsService
from infrastructure.repositories.ad_campaign_analytics.ad_campaign_analytics_repository import Ad_campaign_analyticsRepository
from api.mappers.ad_campaign_analytics_mapper import ad_campaign_analytics_mapper
from shared.utils.logger import logger

class Ad_campaign_analyticsService(IAsyncAd_campaign_analyticsService):
    """Service implementation for Ad_campaign_analytics"""

    def __init__(self):
        self.repository = Ad_campaign_analyticsRepository()

    async def get_by_id(self, id: str) -> Optional[Ad_campaign_analytics]:
        """Get ad_campaign_analytics by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting ad_campaign_analytics by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Ad_campaign_analytics]:
        """Get all ad_campaign_analyticss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all ad_campaign_analyticss: {str(e)}")
            raise

    async def create(self, data: Ad_campaign_analytics) -> Ad_campaign_analytics:
        """Create new ad_campaign_analytics"""
        try:
            return await self.repository.create(ad_campaign_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating ad_campaign_analytics: {str(e)}")
            raise

    async def update(self, id: str, data: Ad_campaign_analytics) -> Optional[Ad_campaign_analytics]:
        """Update ad_campaign_analytics"""
        try:
            return await self.repository.update(id, ad_campaign_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating ad_campaign_analytics: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete ad_campaign_analytics"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting ad_campaign_analytics: {str(e)}")
            raise
