from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Ad_campaign_analyticsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Ad_campaign_analyticsBase(BaseModel):
    """Base schema for ad_campaign_analytics"""
    pass

class Ad_campaign_analyticsCreate(Ad_campaign_analyticsBase):
    """Schema for creating ad_campaign_analytics"""
    name: str
    description: Optional[str] = None
    status: Ad_campaign_analyticsStatus = Ad_campaign_analyticsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Ad_campaign_analyticsUpdate(Ad_campaign_analyticsBase):
    """Schema for updating ad_campaign_analytics"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Ad_campaign_analyticsStatus] = None

class Ad_campaign_analyticsResponse(Ad_campaign_analyticsBase):
    """Response schema for ad_campaign_analytics"""
    id: str
    name: str
    description: Optional[str] = None
    status: Ad_campaign_analyticsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_ad_campaign_analytics_create(data: Ad_campaign_analyticsCreate) -> Ad_campaign_analyticsCreate:
    """Validate ad_campaign_analytics creation data"""
    return data

def validate_ad_campaign_analytics_update(data: Ad_campaign_analyticsUpdate) -> Ad_campaign_analyticsUpdate:
    """Validate ad_campaign_analytics update data"""
    return data
