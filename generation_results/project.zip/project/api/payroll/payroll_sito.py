from typing import List, Optional
from domain.payroll.payroll_entity import Payroll
from domain.payroll.payroll_service_interface import IAsyncPayrollService
from infrastructure.repositories.payroll.payroll_repository import PayrollRepository
from api.mappers.payroll_mapper import payroll_mapper
from shared.utils.logger import logger

class PayrollService(IAsyncPayrollService):
    """Service implementation for Payroll"""

    def __init__(self):
        self.repository = PayrollRepository()

    async def get_by_id(self, id: str) -> Optional[Payroll]:
        """Get payroll by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting payroll by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Payroll]:
        """Get all payrolls"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all payrolls: {str(e)}")
            raise

    async def create(self, data: Payroll) -> Payroll:
        """Create new payroll"""
        try:
            return await self.repository.create(payroll_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating payroll: {str(e)}")
            raise

    async def update(self, id: str, data: Payroll) -> Optional[Payroll]:
        """Update payroll"""
        try:
            return await self.repository.update(id, payroll_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating payroll: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete payroll"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting payroll: {str(e)}")
            raise
