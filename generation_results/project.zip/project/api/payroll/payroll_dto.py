from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class PayrollStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class PayrollBase(BaseModel):
    """Base schema for payroll"""
    pass

class PayrollCreate(PayrollBase):
    """Schema for creating payroll"""
    name: str
    description: Optional[str] = None
    status: PayrollStatus = PayrollStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class PayrollUpdate(PayrollBase):
    """Schema for updating payroll"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[PayrollStatus] = None

class PayrollResponse(PayrollBase):
    """Response schema for payroll"""
    id: str
    name: str
    description: Optional[str] = None
    status: PayrollStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_payroll_create(data: PayrollCreate) -> PayrollCreate:
    """Validate payroll creation data"""
    return data

def validate_payroll_update(data: PayrollUpdate) -> PayrollUpdate:
    """Validate payroll update data"""
    return data
