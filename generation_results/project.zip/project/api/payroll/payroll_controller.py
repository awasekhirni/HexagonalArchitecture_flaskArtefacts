from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.payroll.payroll_entity import Payroll
from domain.payroll.payroll_service_interface import IAsyncPayrollService
from api.dtos.payroll_dto import PayrollCreate, PayrollUpdate, PayrollResponse
from api.mappers.payroll_mapper import payroll_mapper
from api.validations.payroll_validation_schemas import validate_payroll_create, validate_payroll_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('payroll', description='Payroll operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
payroll_create_model = api.model('PayrollCreate', {
    'name': fields.String(required=True, description='payroll name'),
    'description': fields.String(description='payroll description'),
    'status': fields.String(description='payroll status', enum=['active', 'inactive', 'pending'])
})

payroll_update_model = api.model('PayrollUpdate', {
    'name': fields.String(description='payroll name'),
    'description': fields.String(description='payroll description'),
    'status': fields.String(description='payroll status', enum=['active', 'inactive', 'pending'])
})

payroll_response_model = api.model('PayrollResponse', {
    'id': fields.String(description='payroll ID'),
    'name': fields.String(description='payroll name'),
    'description': fields.String(description='payroll description'),
    'status': fields.String(description='payroll status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPayrollService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class PayrollList(Resource):
        @api.doc('list_payrolls')
        @api.expect(pagination_parser)
        @api.marshal_list_with(payroll_response_model)
        @token_required
        async def get(self):
            """List all payrolls"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [payroll_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting payrolls: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_payroll')
        @api.expect(payroll_create_model)
        @api.marshal_with(payroll_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new payroll"""
            try:
                data = api.payload
                validated_data = validate_payroll_create(data)
                entity = payroll_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return payroll_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating payroll: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The payroll identifier')
    @api.response(404, 'Payroll not found')
    class PayrollResource(Resource):
        @api.doc('get_payroll')
        @api.marshal_with(payroll_response_model)
        @token_required
        async def get(self, id):
            """Get a payroll given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Payroll not found")
                return payroll_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting payroll {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_payroll')
        @api.expect(payroll_update_model)
        @api.marshal_with(payroll_response_model)
        @token_required
        async def put(self, id):
            """Update a payroll given its identifier"""
            try:
                data = api.payload
                validated_data = validate_payroll_update(data)
                entity = payroll_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Payroll not found")
                return payroll_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating payroll {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_payroll')
        @api.response(204, 'Payroll deleted')
        @token_required
        async def delete(self, id):
            """Delete a payroll given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Payroll not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting payroll {id}: {str(e)}")
                api.abort(400, str(e))

    return api
