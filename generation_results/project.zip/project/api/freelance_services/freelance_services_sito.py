from typing import List, Optional
from domain.freelance_services.freelance_services_entity import Freelance_services
from domain.freelance_services.freelance_services_service_interface import IAsyncFreelance_servicesService
from infrastructure.repositories.freelance_services.freelance_services_repository import Freelance_servicesRepository
from api.mappers.freelance_services_mapper import freelance_services_mapper
from shared.utils.logger import logger

class Freelance_servicesService(IAsyncFreelance_servicesService):
    """Service implementation for Freelance_services"""

    def __init__(self):
        self.repository = Freelance_servicesRepository()

    async def get_by_id(self, id: str) -> Optional[Freelance_services]:
        """Get freelance_services by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting freelance_services by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Freelance_services]:
        """Get all freelance_servicess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all freelance_servicess: {str(e)}")
            raise

    async def create(self, data: Freelance_services) -> Freelance_services:
        """Create new freelance_services"""
        try:
            return await self.repository.create(freelance_services_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating freelance_services: {str(e)}")
            raise

    async def update(self, id: str, data: Freelance_services) -> Optional[Freelance_services]:
        """Update freelance_services"""
        try:
            return await self.repository.update(id, freelance_services_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating freelance_services: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete freelance_services"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting freelance_services: {str(e)}")
            raise
