from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Freelance_servicesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Freelance_servicesBase(BaseModel):
    """Base schema for freelance_services"""
    pass

class Freelance_servicesCreate(Freelance_servicesBase):
    """Schema for creating freelance_services"""
    name: str
    description: Optional[str] = None
    status: Freelance_servicesStatus = Freelance_servicesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Freelance_servicesUpdate(Freelance_servicesBase):
    """Schema for updating freelance_services"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Freelance_servicesStatus] = None

class Freelance_servicesResponse(Freelance_servicesBase):
    """Response schema for freelance_services"""
    id: str
    name: str
    description: Optional[str] = None
    status: Freelance_servicesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_freelance_services_create(data: Freelance_servicesCreate) -> Freelance_servicesCreate:
    """Validate freelance_services creation data"""
    return data

def validate_freelance_services_update(data: Freelance_servicesUpdate) -> Freelance_servicesUpdate:
    """Validate freelance_services update data"""
    return data
