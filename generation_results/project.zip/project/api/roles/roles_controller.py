from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.roles.roles_entity import Roles
from domain.roles.roles_service_interface import IAsyncRolesService
from api.dtos.roles_dto import RolesCreate, RolesUpdate, RolesResponse
from api.mappers.roles_mapper import roles_mapper
from api.validations.roles_validation_schemas import validate_roles_create, validate_roles_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('roles', description='Roles operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
roles_create_model = api.model('RolesCreate', {
    'name': fields.String(required=True, description='roles name'),
    'description': fields.String(description='roles description'),
    'status': fields.String(description='roles status', enum=['active', 'inactive', 'pending'])
})

roles_update_model = api.model('RolesUpdate', {
    'name': fields.String(description='roles name'),
    'description': fields.String(description='roles description'),
    'status': fields.String(description='roles status', enum=['active', 'inactive', 'pending'])
})

roles_response_model = api.model('RolesResponse', {
    'id': fields.String(description='roles ID'),
    'name': fields.String(description='roles name'),
    'description': fields.String(description='roles description'),
    'status': fields.String(description='roles status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncRolesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class RolesList(Resource):
        @api.doc('list_roless')
        @api.expect(pagination_parser)
        @api.marshal_list_with(roles_response_model)
        @token_required
        async def get(self):
            """List all roless"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [roles_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting roless: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_roles')
        @api.expect(roles_create_model)
        @api.marshal_with(roles_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new roles"""
            try:
                data = api.payload
                validated_data = validate_roles_create(data)
                entity = roles_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return roles_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating roles: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The roles identifier')
    @api.response(404, 'Roles not found')
    class RolesResource(Resource):
        @api.doc('get_roles')
        @api.marshal_with(roles_response_model)
        @token_required
        async def get(self, id):
            """Get a roles given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Roles not found")
                return roles_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting roles {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_roles')
        @api.expect(roles_update_model)
        @api.marshal_with(roles_response_model)
        @token_required
        async def put(self, id):
            """Update a roles given its identifier"""
            try:
                data = api.payload
                validated_data = validate_roles_update(data)
                entity = roles_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Roles not found")
                return roles_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating roles {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_roles')
        @api.response(204, 'Roles deleted')
        @token_required
        async def delete(self, id):
            """Delete a roles given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Roles not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting roles {id}: {str(e)}")
                api.abort(400, str(e))

    return api
