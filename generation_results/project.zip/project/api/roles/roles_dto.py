from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class RolesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class RolesBase(BaseModel):
    """Base schema for roles"""
    pass

class RolesCreate(RolesBase):
    """Schema for creating roles"""
    name: str
    description: Optional[str] = None
    status: RolesStatus = RolesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class RolesUpdate(RolesBase):
    """Schema for updating roles"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[RolesStatus] = None

class RolesResponse(RolesBase):
    """Response schema for roles"""
    id: str
    name: str
    description: Optional[str] = None
    status: RolesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_roles_create(data: RolesCreate) -> RolesCreate:
    """Validate roles creation data"""
    return data

def validate_roles_update(data: RolesUpdate) -> RolesUpdate:
    """Validate roles update data"""
    return data
