from typing import List, Optional
from domain.roles.roles_entity import Roles
from domain.roles.roles_service_interface import IAsyncRolesService
from infrastructure.repositories.roles.roles_repository import RolesRepository
from api.mappers.roles_mapper import roles_mapper
from shared.utils.logger import logger

class RolesService(IAsyncRolesService):
    """Service implementation for Roles"""

    def __init__(self):
        self.repository = RolesRepository()

    async def get_by_id(self, id: str) -> Optional[Roles]:
        """Get roles by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting roles by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Roles]:
        """Get all roless"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all roless: {str(e)}")
            raise

    async def create(self, data: Roles) -> Roles:
        """Create new roles"""
        try:
            return await self.repository.create(roles_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating roles: {str(e)}")
            raise

    async def update(self, id: str, data: Roles) -> Optional[Roles]:
        """Update roles"""
        try:
            return await self.repository.update(id, roles_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating roles: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete roles"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting roles: {str(e)}")
            raise
