from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class PromotionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class PromotionsBase(BaseModel):
    """Base schema for promotions"""
    pass

class PromotionsCreate(PromotionsBase):
    """Schema for creating promotions"""
    name: str
    description: Optional[str] = None
    status: PromotionsStatus = PromotionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class PromotionsUpdate(PromotionsBase):
    """Schema for updating promotions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[PromotionsStatus] = None

class PromotionsResponse(PromotionsBase):
    """Response schema for promotions"""
    id: str
    name: str
    description: Optional[str] = None
    status: PromotionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_promotions_create(data: PromotionsCreate) -> PromotionsCreate:
    """Validate promotions creation data"""
    return data

def validate_promotions_update(data: PromotionsUpdate) -> PromotionsUpdate:
    """Validate promotions update data"""
    return data
