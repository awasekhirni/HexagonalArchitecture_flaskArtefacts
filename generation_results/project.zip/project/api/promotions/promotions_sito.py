from typing import List, Optional
from domain.promotions.promotions_entity import Promotions
from domain.promotions.promotions_service_interface import IAsyncPromotionsService
from infrastructure.repositories.promotions.promotions_repository import PromotionsRepository
from api.mappers.promotions_mapper import promotions_mapper
from shared.utils.logger import logger

class PromotionsService(IAsyncPromotionsService):
    """Service implementation for Promotions"""

    def __init__(self):
        self.repository = PromotionsRepository()

    async def get_by_id(self, id: str) -> Optional[Promotions]:
        """Get promotions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting promotions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Promotions]:
        """Get all promotionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all promotionss: {str(e)}")
            raise

    async def create(self, data: Promotions) -> Promotions:
        """Create new promotions"""
        try:
            return await self.repository.create(promotions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating promotions: {str(e)}")
            raise

    async def update(self, id: str, data: Promotions) -> Optional[Promotions]:
        """Update promotions"""
        try:
            return await self.repository.update(id, promotions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating promotions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete promotions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting promotions: {str(e)}")
            raise
