from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.employee_trainings.employee_trainings_entity import Employee_trainings
from domain.employee_trainings.employee_trainings_service_interface import IAsyncEmployee_trainingsService
from api.dtos.employee_trainings_dto import Employee_trainingsCreate, Employee_trainingsUpdate, Employee_trainingsResponse
from api.mappers.employee_trainings_mapper import employee_trainings_mapper
from api.validations.employee_trainings_validation_schemas import validate_employee_trainings_create, validate_employee_trainings_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('employee_trainings', description='Employee_trainings operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
employee_trainings_create_model = api.model('Employee_trainingsCreate', {
    'name': fields.String(required=True, description='employee_trainings name'),
    'description': fields.String(description='employee_trainings description'),
    'status': fields.String(description='employee_trainings status', enum=['active', 'inactive', 'pending'])
})

employee_trainings_update_model = api.model('Employee_trainingsUpdate', {
    'name': fields.String(description='employee_trainings name'),
    'description': fields.String(description='employee_trainings description'),
    'status': fields.String(description='employee_trainings status', enum=['active', 'inactive', 'pending'])
})

employee_trainings_response_model = api.model('Employee_trainingsResponse', {
    'id': fields.String(description='employee_trainings ID'),
    'name': fields.String(description='employee_trainings name'),
    'description': fields.String(description='employee_trainings description'),
    'status': fields.String(description='employee_trainings status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncEmployee_trainingsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Employee_trainingsList(Resource):
        @api.doc('list_employee_trainingss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(employee_trainings_response_model)
        @token_required
        async def get(self):
            """List all employee_trainingss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [employee_trainings_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting employee_trainingss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_employee_trainings')
        @api.expect(employee_trainings_create_model)
        @api.marshal_with(employee_trainings_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new employee_trainings"""
            try:
                data = api.payload
                validated_data = validate_employee_trainings_create(data)
                entity = employee_trainings_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return employee_trainings_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating employee_trainings: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The employee_trainings identifier')
    @api.response(404, 'Employee_trainings not found')
    class Employee_trainingsResource(Resource):
        @api.doc('get_employee_trainings')
        @api.marshal_with(employee_trainings_response_model)
        @token_required
        async def get(self, id):
            """Get a employee_trainings given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Employee_trainings not found")
                return employee_trainings_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting employee_trainings {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_employee_trainings')
        @api.expect(employee_trainings_update_model)
        @api.marshal_with(employee_trainings_response_model)
        @token_required
        async def put(self, id):
            """Update a employee_trainings given its identifier"""
            try:
                data = api.payload
                validated_data = validate_employee_trainings_update(data)
                entity = employee_trainings_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Employee_trainings not found")
                return employee_trainings_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating employee_trainings {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_employee_trainings')
        @api.response(204, 'Employee_trainings deleted')
        @token_required
        async def delete(self, id):
            """Delete a employee_trainings given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Employee_trainings not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting employee_trainings {id}: {str(e)}")
                api.abort(400, str(e))

    return api
