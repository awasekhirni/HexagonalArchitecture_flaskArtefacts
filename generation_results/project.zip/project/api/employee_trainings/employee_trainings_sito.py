from typing import List, Optional
from domain.employee_trainings.employee_trainings_entity import Employee_trainings
from domain.employee_trainings.employee_trainings_service_interface import IAsyncEmployee_trainingsService
from infrastructure.repositories.employee_trainings.employee_trainings_repository import Employee_trainingsRepository
from api.mappers.employee_trainings_mapper import employee_trainings_mapper
from shared.utils.logger import logger

class Employee_trainingsService(IAsyncEmployee_trainingsService):
    """Service implementation for Employee_trainings"""

    def __init__(self):
        self.repository = Employee_trainingsRepository()

    async def get_by_id(self, id: str) -> Optional[Employee_trainings]:
        """Get employee_trainings by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting employee_trainings by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Employee_trainings]:
        """Get all employee_trainingss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all employee_trainingss: {str(e)}")
            raise

    async def create(self, data: Employee_trainings) -> Employee_trainings:
        """Create new employee_trainings"""
        try:
            return await self.repository.create(employee_trainings_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating employee_trainings: {str(e)}")
            raise

    async def update(self, id: str, data: Employee_trainings) -> Optional[Employee_trainings]:
        """Update employee_trainings"""
        try:
            return await self.repository.update(id, employee_trainings_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating employee_trainings: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete employee_trainings"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting employee_trainings: {str(e)}")
            raise
