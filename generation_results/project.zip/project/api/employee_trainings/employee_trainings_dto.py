from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Employee_trainingsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Employee_trainingsBase(BaseModel):
    """Base schema for employee_trainings"""
    pass

class Employee_trainingsCreate(Employee_trainingsBase):
    """Schema for creating employee_trainings"""
    name: str
    description: Optional[str] = None
    status: Employee_trainingsStatus = Employee_trainingsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Employee_trainingsUpdate(Employee_trainingsBase):
    """Schema for updating employee_trainings"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Employee_trainingsStatus] = None

class Employee_trainingsResponse(Employee_trainingsBase):
    """Response schema for employee_trainings"""
    id: str
    name: str
    description: Optional[str] = None
    status: Employee_trainingsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_employee_trainings_create(data: Employee_trainingsCreate) -> Employee_trainingsCreate:
    """Validate employee_trainings creation data"""
    return data

def validate_employee_trainings_update(data: Employee_trainingsUpdate) -> Employee_trainingsUpdate:
    """Validate employee_trainings update data"""
    return data
