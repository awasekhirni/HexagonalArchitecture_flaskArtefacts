from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Event_attendeesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Event_attendeesBase(BaseModel):
    """Base schema for event_attendees"""
    pass

class Event_attendeesCreate(Event_attendeesBase):
    """Schema for creating event_attendees"""
    name: str
    description: Optional[str] = None
    status: Event_attendeesStatus = Event_attendeesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Event_attendeesUpdate(Event_attendeesBase):
    """Schema for updating event_attendees"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Event_attendeesStatus] = None

class Event_attendeesResponse(Event_attendeesBase):
    """Response schema for event_attendees"""
    id: str
    name: str
    description: Optional[str] = None
    status: Event_attendeesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_event_attendees_create(data: Event_attendeesCreate) -> Event_attendeesCreate:
    """Validate event_attendees creation data"""
    return data

def validate_event_attendees_update(data: Event_attendeesUpdate) -> Event_attendeesUpdate:
    """Validate event_attendees update data"""
    return data
