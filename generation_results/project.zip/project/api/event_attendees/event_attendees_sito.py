from typing import List, Optional
from domain.event_attendees.event_attendees_entity import Event_attendees
from domain.event_attendees.event_attendees_service_interface import IAsyncEvent_attendeesService
from infrastructure.repositories.event_attendees.event_attendees_repository import Event_attendeesRepository
from api.mappers.event_attendees_mapper import event_attendees_mapper
from shared.utils.logger import logger

class Event_attendeesService(IAsyncEvent_attendeesService):
    """Service implementation for Event_attendees"""

    def __init__(self):
        self.repository = Event_attendeesRepository()

    async def get_by_id(self, id: str) -> Optional[Event_attendees]:
        """Get event_attendees by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting event_attendees by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Event_attendees]:
        """Get all event_attendeess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all event_attendeess: {str(e)}")
            raise

    async def create(self, data: Event_attendees) -> Event_attendees:
        """Create new event_attendees"""
        try:
            return await self.repository.create(event_attendees_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating event_attendees: {str(e)}")
            raise

    async def update(self, id: str, data: Event_attendees) -> Optional[Event_attendees]:
        """Update event_attendees"""
        try:
            return await self.repository.update(id, event_attendees_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating event_attendees: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete event_attendees"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting event_attendees: {str(e)}")
            raise
