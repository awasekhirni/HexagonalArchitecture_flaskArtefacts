from domain.event_attendees.event_attendees_entity import Event_attendees
from api.dtos.event_attendees_dto import Event_attendeesCreate, Event_attendeesUpdate, Event_attendeesResponse
from typing import Union

class Event_attendeesMapper:
    """Mapper for Event_attendees between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Event_attendees) -> Event_attendeesResponse:
        """Convert entity to response DTO"""
        return Event_attendeesResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Event_attendeesCreate, Event_attendeesUpdate]) -> Event_attendees:
        """Convert DTO to entity"""
        return Event_attendees(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Event_attendees, dto: Event_attendeesUpdate) -> Event_attendees:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

event_attendees_mapper = Event_attendeesMapper()
