from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.event_attendees.event_attendees_entity import Event_attendees
from domain.event_attendees.event_attendees_service_interface import IAsyncEvent_attendeesService
from api.dtos.event_attendees_dto import Event_attendeesCreate, Event_attendeesUpdate, Event_attendeesResponse
from api.mappers.event_attendees_mapper import event_attendees_mapper
from api.validations.event_attendees_validation_schemas import validate_event_attendees_create, validate_event_attendees_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('event_attendees', description='Event_attendees operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
event_attendees_create_model = api.model('Event_attendeesCreate', {
    'name': fields.String(required=True, description='event_attendees name'),
    'description': fields.String(description='event_attendees description'),
    'status': fields.String(description='event_attendees status', enum=['active', 'inactive', 'pending'])
})

event_attendees_update_model = api.model('Event_attendeesUpdate', {
    'name': fields.String(description='event_attendees name'),
    'description': fields.String(description='event_attendees description'),
    'status': fields.String(description='event_attendees status', enum=['active', 'inactive', 'pending'])
})

event_attendees_response_model = api.model('Event_attendeesResponse', {
    'id': fields.String(description='event_attendees ID'),
    'name': fields.String(description='event_attendees name'),
    'description': fields.String(description='event_attendees description'),
    'status': fields.String(description='event_attendees status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncEvent_attendeesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Event_attendeesList(Resource):
        @api.doc('list_event_attendeess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(event_attendees_response_model)
        @token_required
        async def get(self):
            """List all event_attendeess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [event_attendees_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting event_attendeess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_event_attendees')
        @api.expect(event_attendees_create_model)
        @api.marshal_with(event_attendees_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new event_attendees"""
            try:
                data = api.payload
                validated_data = validate_event_attendees_create(data)
                entity = event_attendees_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return event_attendees_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating event_attendees: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The event_attendees identifier')
    @api.response(404, 'Event_attendees not found')
    class Event_attendeesResource(Resource):
        @api.doc('get_event_attendees')
        @api.marshal_with(event_attendees_response_model)
        @token_required
        async def get(self, id):
            """Get a event_attendees given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Event_attendees not found")
                return event_attendees_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting event_attendees {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_event_attendees')
        @api.expect(event_attendees_update_model)
        @api.marshal_with(event_attendees_response_model)
        @token_required
        async def put(self, id):
            """Update a event_attendees given its identifier"""
            try:
                data = api.payload
                validated_data = validate_event_attendees_update(data)
                entity = event_attendees_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Event_attendees not found")
                return event_attendees_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating event_attendees {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_event_attendees')
        @api.response(204, 'Event_attendees deleted')
        @token_required
        async def delete(self, id):
            """Delete a event_attendees given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Event_attendees not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting event_attendees {id}: {str(e)}")
                api.abort(400, str(e))

    return api
