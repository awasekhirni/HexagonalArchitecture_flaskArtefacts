from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Regional_cost_of_livingStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Regional_cost_of_livingBase(BaseModel):
    """Base schema for regional_cost_of_living"""
    pass

class Regional_cost_of_livingCreate(Regional_cost_of_livingBase):
    """Schema for creating regional_cost_of_living"""
    name: str
    description: Optional[str] = None
    status: Regional_cost_of_livingStatus = Regional_cost_of_livingStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Regional_cost_of_livingUpdate(Regional_cost_of_livingBase):
    """Schema for updating regional_cost_of_living"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Regional_cost_of_livingStatus] = None

class Regional_cost_of_livingResponse(Regional_cost_of_livingBase):
    """Response schema for regional_cost_of_living"""
    id: str
    name: str
    description: Optional[str] = None
    status: Regional_cost_of_livingStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_regional_cost_of_living_create(data: Regional_cost_of_livingCreate) -> Regional_cost_of_livingCreate:
    """Validate regional_cost_of_living creation data"""
    return data

def validate_regional_cost_of_living_update(data: Regional_cost_of_livingUpdate) -> Regional_cost_of_livingUpdate:
    """Validate regional_cost_of_living update data"""
    return data
