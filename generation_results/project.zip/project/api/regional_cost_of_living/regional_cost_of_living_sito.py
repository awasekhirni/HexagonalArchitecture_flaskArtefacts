from typing import List, Optional
from domain.regional_cost_of_living.regional_cost_of_living_entity import Regional_cost_of_living
from domain.regional_cost_of_living.regional_cost_of_living_service_interface import IAsyncRegional_cost_of_livingService
from infrastructure.repositories.regional_cost_of_living.regional_cost_of_living_repository import Regional_cost_of_livingRepository
from api.mappers.regional_cost_of_living_mapper import regional_cost_of_living_mapper
from shared.utils.logger import logger

class Regional_cost_of_livingService(IAsyncRegional_cost_of_livingService):
    """Service implementation for Regional_cost_of_living"""

    def __init__(self):
        self.repository = Regional_cost_of_livingRepository()

    async def get_by_id(self, id: str) -> Optional[Regional_cost_of_living]:
        """Get regional_cost_of_living by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting regional_cost_of_living by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Regional_cost_of_living]:
        """Get all regional_cost_of_livings"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all regional_cost_of_livings: {str(e)}")
            raise

    async def create(self, data: Regional_cost_of_living) -> Regional_cost_of_living:
        """Create new regional_cost_of_living"""
        try:
            return await self.repository.create(regional_cost_of_living_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating regional_cost_of_living: {str(e)}")
            raise

    async def update(self, id: str, data: Regional_cost_of_living) -> Optional[Regional_cost_of_living]:
        """Update regional_cost_of_living"""
        try:
            return await self.repository.update(id, regional_cost_of_living_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating regional_cost_of_living: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete regional_cost_of_living"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting regional_cost_of_living: {str(e)}")
            raise
