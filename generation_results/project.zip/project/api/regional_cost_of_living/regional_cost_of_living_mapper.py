from domain.regional_cost_of_living.regional_cost_of_living_entity import Regional_cost_of_living
from api.dtos.regional_cost_of_living_dto import Regional_cost_of_livingCreate, Regional_cost_of_livingUpdate, Regional_cost_of_livingResponse
from typing import Union

class Regional_cost_of_livingMapper:
    """Mapper for Regional_cost_of_living between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Regional_cost_of_living) -> Regional_cost_of_livingResponse:
        """Convert entity to response DTO"""
        return Regional_cost_of_livingResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Regional_cost_of_livingCreate, Regional_cost_of_livingUpdate]) -> Regional_cost_of_living:
        """Convert DTO to entity"""
        return Regional_cost_of_living(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Regional_cost_of_living, dto: Regional_cost_of_livingUpdate) -> Regional_cost_of_living:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

regional_cost_of_living_mapper = Regional_cost_of_livingMapper()
