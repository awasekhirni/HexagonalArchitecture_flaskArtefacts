from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_connectionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_connectionsBase(BaseModel):
    """Base schema for user_connections"""
    pass

class User_connectionsCreate(User_connectionsBase):
    """Schema for creating user_connections"""
    name: str
    description: Optional[str] = None
    status: User_connectionsStatus = User_connectionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_connectionsUpdate(User_connectionsBase):
    """Schema for updating user_connections"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_connectionsStatus] = None

class User_connectionsResponse(User_connectionsBase):
    """Response schema for user_connections"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_connectionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_connections_create(data: User_connectionsCreate) -> User_connectionsCreate:
    """Validate user_connections creation data"""
    return data

def validate_user_connections_update(data: User_connectionsUpdate) -> User_connectionsUpdate:
    """Validate user_connections update data"""
    return data
