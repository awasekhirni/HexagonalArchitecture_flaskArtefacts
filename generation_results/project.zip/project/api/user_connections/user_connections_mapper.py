from domain.user_connections.user_connections_entity import User_connections
from api.dtos.user_connections_dto import User_connectionsCreate, User_connectionsUpdate, User_connectionsResponse
from typing import Union

class User_connectionsMapper:
    """Mapper for User_connections between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_connections) -> User_connectionsResponse:
        """Convert entity to response DTO"""
        return User_connectionsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_connectionsCreate, User_connectionsUpdate]) -> User_connections:
        """Convert DTO to entity"""
        return User_connections(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_connections, dto: User_connectionsUpdate) -> User_connections:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_connections_mapper = User_connectionsMapper()
