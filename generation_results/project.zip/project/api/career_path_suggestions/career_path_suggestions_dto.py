from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Career_path_suggestionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Career_path_suggestionsBase(BaseModel):
    """Base schema for career_path_suggestions"""
    pass

class Career_path_suggestionsCreate(Career_path_suggestionsBase):
    """Schema for creating career_path_suggestions"""
    name: str
    description: Optional[str] = None
    status: Career_path_suggestionsStatus = Career_path_suggestionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Career_path_suggestionsUpdate(Career_path_suggestionsBase):
    """Schema for updating career_path_suggestions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Career_path_suggestionsStatus] = None

class Career_path_suggestionsResponse(Career_path_suggestionsBase):
    """Response schema for career_path_suggestions"""
    id: str
    name: str
    description: Optional[str] = None
    status: Career_path_suggestionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_career_path_suggestions_create(data: Career_path_suggestionsCreate) -> Career_path_suggestionsCreate:
    """Validate career_path_suggestions creation data"""
    return data

def validate_career_path_suggestions_update(data: Career_path_suggestionsUpdate) -> Career_path_suggestionsUpdate:
    """Validate career_path_suggestions update data"""
    return data
