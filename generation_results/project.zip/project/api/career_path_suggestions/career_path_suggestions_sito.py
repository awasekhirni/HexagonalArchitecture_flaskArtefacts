from typing import List, Optional
from domain.career_path_suggestions.career_path_suggestions_entity import Career_path_suggestions
from domain.career_path_suggestions.career_path_suggestions_service_interface import IAsyncCareer_path_suggestionsService
from infrastructure.repositories.career_path_suggestions.career_path_suggestions_repository import Career_path_suggestionsRepository
from api.mappers.career_path_suggestions_mapper import career_path_suggestions_mapper
from shared.utils.logger import logger

class Career_path_suggestionsService(IAsyncCareer_path_suggestionsService):
    """Service implementation for Career_path_suggestions"""

    def __init__(self):
        self.repository = Career_path_suggestionsRepository()

    async def get_by_id(self, id: str) -> Optional[Career_path_suggestions]:
        """Get career_path_suggestions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting career_path_suggestions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Career_path_suggestions]:
        """Get all career_path_suggestionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all career_path_suggestionss: {str(e)}")
            raise

    async def create(self, data: Career_path_suggestions) -> Career_path_suggestions:
        """Create new career_path_suggestions"""
        try:
            return await self.repository.create(career_path_suggestions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating career_path_suggestions: {str(e)}")
            raise

    async def update(self, id: str, data: Career_path_suggestions) -> Optional[Career_path_suggestions]:
        """Update career_path_suggestions"""
        try:
            return await self.repository.update(id, career_path_suggestions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating career_path_suggestions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete career_path_suggestions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting career_path_suggestions: {str(e)}")
            raise
