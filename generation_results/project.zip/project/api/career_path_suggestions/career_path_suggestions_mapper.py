from domain.career_path_suggestions.career_path_suggestions_entity import Career_path_suggestions
from api.dtos.career_path_suggestions_dto import Career_path_suggestionsCreate, Career_path_suggestionsUpdate, Career_path_suggestionsResponse
from typing import Union

class Career_path_suggestionsMapper:
    """Mapper for Career_path_suggestions between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Career_path_suggestions) -> Career_path_suggestionsResponse:
        """Convert entity to response DTO"""
        return Career_path_suggestionsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Career_path_suggestionsCreate, Career_path_suggestionsUpdate]) -> Career_path_suggestions:
        """Convert DTO to entity"""
        return Career_path_suggestions(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Career_path_suggestions, dto: Career_path_suggestionsUpdate) -> Career_path_suggestions:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

career_path_suggestions_mapper = Career_path_suggestionsMapper()
