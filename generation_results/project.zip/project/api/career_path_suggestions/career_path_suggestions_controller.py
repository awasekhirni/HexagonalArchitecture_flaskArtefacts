from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.career_path_suggestions.career_path_suggestions_entity import Career_path_suggestions
from domain.career_path_suggestions.career_path_suggestions_service_interface import IAsyncCareer_path_suggestionsService
from api.dtos.career_path_suggestions_dto import Career_path_suggestionsCreate, Career_path_suggestionsUpdate, Career_path_suggestionsResponse
from api.mappers.career_path_suggestions_mapper import career_path_suggestions_mapper
from api.validations.career_path_suggestions_validation_schemas import validate_career_path_suggestions_create, validate_career_path_suggestions_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('career_path_suggestions', description='Career_path_suggestions operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
career_path_suggestions_create_model = api.model('Career_path_suggestionsCreate', {
    'name': fields.String(required=True, description='career_path_suggestions name'),
    'description': fields.String(description='career_path_suggestions description'),
    'status': fields.String(description='career_path_suggestions status', enum=['active', 'inactive', 'pending'])
})

career_path_suggestions_update_model = api.model('Career_path_suggestionsUpdate', {
    'name': fields.String(description='career_path_suggestions name'),
    'description': fields.String(description='career_path_suggestions description'),
    'status': fields.String(description='career_path_suggestions status', enum=['active', 'inactive', 'pending'])
})

career_path_suggestions_response_model = api.model('Career_path_suggestionsResponse', {
    'id': fields.String(description='career_path_suggestions ID'),
    'name': fields.String(description='career_path_suggestions name'),
    'description': fields.String(description='career_path_suggestions description'),
    'status': fields.String(description='career_path_suggestions status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncCareer_path_suggestionsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Career_path_suggestionsList(Resource):
        @api.doc('list_career_path_suggestionss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(career_path_suggestions_response_model)
        @token_required
        async def get(self):
            """List all career_path_suggestionss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [career_path_suggestions_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting career_path_suggestionss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_career_path_suggestions')
        @api.expect(career_path_suggestions_create_model)
        @api.marshal_with(career_path_suggestions_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new career_path_suggestions"""
            try:
                data = api.payload
                validated_data = validate_career_path_suggestions_create(data)
                entity = career_path_suggestions_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return career_path_suggestions_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating career_path_suggestions: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The career_path_suggestions identifier')
    @api.response(404, 'Career_path_suggestions not found')
    class Career_path_suggestionsResource(Resource):
        @api.doc('get_career_path_suggestions')
        @api.marshal_with(career_path_suggestions_response_model)
        @token_required
        async def get(self, id):
            """Get a career_path_suggestions given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Career_path_suggestions not found")
                return career_path_suggestions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting career_path_suggestions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_career_path_suggestions')
        @api.expect(career_path_suggestions_update_model)
        @api.marshal_with(career_path_suggestions_response_model)
        @token_required
        async def put(self, id):
            """Update a career_path_suggestions given its identifier"""
            try:
                data = api.payload
                validated_data = validate_career_path_suggestions_update(data)
                entity = career_path_suggestions_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Career_path_suggestions not found")
                return career_path_suggestions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating career_path_suggestions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_career_path_suggestions')
        @api.response(204, 'Career_path_suggestions deleted')
        @token_required
        async def delete(self, id):
            """Delete a career_path_suggestions given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Career_path_suggestions not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting career_path_suggestions {id}: {str(e)}")
                api.abort(400, str(e))

    return api
