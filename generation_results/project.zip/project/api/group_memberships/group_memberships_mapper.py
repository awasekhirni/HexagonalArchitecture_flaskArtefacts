from domain.group_memberships.group_memberships_entity import Group_memberships
from api.dtos.group_memberships_dto import Group_membershipsCreate, Group_membershipsUpdate, Group_membershipsResponse
from typing import Union

class Group_membershipsMapper:
    """Mapper for Group_memberships between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Group_memberships) -> Group_membershipsResponse:
        """Convert entity to response DTO"""
        return Group_membershipsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Group_membershipsCreate, Group_membershipsUpdate]) -> Group_memberships:
        """Convert DTO to entity"""
        return Group_memberships(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Group_memberships, dto: Group_membershipsUpdate) -> Group_memberships:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

group_memberships_mapper = Group_membershipsMapper()
