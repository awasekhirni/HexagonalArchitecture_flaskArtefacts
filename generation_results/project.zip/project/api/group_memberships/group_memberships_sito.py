from typing import List, Optional
from domain.group_memberships.group_memberships_entity import Group_memberships
from domain.group_memberships.group_memberships_service_interface import IAsyncGroup_membershipsService
from infrastructure.repositories.group_memberships.group_memberships_repository import Group_membershipsRepository
from api.mappers.group_memberships_mapper import group_memberships_mapper
from shared.utils.logger import logger

class Group_membershipsService(IAsyncGroup_membershipsService):
    """Service implementation for Group_memberships"""

    def __init__(self):
        self.repository = Group_membershipsRepository()

    async def get_by_id(self, id: str) -> Optional[Group_memberships]:
        """Get group_memberships by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting group_memberships by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Group_memberships]:
        """Get all group_membershipss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all group_membershipss: {str(e)}")
            raise

    async def create(self, data: Group_memberships) -> Group_memberships:
        """Create new group_memberships"""
        try:
            return await self.repository.create(group_memberships_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating group_memberships: {str(e)}")
            raise

    async def update(self, id: str, data: Group_memberships) -> Optional[Group_memberships]:
        """Update group_memberships"""
        try:
            return await self.repository.update(id, group_memberships_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating group_memberships: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete group_memberships"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting group_memberships: {str(e)}")
            raise
