from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.group_memberships.group_memberships_entity import Group_memberships
from domain.group_memberships.group_memberships_service_interface import IAsyncGroup_membershipsService
from api.dtos.group_memberships_dto import Group_membershipsCreate, Group_membershipsUpdate, Group_membershipsResponse
from api.mappers.group_memberships_mapper import group_memberships_mapper
from api.validations.group_memberships_validation_schemas import validate_group_memberships_create, validate_group_memberships_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('group_memberships', description='Group_memberships operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
group_memberships_create_model = api.model('Group_membershipsCreate', {
    'name': fields.String(required=True, description='group_memberships name'),
    'description': fields.String(description='group_memberships description'),
    'status': fields.String(description='group_memberships status', enum=['active', 'inactive', 'pending'])
})

group_memberships_update_model = api.model('Group_membershipsUpdate', {
    'name': fields.String(description='group_memberships name'),
    'description': fields.String(description='group_memberships description'),
    'status': fields.String(description='group_memberships status', enum=['active', 'inactive', 'pending'])
})

group_memberships_response_model = api.model('Group_membershipsResponse', {
    'id': fields.String(description='group_memberships ID'),
    'name': fields.String(description='group_memberships name'),
    'description': fields.String(description='group_memberships description'),
    'status': fields.String(description='group_memberships status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncGroup_membershipsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Group_membershipsList(Resource):
        @api.doc('list_group_membershipss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(group_memberships_response_model)
        @token_required
        async def get(self):
            """List all group_membershipss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [group_memberships_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting group_membershipss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_group_memberships')
        @api.expect(group_memberships_create_model)
        @api.marshal_with(group_memberships_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new group_memberships"""
            try:
                data = api.payload
                validated_data = validate_group_memberships_create(data)
                entity = group_memberships_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return group_memberships_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating group_memberships: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The group_memberships identifier')
    @api.response(404, 'Group_memberships not found')
    class Group_membershipsResource(Resource):
        @api.doc('get_group_memberships')
        @api.marshal_with(group_memberships_response_model)
        @token_required
        async def get(self, id):
            """Get a group_memberships given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Group_memberships not found")
                return group_memberships_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting group_memberships {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_group_memberships')
        @api.expect(group_memberships_update_model)
        @api.marshal_with(group_memberships_response_model)
        @token_required
        async def put(self, id):
            """Update a group_memberships given its identifier"""
            try:
                data = api.payload
                validated_data = validate_group_memberships_update(data)
                entity = group_memberships_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Group_memberships not found")
                return group_memberships_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating group_memberships {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_group_memberships')
        @api.response(204, 'Group_memberships deleted')
        @token_required
        async def delete(self, id):
            """Delete a group_memberships given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Group_memberships not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting group_memberships {id}: {str(e)}")
                api.abort(400, str(e))

    return api
