from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.collaborations.collaborations_entity import Collaborations
from domain.collaborations.collaborations_service_interface import IAsyncCollaborationsService
from api.dtos.collaborations_dto import CollaborationsCreate, CollaborationsUpdate, CollaborationsResponse
from api.mappers.collaborations_mapper import collaborations_mapper
from api.validations.collaborations_validation_schemas import validate_collaborations_create, validate_collaborations_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('collaborations', description='Collaborations operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
collaborations_create_model = api.model('CollaborationsCreate', {
    'name': fields.String(required=True, description='collaborations name'),
    'description': fields.String(description='collaborations description'),
    'status': fields.String(description='collaborations status', enum=['active', 'inactive', 'pending'])
})

collaborations_update_model = api.model('CollaborationsUpdate', {
    'name': fields.String(description='collaborations name'),
    'description': fields.String(description='collaborations description'),
    'status': fields.String(description='collaborations status', enum=['active', 'inactive', 'pending'])
})

collaborations_response_model = api.model('CollaborationsResponse', {
    'id': fields.String(description='collaborations ID'),
    'name': fields.String(description='collaborations name'),
    'description': fields.String(description='collaborations description'),
    'status': fields.String(description='collaborations status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncCollaborationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class CollaborationsList(Resource):
        @api.doc('list_collaborationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(collaborations_response_model)
        @token_required
        async def get(self):
            """List all collaborationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [collaborations_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting collaborationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_collaborations')
        @api.expect(collaborations_create_model)
        @api.marshal_with(collaborations_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new collaborations"""
            try:
                data = api.payload
                validated_data = validate_collaborations_create(data)
                entity = collaborations_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return collaborations_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating collaborations: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The collaborations identifier')
    @api.response(404, 'Collaborations not found')
    class CollaborationsResource(Resource):
        @api.doc('get_collaborations')
        @api.marshal_with(collaborations_response_model)
        @token_required
        async def get(self, id):
            """Get a collaborations given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Collaborations not found")
                return collaborations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting collaborations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_collaborations')
        @api.expect(collaborations_update_model)
        @api.marshal_with(collaborations_response_model)
        @token_required
        async def put(self, id):
            """Update a collaborations given its identifier"""
            try:
                data = api.payload
                validated_data = validate_collaborations_update(data)
                entity = collaborations_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Collaborations not found")
                return collaborations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating collaborations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_collaborations')
        @api.response(204, 'Collaborations deleted')
        @token_required
        async def delete(self, id):
            """Delete a collaborations given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Collaborations not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting collaborations {id}: {str(e)}")
                api.abort(400, str(e))

    return api
