from typing import List, Optional
from domain.collaborations.collaborations_entity import Collaborations
from domain.collaborations.collaborations_service_interface import IAsyncCollaborationsService
from infrastructure.repositories.collaborations.collaborations_repository import CollaborationsRepository
from api.mappers.collaborations_mapper import collaborations_mapper
from shared.utils.logger import logger

class CollaborationsService(IAsyncCollaborationsService):
    """Service implementation for Collaborations"""

    def __init__(self):
        self.repository = CollaborationsRepository()

    async def get_by_id(self, id: str) -> Optional[Collaborations]:
        """Get collaborations by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting collaborations by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Collaborations]:
        """Get all collaborationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all collaborationss: {str(e)}")
            raise

    async def create(self, data: Collaborations) -> Collaborations:
        """Create new collaborations"""
        try:
            return await self.repository.create(collaborations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating collaborations: {str(e)}")
            raise

    async def update(self, id: str, data: Collaborations) -> Optional[Collaborations]:
        """Update collaborations"""
        try:
            return await self.repository.update(id, collaborations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating collaborations: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete collaborations"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting collaborations: {str(e)}")
            raise
