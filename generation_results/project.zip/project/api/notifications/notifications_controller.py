from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.notifications.notifications_entity import Notifications
from domain.notifications.notifications_service_interface import IAsyncNotificationsService
from api.dtos.notifications_dto import NotificationsCreate, NotificationsUpdate, NotificationsResponse
from api.mappers.notifications_mapper import notifications_mapper
from api.validations.notifications_validation_schemas import validate_notifications_create, validate_notifications_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('notifications', description='Notifications operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
notifications_create_model = api.model('NotificationsCreate', {
    'name': fields.String(required=True, description='notifications name'),
    'description': fields.String(description='notifications description'),
    'status': fields.String(description='notifications status', enum=['active', 'inactive', 'pending'])
})

notifications_update_model = api.model('NotificationsUpdate', {
    'name': fields.String(description='notifications name'),
    'description': fields.String(description='notifications description'),
    'status': fields.String(description='notifications status', enum=['active', 'inactive', 'pending'])
})

notifications_response_model = api.model('NotificationsResponse', {
    'id': fields.String(description='notifications ID'),
    'name': fields.String(description='notifications name'),
    'description': fields.String(description='notifications description'),
    'status': fields.String(description='notifications status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncNotificationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class NotificationsList(Resource):
        @api.doc('list_notificationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(notifications_response_model)
        @token_required
        async def get(self):
            """List all notificationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [notifications_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting notificationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_notifications')
        @api.expect(notifications_create_model)
        @api.marshal_with(notifications_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new notifications"""
            try:
                data = api.payload
                validated_data = validate_notifications_create(data)
                entity = notifications_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return notifications_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating notifications: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The notifications identifier')
    @api.response(404, 'Notifications not found')
    class NotificationsResource(Resource):
        @api.doc('get_notifications')
        @api.marshal_with(notifications_response_model)
        @token_required
        async def get(self, id):
            """Get a notifications given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Notifications not found")
                return notifications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting notifications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_notifications')
        @api.expect(notifications_update_model)
        @api.marshal_with(notifications_response_model)
        @token_required
        async def put(self, id):
            """Update a notifications given its identifier"""
            try:
                data = api.payload
                validated_data = validate_notifications_update(data)
                entity = notifications_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Notifications not found")
                return notifications_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating notifications {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_notifications')
        @api.response(204, 'Notifications deleted')
        @token_required
        async def delete(self, id):
            """Delete a notifications given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Notifications not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting notifications {id}: {str(e)}")
                api.abort(400, str(e))

    return api
