from typing import List, Optional
from domain.notifications.notifications_entity import Notifications
from domain.notifications.notifications_service_interface import IAsyncNotificationsService
from infrastructure.repositories.notifications.notifications_repository import NotificationsRepository
from api.mappers.notifications_mapper import notifications_mapper
from shared.utils.logger import logger

class NotificationsService(IAsyncNotificationsService):
    """Service implementation for Notifications"""

    def __init__(self):
        self.repository = NotificationsRepository()

    async def get_by_id(self, id: str) -> Optional[Notifications]:
        """Get notifications by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting notifications by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Notifications]:
        """Get all notificationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all notificationss: {str(e)}")
            raise

    async def create(self, data: Notifications) -> Notifications:
        """Create new notifications"""
        try:
            return await self.repository.create(notifications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating notifications: {str(e)}")
            raise

    async def update(self, id: str, data: Notifications) -> Optional[Notifications]:
        """Update notifications"""
        try:
            return await self.repository.update(id, notifications_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating notifications: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete notifications"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting notifications: {str(e)}")
            raise
