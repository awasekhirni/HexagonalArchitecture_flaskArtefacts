from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class NotificationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class NotificationsBase(BaseModel):
    """Base schema for notifications"""
    pass

class NotificationsCreate(NotificationsBase):
    """Schema for creating notifications"""
    name: str
    description: Optional[str] = None
    status: NotificationsStatus = NotificationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class NotificationsUpdate(NotificationsBase):
    """Schema for updating notifications"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[NotificationsStatus] = None

class NotificationsResponse(NotificationsBase):
    """Response schema for notifications"""
    id: str
    name: str
    description: Optional[str] = None
    status: NotificationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_notifications_create(data: NotificationsCreate) -> NotificationsCreate:
    """Validate notifications creation data"""
    return data

def validate_notifications_update(data: NotificationsUpdate) -> NotificationsUpdate:
    """Validate notifications update data"""
    return data
