from typing import List, Optional
from domain.premium_memberships.premium_memberships_entity import Premium_memberships
from domain.premium_memberships.premium_memberships_service_interface import IAsyncPremium_membershipsService
from infrastructure.repositories.premium_memberships.premium_memberships_repository import Premium_membershipsRepository
from api.mappers.premium_memberships_mapper import premium_memberships_mapper
from shared.utils.logger import logger

class Premium_membershipsService(IAsyncPremium_membershipsService):
    """Service implementation for Premium_memberships"""

    def __init__(self):
        self.repository = Premium_membershipsRepository()

    async def get_by_id(self, id: str) -> Optional[Premium_memberships]:
        """Get premium_memberships by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting premium_memberships by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Premium_memberships]:
        """Get all premium_membershipss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all premium_membershipss: {str(e)}")
            raise

    async def create(self, data: Premium_memberships) -> Premium_memberships:
        """Create new premium_memberships"""
        try:
            return await self.repository.create(premium_memberships_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating premium_memberships: {str(e)}")
            raise

    async def update(self, id: str, data: Premium_memberships) -> Optional[Premium_memberships]:
        """Update premium_memberships"""
        try:
            return await self.repository.update(id, premium_memberships_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating premium_memberships: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete premium_memberships"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting premium_memberships: {str(e)}")
            raise
