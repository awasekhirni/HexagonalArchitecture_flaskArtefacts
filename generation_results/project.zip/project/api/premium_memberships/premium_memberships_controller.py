from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.premium_memberships.premium_memberships_entity import Premium_memberships
from domain.premium_memberships.premium_memberships_service_interface import IAsyncPremium_membershipsService
from api.dtos.premium_memberships_dto import Premium_membershipsCreate, Premium_membershipsUpdate, Premium_membershipsResponse
from api.mappers.premium_memberships_mapper import premium_memberships_mapper
from api.validations.premium_memberships_validation_schemas import validate_premium_memberships_create, validate_premium_memberships_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('premium_memberships', description='Premium_memberships operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
premium_memberships_create_model = api.model('Premium_membershipsCreate', {
    'name': fields.String(required=True, description='premium_memberships name'),
    'description': fields.String(description='premium_memberships description'),
    'status': fields.String(description='premium_memberships status', enum=['active', 'inactive', 'pending'])
})

premium_memberships_update_model = api.model('Premium_membershipsUpdate', {
    'name': fields.String(description='premium_memberships name'),
    'description': fields.String(description='premium_memberships description'),
    'status': fields.String(description='premium_memberships status', enum=['active', 'inactive', 'pending'])
})

premium_memberships_response_model = api.model('Premium_membershipsResponse', {
    'id': fields.String(description='premium_memberships ID'),
    'name': fields.String(description='premium_memberships name'),
    'description': fields.String(description='premium_memberships description'),
    'status': fields.String(description='premium_memberships status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPremium_membershipsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Premium_membershipsList(Resource):
        @api.doc('list_premium_membershipss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(premium_memberships_response_model)
        @token_required
        async def get(self):
            """List all premium_membershipss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [premium_memberships_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting premium_membershipss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_premium_memberships')
        @api.expect(premium_memberships_create_model)
        @api.marshal_with(premium_memberships_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new premium_memberships"""
            try:
                data = api.payload
                validated_data = validate_premium_memberships_create(data)
                entity = premium_memberships_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return premium_memberships_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating premium_memberships: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The premium_memberships identifier')
    @api.response(404, 'Premium_memberships not found')
    class Premium_membershipsResource(Resource):
        @api.doc('get_premium_memberships')
        @api.marshal_with(premium_memberships_response_model)
        @token_required
        async def get(self, id):
            """Get a premium_memberships given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Premium_memberships not found")
                return premium_memberships_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting premium_memberships {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_premium_memberships')
        @api.expect(premium_memberships_update_model)
        @api.marshal_with(premium_memberships_response_model)
        @token_required
        async def put(self, id):
            """Update a premium_memberships given its identifier"""
            try:
                data = api.payload
                validated_data = validate_premium_memberships_update(data)
                entity = premium_memberships_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Premium_memberships not found")
                return premium_memberships_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating premium_memberships {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_premium_memberships')
        @api.response(204, 'Premium_memberships deleted')
        @token_required
        async def delete(self, id):
            """Delete a premium_memberships given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Premium_memberships not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting premium_memberships {id}: {str(e)}")
                api.abort(400, str(e))

    return api
