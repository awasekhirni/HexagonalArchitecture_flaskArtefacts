from flask_restx import Api
from api.controllers.user_resumes_controller import initialize_controller as user_resumes_api
from api.controllers.audit_logs_controller import initialize_controller as audit_logs_api
from api.controllers.user_logins_controller import initialize_controller as user_logins_api
from api.controllers.review_tags_controller import initialize_controller as review_tags_api
from api.controllers.user_skills_controller import initialize_controller as user_skills_api
from api.controllers.podcasts_controller import initialize_controller as podcasts_api
from api.controllers.moderation_logs_controller import initialize_controller as moderation_logs_api
from api.controllers.mentorship_matches_controller import initialize_controller as mentorship_matches_api
from api.controllers.mentorship_sessions_controller import initialize_controller as mentorship_sessions_api
from api.controllers.blog_posts_controller import initialize_controller as blog_posts_api
from api.controllers.job_listings_controller import initialize_controller as job_listings_api
from api.controllers.user_encryption_keys_controller import initialize_controller as user_encryption_keys_api
from api.controllers.freelance_requests_controller import initialize_controller as freelance_requests_api
from api.controllers.saved_jobs_controller import initialize_controller as saved_jobs_api
from api.controllers.sponsored_content_controller import initialize_controller as sponsored_content_api
from api.controllers.user_followers_controller import initialize_controller as user_followers_api
from api.controllers.profile_access_audit_controller import initialize_controller as profile_access_audit_api
from api.controllers.user_achievements_controller import initialize_controller as user_achievements_api
from api.controllers.review_tag_map_controller import initialize_controller as review_tag_map_api
from api.controllers.mentions_controller import initialize_controller as mentions_api
from api.controllers.collaborations_controller import initialize_controller as collaborations_api
from api.controllers.jobs_controller import initialize_controller as jobs_api
from api.controllers.roles_controller import initialize_controller as roles_api
from api.controllers.user_tags_controller import initialize_controller as user_tags_api
from api.controllers.freelance_services_controller import initialize_controller as freelance_services_api
from api.controllers.moderators_controller import initialize_controller as moderators_api
from api.controllers.podcast_likes_controller import initialize_controller as podcast_likes_api
from api.controllers.project_tags_controller import initialize_controller as project_tags_api
from api.controllers.content_views_controller import initialize_controller as content_views_api
from api.controllers.user_engagements_controller import initialize_controller as user_engagements_api
from api.controllers.employee_documents_controller import initialize_controller as employee_documents_api
from api.controllers.skill_endorsements_controller import initialize_controller as skill_endorsements_api
from api.controllers.regional_cost_of_living_controller import initialize_controller as regional_cost_of_living_api
from api.controllers.mentors_controller import initialize_controller as mentors_api
from api.controllers.job_tag_map_controller import initialize_controller as job_tag_map_api
from api.controllers.events_controller import initialize_controller as events_api
from api.controllers.content_creator_monetization_controller import initialize_controller as content_creator_monetization_api
from api.controllers.regions_controller import initialize_controller as regions_api
from api.controllers.disciplinary_actions_controller import initialize_controller as disciplinary_actions_api
from api.controllers.employees_controller import initialize_controller as employees_api
from api.controllers.employee_resignations_controller import initialize_controller as employee_resignations_api
from api.controllers.groups_controller import initialize_controller as groups_api
from api.controllers.group_memberships_controller import initialize_controller as group_memberships_api
from api.controllers.messages_controller import initialize_controller as messages_api
from api.controllers.employee_benefits_controller import initialize_controller as employee_benefits_api
from api.controllers.ad_campaigns_controller import initialize_controller as ad_campaigns_api
from api.controllers.moderator_alerts_controller import initialize_controller as moderator_alerts_api
from api.controllers.content_recommendations_controller import initialize_controller as content_recommendations_api
from api.controllers.payroll_controller import initialize_controller as payroll_api
from api.controllers.group_discussion_comments_controller import initialize_controller as group_discussion_comments_api
from api.controllers.users_controller import initialize_controller as users_api
from api.controllers.political_affiliations_controller import initialize_controller as political_affiliations_api
from api.controllers.pre_interview_feedback_controller import initialize_controller as pre_interview_feedback_api
from api.controllers.project_skills_controller import initialize_controller as project_skills_api
from api.controllers.job_required_skills_controller import initialize_controller as job_required_skills_api
from api.controllers.user_job_history_controller import initialize_controller as user_job_history_api
from api.controllers.jwt_blacklist_controller import initialize_controller as jwt_blacklist_api
from api.controllers.projects_controller import initialize_controller as projects_api
from api.controllers.career_path_suggestions_controller import initialize_controller as career_path_suggestions_api
from api.controllers.skills_controller import initialize_controller as skills_api
from api.controllers.post_interview_feedback_controller import initialize_controller as post_interview_feedback_api
from api.controllers.podcast_comments_controller import initialize_controller as podcast_comments_api
from api.controllers.user_blocks_controller import initialize_controller as user_blocks_api
from api.controllers.leave_requests_controller import initialize_controller as leave_requests_api
from api.controllers.blog_comments_controller import initialize_controller as blog_comments_api
from api.controllers.ad_campaign_analytics_controller import initialize_controller as ad_campaign_analytics_api
from api.controllers.user_levels_controller import initialize_controller as user_levels_api
from api.controllers.feedback_controller import initialize_controller as feedback_api
from api.controllers.hr_notifications_controller import initialize_controller as hr_notifications_api
from api.controllers.job_applications_controller import initialize_controller as job_applications_api
from api.controllers.content_analytics_controller import initialize_controller as content_analytics_api
from api.controllers.user_reports_controller import initialize_controller as user_reports_api
from api.controllers.user_reputation_controller import initialize_controller as user_reputation_api
from api.controllers.influencer_article_likes_controller import initialize_controller as influencer_article_likes_api
from api.controllers.employee_trainings_controller import initialize_controller as employee_trainings_api
from api.controllers.interests_controller import initialize_controller as interests_api
from api.controllers.platform_analytics_controller import initialize_controller as platform_analytics_api
from api.controllers.professional_feed_controller import initialize_controller as professional_feed_api
from api.controllers.profile_visits_controller import initialize_controller as profile_visits_api
from api.controllers.blog_likes_controller import initialize_controller as blog_likes_api
from api.controllers.career_progression_controller import initialize_controller as career_progression_api
from api.controllers.premium_memberships_controller import initialize_controller as premium_memberships_api
from api.controllers.job_tags_controller import initialize_controller as job_tags_api
from api.controllers.professional_groups_controller import initialize_controller as professional_groups_api
from api.controllers.promotions_controller import initialize_controller as promotions_api
from api.controllers.recommendations_controller import initialize_controller as recommendations_api
from api.controllers.job_reviews_controller import initialize_controller as job_reviews_api
from api.controllers.learning_paths_controller import initialize_controller as learning_paths_api
from api.controllers.languages_controller import initialize_controller as languages_api
from api.controllers.project_interests_controller import initialize_controller as project_interests_api
from api.controllers.attendance_controller import initialize_controller as attendance_api
from api.controllers.event_attendees_controller import initialize_controller as event_attendees_api
from api.controllers.content_flags_controller import initialize_controller as content_flags_api
from api.controllers.influencer_article_tags_controller import initialize_controller as influencer_article_tags_api
from api.controllers.sponsored_content_analytics_controller import initialize_controller as sponsored_content_analytics_api
from api.controllers.industries_controller import initialize_controller as industries_api
from api.controllers.influencer_article_comments_controller import initialize_controller as influencer_article_comments_api
from api.controllers.performance_reviews_controller import initialize_controller as performance_reviews_api
from api.controllers.group_discussions_controller import initialize_controller as group_discussions_api
from api.controllers.notifications_controller import initialize_controller as notifications_api
from api.controllers.block_appeals_controller import initialize_controller as block_appeals_api
from api.controllers.company_culture_feedback_data_controller import initialize_controller as company_culture_feedback_data_api
from api.controllers.influencer_articles_controller import initialize_controller as influencer_articles_api
from api.controllers.user_connections_controller import initialize_controller as user_connections_api
from api.controllers.tags_controller import initialize_controller as tags_api
from api.controllers.user_feedback_tags_data_controller import initialize_controller as user_feedback_tags_data_api
from api.controllers.direct_messages_controller import initialize_controller as direct_messages_api
from application.services.user_resumes_service import User_resumesService

api = Api(
    title='Hexagonal Architecture API',
    version='1.0',
    description='API built with Hexagonal Architecture pattern',
    doc='/docs'
)

api.add_namespace(user_resumes_api(User_resumesService()), '/user_resumes')
api.add_namespace(audit_logs_api(Audit_logsService()), '/audit_logs')
api.add_namespace(user_logins_api(User_loginsService()), '/user_logins')
api.add_namespace(review_tags_api(Review_tagsService()), '/review_tags')
api.add_namespace(user_skills_api(User_skillsService()), '/user_skills')
api.add_namespace(podcasts_api(PodcastsService()), '/podcasts')
api.add_namespace(moderation_logs_api(Moderation_logsService()), '/moderation_logs')
api.add_namespace(mentorship_matches_api(Mentorship_matchesService()), '/mentorship_matches')
api.add_namespace(mentorship_sessions_api(Mentorship_sessionsService()), '/mentorship_sessions')
api.add_namespace(blog_posts_api(Blog_postsService()), '/blog_posts')
api.add_namespace(job_listings_api(Job_listingsService()), '/job_listings')
api.add_namespace(user_encryption_keys_api(User_encryption_keysService()), '/user_encryption_keys')
api.add_namespace(freelance_requests_api(Freelance_requestsService()), '/freelance_requests')
api.add_namespace(saved_jobs_api(Saved_jobsService()), '/saved_jobs')
api.add_namespace(sponsored_content_api(Sponsored_contentService()), '/sponsored_content')
api.add_namespace(user_followers_api(User_followersService()), '/user_followers')
api.add_namespace(profile_access_audit_api(Profile_access_auditService()), '/profile_access_audit')
api.add_namespace(user_achievements_api(User_achievementsService()), '/user_achievements')
api.add_namespace(review_tag_map_api(Review_tag_mapService()), '/review_tag_map')
api.add_namespace(mentions_api(MentionsService()), '/mentions')
api.add_namespace(collaborations_api(CollaborationsService()), '/collaborations')
api.add_namespace(jobs_api(JobsService()), '/jobs')
api.add_namespace(roles_api(RolesService()), '/roles')
api.add_namespace(user_tags_api(User_tagsService()), '/user_tags')
api.add_namespace(freelance_services_api(Freelance_servicesService()), '/freelance_services')
api.add_namespace(moderators_api(ModeratorsService()), '/moderators')
api.add_namespace(podcast_likes_api(Podcast_likesService()), '/podcast_likes')
api.add_namespace(project_tags_api(Project_tagsService()), '/project_tags')
api.add_namespace(content_views_api(Content_viewsService()), '/content_views')
api.add_namespace(user_engagements_api(User_engagementsService()), '/user_engagements')
api.add_namespace(employee_documents_api(Employee_documentsService()), '/employee_documents')
api.add_namespace(skill_endorsements_api(Skill_endorsementsService()), '/skill_endorsements')
api.add_namespace(regional_cost_of_living_api(Regional_cost_of_livingService()), '/regional_cost_of_living')
api.add_namespace(mentors_api(MentorsService()), '/mentors')
api.add_namespace(job_tag_map_api(Job_tag_mapService()), '/job_tag_map')
api.add_namespace(events_api(EventsService()), '/events')
api.add_namespace(content_creator_monetization_api(Content_creator_monetizationService()), '/content_creator_monetization')
api.add_namespace(regions_api(RegionsService()), '/regions')
api.add_namespace(disciplinary_actions_api(Disciplinary_actionsService()), '/disciplinary_actions')
api.add_namespace(employees_api(EmployeesService()), '/employees')
api.add_namespace(employee_resignations_api(Employee_resignationsService()), '/employee_resignations')
api.add_namespace(groups_api(GroupsService()), '/groups')
api.add_namespace(group_memberships_api(Group_membershipsService()), '/group_memberships')
api.add_namespace(messages_api(MessagesService()), '/messages')
api.add_namespace(employee_benefits_api(Employee_benefitsService()), '/employee_benefits')
api.add_namespace(ad_campaigns_api(Ad_campaignsService()), '/ad_campaigns')
api.add_namespace(moderator_alerts_api(Moderator_alertsService()), '/moderator_alerts')
api.add_namespace(content_recommendations_api(Content_recommendationsService()), '/content_recommendations')
api.add_namespace(payroll_api(PayrollService()), '/payroll')
api.add_namespace(group_discussion_comments_api(Group_discussion_commentsService()), '/group_discussion_comments')
api.add_namespace(users_api(UsersService()), '/users')
api.add_namespace(political_affiliations_api(Political_affiliationsService()), '/political_affiliations')
api.add_namespace(pre_interview_feedback_api(Pre_interview_feedbackService()), '/pre_interview_feedback')
api.add_namespace(project_skills_api(Project_skillsService()), '/project_skills')
api.add_namespace(job_required_skills_api(Job_required_skillsService()), '/job_required_skills')
api.add_namespace(user_job_history_api(User_job_historyService()), '/user_job_history')
api.add_namespace(jwt_blacklist_api(Jwt_blacklistService()), '/jwt_blacklist')
api.add_namespace(projects_api(ProjectsService()), '/projects')
api.add_namespace(career_path_suggestions_api(Career_path_suggestionsService()), '/career_path_suggestions')
api.add_namespace(skills_api(SkillsService()), '/skills')
api.add_namespace(post_interview_feedback_api(Post_interview_feedbackService()), '/post_interview_feedback')
api.add_namespace(podcast_comments_api(Podcast_commentsService()), '/podcast_comments')
api.add_namespace(user_blocks_api(User_blocksService()), '/user_blocks')
api.add_namespace(leave_requests_api(Leave_requestsService()), '/leave_requests')
api.add_namespace(blog_comments_api(Blog_commentsService()), '/blog_comments')
api.add_namespace(ad_campaign_analytics_api(Ad_campaign_analyticsService()), '/ad_campaign_analytics')
api.add_namespace(user_levels_api(User_levelsService()), '/user_levels')
api.add_namespace(feedback_api(FeedbackService()), '/feedback')
api.add_namespace(hr_notifications_api(Hr_notificationsService()), '/hr_notifications')
api.add_namespace(job_applications_api(Job_applicationsService()), '/job_applications')
api.add_namespace(content_analytics_api(Content_analyticsService()), '/content_analytics')
api.add_namespace(user_reports_api(User_reportsService()), '/user_reports')
api.add_namespace(user_reputation_api(User_reputationService()), '/user_reputation')
api.add_namespace(influencer_article_likes_api(Influencer_article_likesService()), '/influencer_article_likes')
api.add_namespace(employee_trainings_api(Employee_trainingsService()), '/employee_trainings')
api.add_namespace(interests_api(InterestsService()), '/interests')
api.add_namespace(platform_analytics_api(Platform_analyticsService()), '/platform_analytics')
api.add_namespace(professional_feed_api(Professional_feedService()), '/professional_feed')
api.add_namespace(profile_visits_api(Profile_visitsService()), '/profile_visits')
api.add_namespace(blog_likes_api(Blog_likesService()), '/blog_likes')
api.add_namespace(career_progression_api(Career_progressionService()), '/career_progression')
api.add_namespace(premium_memberships_api(Premium_membershipsService()), '/premium_memberships')
api.add_namespace(job_tags_api(Job_tagsService()), '/job_tags')
api.add_namespace(professional_groups_api(Professional_groupsService()), '/professional_groups')
api.add_namespace(promotions_api(PromotionsService()), '/promotions')
api.add_namespace(recommendations_api(RecommendationsService()), '/recommendations')
api.add_namespace(job_reviews_api(Job_reviewsService()), '/job_reviews')
api.add_namespace(learning_paths_api(Learning_pathsService()), '/learning_paths')
api.add_namespace(languages_api(LanguagesService()), '/languages')
api.add_namespace(project_interests_api(Project_interestsService()), '/project_interests')
api.add_namespace(attendance_api(AttendanceService()), '/attendance')
api.add_namespace(event_attendees_api(Event_attendeesService()), '/event_attendees')
api.add_namespace(content_flags_api(Content_flagsService()), '/content_flags')
api.add_namespace(influencer_article_tags_api(Influencer_article_tagsService()), '/influencer_article_tags')
api.add_namespace(sponsored_content_analytics_api(Sponsored_content_analyticsService()), '/sponsored_content_analytics')
api.add_namespace(industries_api(IndustriesService()), '/industries')
api.add_namespace(influencer_article_comments_api(Influencer_article_commentsService()), '/influencer_article_comments')
api.add_namespace(performance_reviews_api(Performance_reviewsService()), '/performance_reviews')
api.add_namespace(group_discussions_api(Group_discussionsService()), '/group_discussions')
api.add_namespace(notifications_api(NotificationsService()), '/notifications')
api.add_namespace(block_appeals_api(Block_appealsService()), '/block_appeals')
api.add_namespace(company_culture_feedback_data_api(Company_culture_feedback_dataService()), '/company_culture_feedback_data')
api.add_namespace(influencer_articles_api(Influencer_articlesService()), '/influencer_articles')
api.add_namespace(user_connections_api(User_connectionsService()), '/user_connections')
api.add_namespace(tags_api(TagsService()), '/tags')
api.add_namespace(user_feedback_tags_data_api(User_feedback_tags_dataService()), '/user_feedback_tags_data')
api.add_namespace(direct_messages_api(Direct_messagesService()), '/direct_messages')
