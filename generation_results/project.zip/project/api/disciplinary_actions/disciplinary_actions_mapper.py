from domain.disciplinary_actions.disciplinary_actions_entity import Disciplinary_actions
from api.dtos.disciplinary_actions_dto import Disciplinary_actionsCreate, Disciplinary_actionsUpdate, Disciplinary_actionsResponse
from typing import Union

class Disciplinary_actionsMapper:
    """Mapper for Disciplinary_actions between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Disciplinary_actions) -> Disciplinary_actionsResponse:
        """Convert entity to response DTO"""
        return Disciplinary_actionsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Disciplinary_actionsCreate, Disciplinary_actionsUpdate]) -> Disciplinary_actions:
        """Convert DTO to entity"""
        return Disciplinary_actions(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Disciplinary_actions, dto: Disciplinary_actionsUpdate) -> Disciplinary_actions:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

disciplinary_actions_mapper = Disciplinary_actionsMapper()
