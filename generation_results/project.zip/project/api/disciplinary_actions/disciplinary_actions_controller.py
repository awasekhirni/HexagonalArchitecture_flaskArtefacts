from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.disciplinary_actions.disciplinary_actions_entity import Disciplinary_actions
from domain.disciplinary_actions.disciplinary_actions_service_interface import IAsyncDisciplinary_actionsService
from api.dtos.disciplinary_actions_dto import Disciplinary_actionsCreate, Disciplinary_actionsUpdate, Disciplinary_actionsResponse
from api.mappers.disciplinary_actions_mapper import disciplinary_actions_mapper
from api.validations.disciplinary_actions_validation_schemas import validate_disciplinary_actions_create, validate_disciplinary_actions_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('disciplinary_actions', description='Disciplinary_actions operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
disciplinary_actions_create_model = api.model('Disciplinary_actionsCreate', {
    'name': fields.String(required=True, description='disciplinary_actions name'),
    'description': fields.String(description='disciplinary_actions description'),
    'status': fields.String(description='disciplinary_actions status', enum=['active', 'inactive', 'pending'])
})

disciplinary_actions_update_model = api.model('Disciplinary_actionsUpdate', {
    'name': fields.String(description='disciplinary_actions name'),
    'description': fields.String(description='disciplinary_actions description'),
    'status': fields.String(description='disciplinary_actions status', enum=['active', 'inactive', 'pending'])
})

disciplinary_actions_response_model = api.model('Disciplinary_actionsResponse', {
    'id': fields.String(description='disciplinary_actions ID'),
    'name': fields.String(description='disciplinary_actions name'),
    'description': fields.String(description='disciplinary_actions description'),
    'status': fields.String(description='disciplinary_actions status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncDisciplinary_actionsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Disciplinary_actionsList(Resource):
        @api.doc('list_disciplinary_actionss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(disciplinary_actions_response_model)
        @token_required
        async def get(self):
            """List all disciplinary_actionss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [disciplinary_actions_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting disciplinary_actionss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_disciplinary_actions')
        @api.expect(disciplinary_actions_create_model)
        @api.marshal_with(disciplinary_actions_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new disciplinary_actions"""
            try:
                data = api.payload
                validated_data = validate_disciplinary_actions_create(data)
                entity = disciplinary_actions_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return disciplinary_actions_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating disciplinary_actions: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The disciplinary_actions identifier')
    @api.response(404, 'Disciplinary_actions not found')
    class Disciplinary_actionsResource(Resource):
        @api.doc('get_disciplinary_actions')
        @api.marshal_with(disciplinary_actions_response_model)
        @token_required
        async def get(self, id):
            """Get a disciplinary_actions given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Disciplinary_actions not found")
                return disciplinary_actions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting disciplinary_actions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_disciplinary_actions')
        @api.expect(disciplinary_actions_update_model)
        @api.marshal_with(disciplinary_actions_response_model)
        @token_required
        async def put(self, id):
            """Update a disciplinary_actions given its identifier"""
            try:
                data = api.payload
                validated_data = validate_disciplinary_actions_update(data)
                entity = disciplinary_actions_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Disciplinary_actions not found")
                return disciplinary_actions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating disciplinary_actions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_disciplinary_actions')
        @api.response(204, 'Disciplinary_actions deleted')
        @token_required
        async def delete(self, id):
            """Delete a disciplinary_actions given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Disciplinary_actions not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting disciplinary_actions {id}: {str(e)}")
                api.abort(400, str(e))

    return api
