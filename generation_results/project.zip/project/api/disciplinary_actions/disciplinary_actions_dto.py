from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Disciplinary_actionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Disciplinary_actionsBase(BaseModel):
    """Base schema for disciplinary_actions"""
    pass

class Disciplinary_actionsCreate(Disciplinary_actionsBase):
    """Schema for creating disciplinary_actions"""
    name: str
    description: Optional[str] = None
    status: Disciplinary_actionsStatus = Disciplinary_actionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Disciplinary_actionsUpdate(Disciplinary_actionsBase):
    """Schema for updating disciplinary_actions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Disciplinary_actionsStatus] = None

class Disciplinary_actionsResponse(Disciplinary_actionsBase):
    """Response schema for disciplinary_actions"""
    id: str
    name: str
    description: Optional[str] = None
    status: Disciplinary_actionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_disciplinary_actions_create(data: Disciplinary_actionsCreate) -> Disciplinary_actionsCreate:
    """Validate disciplinary_actions creation data"""
    return data

def validate_disciplinary_actions_update(data: Disciplinary_actionsUpdate) -> Disciplinary_actionsUpdate:
    """Validate disciplinary_actions update data"""
    return data
