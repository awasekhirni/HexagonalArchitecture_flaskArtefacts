from typing import List, Optional
from domain.disciplinary_actions.disciplinary_actions_entity import Disciplinary_actions
from domain.disciplinary_actions.disciplinary_actions_service_interface import IAsyncDisciplinary_actionsService
from infrastructure.repositories.disciplinary_actions.disciplinary_actions_repository import Disciplinary_actionsRepository
from api.mappers.disciplinary_actions_mapper import disciplinary_actions_mapper
from shared.utils.logger import logger

class Disciplinary_actionsService(IAsyncDisciplinary_actionsService):
    """Service implementation for Disciplinary_actions"""

    def __init__(self):
        self.repository = Disciplinary_actionsRepository()

    async def get_by_id(self, id: str) -> Optional[Disciplinary_actions]:
        """Get disciplinary_actions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting disciplinary_actions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Disciplinary_actions]:
        """Get all disciplinary_actionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all disciplinary_actionss: {str(e)}")
            raise

    async def create(self, data: Disciplinary_actions) -> Disciplinary_actions:
        """Create new disciplinary_actions"""
        try:
            return await self.repository.create(disciplinary_actions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating disciplinary_actions: {str(e)}")
            raise

    async def update(self, id: str, data: Disciplinary_actions) -> Optional[Disciplinary_actions]:
        """Update disciplinary_actions"""
        try:
            return await self.repository.update(id, disciplinary_actions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating disciplinary_actions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete disciplinary_actions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting disciplinary_actions: {str(e)}")
            raise
