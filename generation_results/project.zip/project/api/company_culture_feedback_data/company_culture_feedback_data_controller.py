from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.company_culture_feedback_data.company_culture_feedback_data_entity import Company_culture_feedback_data
from domain.company_culture_feedback_data.company_culture_feedback_data_service_interface import IAsyncCompany_culture_feedback_dataService
from api.dtos.company_culture_feedback_data_dto import Company_culture_feedback_dataCreate, Company_culture_feedback_dataUpdate, Company_culture_feedback_dataResponse
from api.mappers.company_culture_feedback_data_mapper import company_culture_feedback_data_mapper
from api.validations.company_culture_feedback_data_validation_schemas import validate_company_culture_feedback_data_create, validate_company_culture_feedback_data_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('company_culture_feedback_data', description='Company_culture_feedback_data operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
company_culture_feedback_data_create_model = api.model('Company_culture_feedback_dataCreate', {
    'name': fields.String(required=True, description='company_culture_feedback_data name'),
    'description': fields.String(description='company_culture_feedback_data description'),
    'status': fields.String(description='company_culture_feedback_data status', enum=['active', 'inactive', 'pending'])
})

company_culture_feedback_data_update_model = api.model('Company_culture_feedback_dataUpdate', {
    'name': fields.String(description='company_culture_feedback_data name'),
    'description': fields.String(description='company_culture_feedback_data description'),
    'status': fields.String(description='company_culture_feedback_data status', enum=['active', 'inactive', 'pending'])
})

company_culture_feedback_data_response_model = api.model('Company_culture_feedback_dataResponse', {
    'id': fields.String(description='company_culture_feedback_data ID'),
    'name': fields.String(description='company_culture_feedback_data name'),
    'description': fields.String(description='company_culture_feedback_data description'),
    'status': fields.String(description='company_culture_feedback_data status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncCompany_culture_feedback_dataService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Company_culture_feedback_dataList(Resource):
        @api.doc('list_company_culture_feedback_datas')
        @api.expect(pagination_parser)
        @api.marshal_list_with(company_culture_feedback_data_response_model)
        @token_required
        async def get(self):
            """List all company_culture_feedback_datas"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [company_culture_feedback_data_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting company_culture_feedback_datas: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_company_culture_feedback_data')
        @api.expect(company_culture_feedback_data_create_model)
        @api.marshal_with(company_culture_feedback_data_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new company_culture_feedback_data"""
            try:
                data = api.payload
                validated_data = validate_company_culture_feedback_data_create(data)
                entity = company_culture_feedback_data_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return company_culture_feedback_data_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating company_culture_feedback_data: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The company_culture_feedback_data identifier')
    @api.response(404, 'Company_culture_feedback_data not found')
    class Company_culture_feedback_dataResource(Resource):
        @api.doc('get_company_culture_feedback_data')
        @api.marshal_with(company_culture_feedback_data_response_model)
        @token_required
        async def get(self, id):
            """Get a company_culture_feedback_data given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Company_culture_feedback_data not found")
                return company_culture_feedback_data_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting company_culture_feedback_data {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_company_culture_feedback_data')
        @api.expect(company_culture_feedback_data_update_model)
        @api.marshal_with(company_culture_feedback_data_response_model)
        @token_required
        async def put(self, id):
            """Update a company_culture_feedback_data given its identifier"""
            try:
                data = api.payload
                validated_data = validate_company_culture_feedback_data_update(data)
                entity = company_culture_feedback_data_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Company_culture_feedback_data not found")
                return company_culture_feedback_data_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating company_culture_feedback_data {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_company_culture_feedback_data')
        @api.response(204, 'Company_culture_feedback_data deleted')
        @token_required
        async def delete(self, id):
            """Delete a company_culture_feedback_data given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Company_culture_feedback_data not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting company_culture_feedback_data {id}: {str(e)}")
                api.abort(400, str(e))

    return api
