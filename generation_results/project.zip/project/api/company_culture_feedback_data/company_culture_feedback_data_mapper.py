from domain.company_culture_feedback_data.company_culture_feedback_data_entity import Company_culture_feedback_data
from api.dtos.company_culture_feedback_data_dto import Company_culture_feedback_dataCreate, Company_culture_feedback_dataUpdate, Company_culture_feedback_dataResponse
from typing import Union

class Company_culture_feedback_dataMapper:
    """Mapper for Company_culture_feedback_data between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Company_culture_feedback_data) -> Company_culture_feedback_dataResponse:
        """Convert entity to response DTO"""
        return Company_culture_feedback_dataResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Company_culture_feedback_dataCreate, Company_culture_feedback_dataUpdate]) -> Company_culture_feedback_data:
        """Convert DTO to entity"""
        return Company_culture_feedback_data(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Company_culture_feedback_data, dto: Company_culture_feedback_dataUpdate) -> Company_culture_feedback_data:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

company_culture_feedback_data_mapper = Company_culture_feedback_dataMapper()
