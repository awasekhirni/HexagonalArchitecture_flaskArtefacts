from typing import List, Optional
from domain.company_culture_feedback_data.company_culture_feedback_data_entity import Company_culture_feedback_data
from domain.company_culture_feedback_data.company_culture_feedback_data_service_interface import IAsyncCompany_culture_feedback_dataService
from infrastructure.repositories.company_culture_feedback_data.company_culture_feedback_data_repository import Company_culture_feedback_dataRepository
from api.mappers.company_culture_feedback_data_mapper import company_culture_feedback_data_mapper
from shared.utils.logger import logger

class Company_culture_feedback_dataService(IAsyncCompany_culture_feedback_dataService):
    """Service implementation for Company_culture_feedback_data"""

    def __init__(self):
        self.repository = Company_culture_feedback_dataRepository()

    async def get_by_id(self, id: str) -> Optional[Company_culture_feedback_data]:
        """Get company_culture_feedback_data by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting company_culture_feedback_data by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Company_culture_feedback_data]:
        """Get all company_culture_feedback_datas"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all company_culture_feedback_datas: {str(e)}")
            raise

    async def create(self, data: Company_culture_feedback_data) -> Company_culture_feedback_data:
        """Create new company_culture_feedback_data"""
        try:
            return await self.repository.create(company_culture_feedback_data_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating company_culture_feedback_data: {str(e)}")
            raise

    async def update(self, id: str, data: Company_culture_feedback_data) -> Optional[Company_culture_feedback_data]:
        """Update company_culture_feedback_data"""
        try:
            return await self.repository.update(id, company_culture_feedback_data_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating company_culture_feedback_data: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete company_culture_feedback_data"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting company_culture_feedback_data: {str(e)}")
            raise
