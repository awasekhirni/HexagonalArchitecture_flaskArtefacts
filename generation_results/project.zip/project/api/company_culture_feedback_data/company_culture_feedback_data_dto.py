from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Company_culture_feedback_dataStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Company_culture_feedback_dataBase(BaseModel):
    """Base schema for company_culture_feedback_data"""
    pass

class Company_culture_feedback_dataCreate(Company_culture_feedback_dataBase):
    """Schema for creating company_culture_feedback_data"""
    name: str
    description: Optional[str] = None
    status: Company_culture_feedback_dataStatus = Company_culture_feedback_dataStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Company_culture_feedback_dataUpdate(Company_culture_feedback_dataBase):
    """Schema for updating company_culture_feedback_data"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Company_culture_feedback_dataStatus] = None

class Company_culture_feedback_dataResponse(Company_culture_feedback_dataBase):
    """Response schema for company_culture_feedback_data"""
    id: str
    name: str
    description: Optional[str] = None
    status: Company_culture_feedback_dataStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_company_culture_feedback_data_create(data: Company_culture_feedback_dataCreate) -> Company_culture_feedback_dataCreate:
    """Validate company_culture_feedback_data creation data"""
    return data

def validate_company_culture_feedback_data_update(data: Company_culture_feedback_dataUpdate) -> Company_culture_feedback_dataUpdate:
    """Validate company_culture_feedback_data update data"""
    return data
