from typing import List, Optional
from domain.content_views.content_views_entity import Content_views
from domain.content_views.content_views_service_interface import IAsyncContent_viewsService
from infrastructure.repositories.content_views.content_views_repository import Content_viewsRepository
from api.mappers.content_views_mapper import content_views_mapper
from shared.utils.logger import logger

class Content_viewsService(IAsyncContent_viewsService):
    """Service implementation for Content_views"""

    def __init__(self):
        self.repository = Content_viewsRepository()

    async def get_by_id(self, id: str) -> Optional[Content_views]:
        """Get content_views by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting content_views by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Content_views]:
        """Get all content_viewss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all content_viewss: {str(e)}")
            raise

    async def create(self, data: Content_views) -> Content_views:
        """Create new content_views"""
        try:
            return await self.repository.create(content_views_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating content_views: {str(e)}")
            raise

    async def update(self, id: str, data: Content_views) -> Optional[Content_views]:
        """Update content_views"""
        try:
            return await self.repository.update(id, content_views_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating content_views: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete content_views"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting content_views: {str(e)}")
            raise
