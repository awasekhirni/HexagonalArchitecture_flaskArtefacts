from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Content_viewsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Content_viewsBase(BaseModel):
    """Base schema for content_views"""
    pass

class Content_viewsCreate(Content_viewsBase):
    """Schema for creating content_views"""
    name: str
    description: Optional[str] = None
    status: Content_viewsStatus = Content_viewsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Content_viewsUpdate(Content_viewsBase):
    """Schema for updating content_views"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Content_viewsStatus] = None

class Content_viewsResponse(Content_viewsBase):
    """Response schema for content_views"""
    id: str
    name: str
    description: Optional[str] = None
    status: Content_viewsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_content_views_create(data: Content_viewsCreate) -> Content_viewsCreate:
    """Validate content_views creation data"""
    return data

def validate_content_views_update(data: Content_viewsUpdate) -> Content_viewsUpdate:
    """Validate content_views update data"""
    return data
