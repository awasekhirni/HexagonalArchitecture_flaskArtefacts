from typing import List, Optional
from domain.user_logins.user_logins_entity import User_logins
from domain.user_logins.user_logins_service_interface import IAsyncUser_loginsService
from infrastructure.repositories.user_logins.user_logins_repository import User_loginsRepository
from api.mappers.user_logins_mapper import user_logins_mapper
from shared.utils.logger import logger

class User_loginsService(IAsyncUser_loginsService):
    """Service implementation for User_logins"""

    def __init__(self):
        self.repository = User_loginsRepository()

    async def get_by_id(self, id: str) -> Optional[User_logins]:
        """Get user_logins by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_logins by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_logins]:
        """Get all user_loginss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_loginss: {str(e)}")
            raise

    async def create(self, data: User_logins) -> User_logins:
        """Create new user_logins"""
        try:
            return await self.repository.create(user_logins_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_logins: {str(e)}")
            raise

    async def update(self, id: str, data: User_logins) -> Optional[User_logins]:
        """Update user_logins"""
        try:
            return await self.repository.update(id, user_logins_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_logins: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_logins"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_logins: {str(e)}")
            raise
