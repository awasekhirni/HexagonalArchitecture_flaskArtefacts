from domain.user_logins.user_logins_entity import User_logins
from api.dtos.user_logins_dto import User_loginsCreate, User_loginsUpdate, User_loginsResponse
from typing import Union

class User_loginsMapper:
    """Mapper for User_logins between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_logins) -> User_loginsResponse:
        """Convert entity to response DTO"""
        return User_loginsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_loginsCreate, User_loginsUpdate]) -> User_logins:
        """Convert DTO to entity"""
        return User_logins(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_logins, dto: User_loginsUpdate) -> User_logins:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_logins_mapper = User_loginsMapper()
