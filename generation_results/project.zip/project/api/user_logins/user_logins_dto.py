from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_loginsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_loginsBase(BaseModel):
    """Base schema for user_logins"""
    pass

class User_loginsCreate(User_loginsBase):
    """Schema for creating user_logins"""
    name: str
    description: Optional[str] = None
    status: User_loginsStatus = User_loginsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_loginsUpdate(User_loginsBase):
    """Schema for updating user_logins"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_loginsStatus] = None

class User_loginsResponse(User_loginsBase):
    """Response schema for user_logins"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_loginsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_logins_create(data: User_loginsCreate) -> User_loginsCreate:
    """Validate user_logins creation data"""
    return data

def validate_user_logins_update(data: User_loginsUpdate) -> User_loginsUpdate:
    """Validate user_logins update data"""
    return data
