from typing import List, Optional
from domain.jobs.jobs_entity import Jobs
from domain.jobs.jobs_service_interface import IAsyncJobsService
from infrastructure.repositories.jobs.jobs_repository import JobsRepository
from api.mappers.jobs_mapper import jobs_mapper
from shared.utils.logger import logger

class JobsService(IAsyncJobsService):
    """Service implementation for Jobs"""

    def __init__(self):
        self.repository = JobsRepository()

    async def get_by_id(self, id: str) -> Optional[Jobs]:
        """Get jobs by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting jobs by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Jobs]:
        """Get all jobss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all jobss: {str(e)}")
            raise

    async def create(self, data: Jobs) -> Jobs:
        """Create new jobs"""
        try:
            return await self.repository.create(jobs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating jobs: {str(e)}")
            raise

    async def update(self, id: str, data: Jobs) -> Optional[Jobs]:
        """Update jobs"""
        try:
            return await self.repository.update(id, jobs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating jobs: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete jobs"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting jobs: {str(e)}")
            raise
