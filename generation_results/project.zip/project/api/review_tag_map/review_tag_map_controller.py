from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.review_tag_map.review_tag_map_entity import Review_tag_map
from domain.review_tag_map.review_tag_map_service_interface import IAsyncReview_tag_mapService
from api.dtos.review_tag_map_dto import Review_tag_mapCreate, Review_tag_mapUpdate, Review_tag_mapResponse
from api.mappers.review_tag_map_mapper import review_tag_map_mapper
from api.validations.review_tag_map_validation_schemas import validate_review_tag_map_create, validate_review_tag_map_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('review_tag_map', description='Review_tag_map operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
review_tag_map_create_model = api.model('Review_tag_mapCreate', {
    'name': fields.String(required=True, description='review_tag_map name'),
    'description': fields.String(description='review_tag_map description'),
    'status': fields.String(description='review_tag_map status', enum=['active', 'inactive', 'pending'])
})

review_tag_map_update_model = api.model('Review_tag_mapUpdate', {
    'name': fields.String(description='review_tag_map name'),
    'description': fields.String(description='review_tag_map description'),
    'status': fields.String(description='review_tag_map status', enum=['active', 'inactive', 'pending'])
})

review_tag_map_response_model = api.model('Review_tag_mapResponse', {
    'id': fields.String(description='review_tag_map ID'),
    'name': fields.String(description='review_tag_map name'),
    'description': fields.String(description='review_tag_map description'),
    'status': fields.String(description='review_tag_map status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncReview_tag_mapService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Review_tag_mapList(Resource):
        @api.doc('list_review_tag_maps')
        @api.expect(pagination_parser)
        @api.marshal_list_with(review_tag_map_response_model)
        @token_required
        async def get(self):
            """List all review_tag_maps"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [review_tag_map_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting review_tag_maps: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_review_tag_map')
        @api.expect(review_tag_map_create_model)
        @api.marshal_with(review_tag_map_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new review_tag_map"""
            try:
                data = api.payload
                validated_data = validate_review_tag_map_create(data)
                entity = review_tag_map_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return review_tag_map_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating review_tag_map: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The review_tag_map identifier')
    @api.response(404, 'Review_tag_map not found')
    class Review_tag_mapResource(Resource):
        @api.doc('get_review_tag_map')
        @api.marshal_with(review_tag_map_response_model)
        @token_required
        async def get(self, id):
            """Get a review_tag_map given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Review_tag_map not found")
                return review_tag_map_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting review_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_review_tag_map')
        @api.expect(review_tag_map_update_model)
        @api.marshal_with(review_tag_map_response_model)
        @token_required
        async def put(self, id):
            """Update a review_tag_map given its identifier"""
            try:
                data = api.payload
                validated_data = validate_review_tag_map_update(data)
                entity = review_tag_map_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Review_tag_map not found")
                return review_tag_map_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating review_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_review_tag_map')
        @api.response(204, 'Review_tag_map deleted')
        @token_required
        async def delete(self, id):
            """Delete a review_tag_map given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Review_tag_map not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting review_tag_map {id}: {str(e)}")
                api.abort(400, str(e))

    return api
