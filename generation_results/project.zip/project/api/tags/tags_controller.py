from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.tags.tags_entity import Tags
from domain.tags.tags_service_interface import IAsyncTagsService
from api.dtos.tags_dto import TagsCreate, TagsUpdate, TagsResponse
from api.mappers.tags_mapper import tags_mapper
from api.validations.tags_validation_schemas import validate_tags_create, validate_tags_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('tags', description='Tags operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
tags_create_model = api.model('TagsCreate', {
    'name': fields.String(required=True, description='tags name'),
    'description': fields.String(description='tags description'),
    'status': fields.String(description='tags status', enum=['active', 'inactive', 'pending'])
})

tags_update_model = api.model('TagsUpdate', {
    'name': fields.String(description='tags name'),
    'description': fields.String(description='tags description'),
    'status': fields.String(description='tags status', enum=['active', 'inactive', 'pending'])
})

tags_response_model = api.model('TagsResponse', {
    'id': fields.String(description='tags ID'),
    'name': fields.String(description='tags name'),
    'description': fields.String(description='tags description'),
    'status': fields.String(description='tags status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncTagsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class TagsList(Resource):
        @api.doc('list_tagss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(tags_response_model)
        @token_required
        async def get(self):
            """List all tagss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [tags_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting tagss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_tags')
        @api.expect(tags_create_model)
        @api.marshal_with(tags_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new tags"""
            try:
                data = api.payload
                validated_data = validate_tags_create(data)
                entity = tags_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return tags_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating tags: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The tags identifier')
    @api.response(404, 'Tags not found')
    class TagsResource(Resource):
        @api.doc('get_tags')
        @api.marshal_with(tags_response_model)
        @token_required
        async def get(self, id):
            """Get a tags given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Tags not found")
                return tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_tags')
        @api.expect(tags_update_model)
        @api.marshal_with(tags_response_model)
        @token_required
        async def put(self, id):
            """Update a tags given its identifier"""
            try:
                data = api.payload
                validated_data = validate_tags_update(data)
                entity = tags_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Tags not found")
                return tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_tags')
        @api.response(204, 'Tags deleted')
        @token_required
        async def delete(self, id):
            """Delete a tags given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Tags not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting tags {id}: {str(e)}")
                api.abort(400, str(e))

    return api
