from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class TagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class TagsBase(BaseModel):
    """Base schema for tags"""
    pass

class TagsCreate(TagsBase):
    """Schema for creating tags"""
    name: str
    description: Optional[str] = None
    status: TagsStatus = TagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class TagsUpdate(TagsBase):
    """Schema for updating tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[TagsStatus] = None

class TagsResponse(TagsBase):
    """Response schema for tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: TagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_tags_create(data: TagsCreate) -> TagsCreate:
    """Validate tags creation data"""
    return data

def validate_tags_update(data: TagsUpdate) -> TagsUpdate:
    """Validate tags update data"""
    return data
