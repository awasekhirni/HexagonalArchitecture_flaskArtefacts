from typing import List, Optional
from domain.tags.tags_entity import Tags
from domain.tags.tags_service_interface import IAsyncTagsService
from infrastructure.repositories.tags.tags_repository import TagsRepository
from api.mappers.tags_mapper import tags_mapper
from shared.utils.logger import logger

class TagsService(IAsyncTagsService):
    """Service implementation for Tags"""

    def __init__(self):
        self.repository = TagsRepository()

    async def get_by_id(self, id: str) -> Optional[Tags]:
        """Get tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Tags]:
        """Get all tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all tagss: {str(e)}")
            raise

    async def create(self, data: Tags) -> Tags:
        """Create new tags"""
        try:
            return await self.repository.create(tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating tags: {str(e)}")
            raise

    async def update(self, id: str, data: Tags) -> Optional[Tags]:
        """Update tags"""
        try:
            return await self.repository.update(id, tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting tags: {str(e)}")
            raise
