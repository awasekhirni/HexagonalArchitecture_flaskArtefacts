from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.moderators.moderators_entity import Moderators
from domain.moderators.moderators_service_interface import IAsyncModeratorsService
from api.dtos.moderators_dto import ModeratorsCreate, ModeratorsUpdate, ModeratorsResponse
from api.mappers.moderators_mapper import moderators_mapper
from api.validations.moderators_validation_schemas import validate_moderators_create, validate_moderators_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('moderators', description='Moderators operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
moderators_create_model = api.model('ModeratorsCreate', {
    'name': fields.String(required=True, description='moderators name'),
    'description': fields.String(description='moderators description'),
    'status': fields.String(description='moderators status', enum=['active', 'inactive', 'pending'])
})

moderators_update_model = api.model('ModeratorsUpdate', {
    'name': fields.String(description='moderators name'),
    'description': fields.String(description='moderators description'),
    'status': fields.String(description='moderators status', enum=['active', 'inactive', 'pending'])
})

moderators_response_model = api.model('ModeratorsResponse', {
    'id': fields.String(description='moderators ID'),
    'name': fields.String(description='moderators name'),
    'description': fields.String(description='moderators description'),
    'status': fields.String(description='moderators status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncModeratorsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class ModeratorsList(Resource):
        @api.doc('list_moderatorss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(moderators_response_model)
        @token_required
        async def get(self):
            """List all moderatorss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [moderators_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting moderatorss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_moderators')
        @api.expect(moderators_create_model)
        @api.marshal_with(moderators_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new moderators"""
            try:
                data = api.payload
                validated_data = validate_moderators_create(data)
                entity = moderators_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return moderators_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating moderators: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The moderators identifier')
    @api.response(404, 'Moderators not found')
    class ModeratorsResource(Resource):
        @api.doc('get_moderators')
        @api.marshal_with(moderators_response_model)
        @token_required
        async def get(self, id):
            """Get a moderators given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Moderators not found")
                return moderators_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting moderators {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_moderators')
        @api.expect(moderators_update_model)
        @api.marshal_with(moderators_response_model)
        @token_required
        async def put(self, id):
            """Update a moderators given its identifier"""
            try:
                data = api.payload
                validated_data = validate_moderators_update(data)
                entity = moderators_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Moderators not found")
                return moderators_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating moderators {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_moderators')
        @api.response(204, 'Moderators deleted')
        @token_required
        async def delete(self, id):
            """Delete a moderators given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Moderators not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting moderators {id}: {str(e)}")
                api.abort(400, str(e))

    return api
