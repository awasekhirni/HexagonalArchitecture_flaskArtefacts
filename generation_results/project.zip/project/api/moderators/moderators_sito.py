from typing import List, Optional
from domain.moderators.moderators_entity import Moderators
from domain.moderators.moderators_service_interface import IAsyncModeratorsService
from infrastructure.repositories.moderators.moderators_repository import ModeratorsRepository
from api.mappers.moderators_mapper import moderators_mapper
from shared.utils.logger import logger

class ModeratorsService(IAsyncModeratorsService):
    """Service implementation for Moderators"""

    def __init__(self):
        self.repository = ModeratorsRepository()

    async def get_by_id(self, id: str) -> Optional[Moderators]:
        """Get moderators by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting moderators by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Moderators]:
        """Get all moderatorss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all moderatorss: {str(e)}")
            raise

    async def create(self, data: Moderators) -> Moderators:
        """Create new moderators"""
        try:
            return await self.repository.create(moderators_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating moderators: {str(e)}")
            raise

    async def update(self, id: str, data: Moderators) -> Optional[Moderators]:
        """Update moderators"""
        try:
            return await self.repository.update(id, moderators_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating moderators: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete moderators"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting moderators: {str(e)}")
            raise
