from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class ModeratorsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class ModeratorsBase(BaseModel):
    """Base schema for moderators"""
    pass

class ModeratorsCreate(ModeratorsBase):
    """Schema for creating moderators"""
    name: str
    description: Optional[str] = None
    status: ModeratorsStatus = ModeratorsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class ModeratorsUpdate(ModeratorsBase):
    """Schema for updating moderators"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ModeratorsStatus] = None

class ModeratorsResponse(ModeratorsBase):
    """Response schema for moderators"""
    id: str
    name: str
    description: Optional[str] = None
    status: ModeratorsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_moderators_create(data: ModeratorsCreate) -> ModeratorsCreate:
    """Validate moderators creation data"""
    return data

def validate_moderators_update(data: ModeratorsUpdate) -> ModeratorsUpdate:
    """Validate moderators update data"""
    return data
