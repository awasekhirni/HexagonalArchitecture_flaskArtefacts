from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.recommendations.recommendations_entity import Recommendations
from domain.recommendations.recommendations_service_interface import IAsyncRecommendationsService
from api.dtos.recommendations_dto import RecommendationsCreate, RecommendationsUpdate, RecommendationsResponse
from api.mappers.recommendations_mapper import recommendations_mapper
from api.validations.recommendations_validation_schemas import validate_recommendations_create, validate_recommendations_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('recommendations', description='Recommendations operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
recommendations_create_model = api.model('RecommendationsCreate', {
    'name': fields.String(required=True, description='recommendations name'),
    'description': fields.String(description='recommendations description'),
    'status': fields.String(description='recommendations status', enum=['active', 'inactive', 'pending'])
})

recommendations_update_model = api.model('RecommendationsUpdate', {
    'name': fields.String(description='recommendations name'),
    'description': fields.String(description='recommendations description'),
    'status': fields.String(description='recommendations status', enum=['active', 'inactive', 'pending'])
})

recommendations_response_model = api.model('RecommendationsResponse', {
    'id': fields.String(description='recommendations ID'),
    'name': fields.String(description='recommendations name'),
    'description': fields.String(description='recommendations description'),
    'status': fields.String(description='recommendations status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncRecommendationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class RecommendationsList(Resource):
        @api.doc('list_recommendationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(recommendations_response_model)
        @token_required
        async def get(self):
            """List all recommendationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [recommendations_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting recommendationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_recommendations')
        @api.expect(recommendations_create_model)
        @api.marshal_with(recommendations_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new recommendations"""
            try:
                data = api.payload
                validated_data = validate_recommendations_create(data)
                entity = recommendations_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return recommendations_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating recommendations: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The recommendations identifier')
    @api.response(404, 'Recommendations not found')
    class RecommendationsResource(Resource):
        @api.doc('get_recommendations')
        @api.marshal_with(recommendations_response_model)
        @token_required
        async def get(self, id):
            """Get a recommendations given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Recommendations not found")
                return recommendations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting recommendations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_recommendations')
        @api.expect(recommendations_update_model)
        @api.marshal_with(recommendations_response_model)
        @token_required
        async def put(self, id):
            """Update a recommendations given its identifier"""
            try:
                data = api.payload
                validated_data = validate_recommendations_update(data)
                entity = recommendations_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Recommendations not found")
                return recommendations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating recommendations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_recommendations')
        @api.response(204, 'Recommendations deleted')
        @token_required
        async def delete(self, id):
            """Delete a recommendations given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Recommendations not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting recommendations {id}: {str(e)}")
                api.abort(400, str(e))

    return api
