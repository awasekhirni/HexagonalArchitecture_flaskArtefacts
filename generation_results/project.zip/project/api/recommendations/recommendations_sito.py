from typing import List, Optional
from domain.recommendations.recommendations_entity import Recommendations
from domain.recommendations.recommendations_service_interface import IAsyncRecommendationsService
from infrastructure.repositories.recommendations.recommendations_repository import RecommendationsRepository
from api.mappers.recommendations_mapper import recommendations_mapper
from shared.utils.logger import logger

class RecommendationsService(IAsyncRecommendationsService):
    """Service implementation for Recommendations"""

    def __init__(self):
        self.repository = RecommendationsRepository()

    async def get_by_id(self, id: str) -> Optional[Recommendations]:
        """Get recommendations by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting recommendations by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Recommendations]:
        """Get all recommendationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all recommendationss: {str(e)}")
            raise

    async def create(self, data: Recommendations) -> Recommendations:
        """Create new recommendations"""
        try:
            return await self.repository.create(recommendations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating recommendations: {str(e)}")
            raise

    async def update(self, id: str, data: Recommendations) -> Optional[Recommendations]:
        """Update recommendations"""
        try:
            return await self.repository.update(id, recommendations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating recommendations: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete recommendations"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting recommendations: {str(e)}")
            raise
