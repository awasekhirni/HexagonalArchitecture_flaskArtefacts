from typing import List, Optional
from domain.job_listings.job_listings_entity import Job_listings
from domain.job_listings.job_listings_service_interface import IAsyncJob_listingsService
from infrastructure.repositories.job_listings.job_listings_repository import Job_listingsRepository
from api.mappers.job_listings_mapper import job_listings_mapper
from shared.utils.logger import logger

class Job_listingsService(IAsyncJob_listingsService):
    """Service implementation for Job_listings"""

    def __init__(self):
        self.repository = Job_listingsRepository()

    async def get_by_id(self, id: str) -> Optional[Job_listings]:
        """Get job_listings by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting job_listings by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Job_listings]:
        """Get all job_listingss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all job_listingss: {str(e)}")
            raise

    async def create(self, data: Job_listings) -> Job_listings:
        """Create new job_listings"""
        try:
            return await self.repository.create(job_listings_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating job_listings: {str(e)}")
            raise

    async def update(self, id: str, data: Job_listings) -> Optional[Job_listings]:
        """Update job_listings"""
        try:
            return await self.repository.update(id, job_listings_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating job_listings: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete job_listings"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting job_listings: {str(e)}")
            raise
