from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Job_listingsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Job_listingsBase(BaseModel):
    """Base schema for job_listings"""
    pass

class Job_listingsCreate(Job_listingsBase):
    """Schema for creating job_listings"""
    name: str
    description: Optional[str] = None
    status: Job_listingsStatus = Job_listingsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Job_listingsUpdate(Job_listingsBase):
    """Schema for updating job_listings"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Job_listingsStatus] = None

class Job_listingsResponse(Job_listingsBase):
    """Response schema for job_listings"""
    id: str
    name: str
    description: Optional[str] = None
    status: Job_listingsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_job_listings_create(data: Job_listingsCreate) -> Job_listingsCreate:
    """Validate job_listings creation data"""
    return data

def validate_job_listings_update(data: Job_listingsUpdate) -> Job_listingsUpdate:
    """Validate job_listings update data"""
    return data
