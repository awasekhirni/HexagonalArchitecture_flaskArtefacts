from domain.job_listings.job_listings_entity import Job_listings
from api.dtos.job_listings_dto import Job_listingsCreate, Job_listingsUpdate, Job_listingsResponse
from typing import Union

class Job_listingsMapper:
    """Mapper for Job_listings between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Job_listings) -> Job_listingsResponse:
        """Convert entity to response DTO"""
        return Job_listingsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Job_listingsCreate, Job_listingsUpdate]) -> Job_listings:
        """Convert DTO to entity"""
        return Job_listings(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Job_listings, dto: Job_listingsUpdate) -> Job_listings:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

job_listings_mapper = Job_listingsMapper()
