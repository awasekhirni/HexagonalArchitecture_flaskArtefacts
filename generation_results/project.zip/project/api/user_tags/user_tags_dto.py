from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_tagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_tagsBase(BaseModel):
    """Base schema for user_tags"""
    pass

class User_tagsCreate(User_tagsBase):
    """Schema for creating user_tags"""
    name: str
    description: Optional[str] = None
    status: User_tagsStatus = User_tagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_tagsUpdate(User_tagsBase):
    """Schema for updating user_tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_tagsStatus] = None

class User_tagsResponse(User_tagsBase):
    """Response schema for user_tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_tagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_tags_create(data: User_tagsCreate) -> User_tagsCreate:
    """Validate user_tags creation data"""
    return data

def validate_user_tags_update(data: User_tagsUpdate) -> User_tagsUpdate:
    """Validate user_tags update data"""
    return data
