from typing import List, Optional
from domain.user_tags.user_tags_entity import User_tags
from domain.user_tags.user_tags_service_interface import IAsyncUser_tagsService
from infrastructure.repositories.user_tags.user_tags_repository import User_tagsRepository
from api.mappers.user_tags_mapper import user_tags_mapper
from shared.utils.logger import logger

class User_tagsService(IAsyncUser_tagsService):
    """Service implementation for User_tags"""

    def __init__(self):
        self.repository = User_tagsRepository()

    async def get_by_id(self, id: str) -> Optional[User_tags]:
        """Get user_tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_tags]:
        """Get all user_tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_tagss: {str(e)}")
            raise

    async def create(self, data: User_tags) -> User_tags:
        """Create new user_tags"""
        try:
            return await self.repository.create(user_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_tags: {str(e)}")
            raise

    async def update(self, id: str, data: User_tags) -> Optional[User_tags]:
        """Update user_tags"""
        try:
            return await self.repository.update(id, user_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_tags: {str(e)}")
            raise
