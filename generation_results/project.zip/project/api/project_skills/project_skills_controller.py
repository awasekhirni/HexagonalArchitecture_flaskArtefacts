from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.project_skills.project_skills_entity import Project_skills
from domain.project_skills.project_skills_service_interface import IAsyncProject_skillsService
from api.dtos.project_skills_dto import Project_skillsCreate, Project_skillsUpdate, Project_skillsResponse
from api.mappers.project_skills_mapper import project_skills_mapper
from api.validations.project_skills_validation_schemas import validate_project_skills_create, validate_project_skills_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('project_skills', description='Project_skills operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
project_skills_create_model = api.model('Project_skillsCreate', {
    'name': fields.String(required=True, description='project_skills name'),
    'description': fields.String(description='project_skills description'),
    'status': fields.String(description='project_skills status', enum=['active', 'inactive', 'pending'])
})

project_skills_update_model = api.model('Project_skillsUpdate', {
    'name': fields.String(description='project_skills name'),
    'description': fields.String(description='project_skills description'),
    'status': fields.String(description='project_skills status', enum=['active', 'inactive', 'pending'])
})

project_skills_response_model = api.model('Project_skillsResponse', {
    'id': fields.String(description='project_skills ID'),
    'name': fields.String(description='project_skills name'),
    'description': fields.String(description='project_skills description'),
    'status': fields.String(description='project_skills status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProject_skillsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Project_skillsList(Resource):
        @api.doc('list_project_skillss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(project_skills_response_model)
        @token_required
        async def get(self):
            """List all project_skillss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [project_skills_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting project_skillss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_project_skills')
        @api.expect(project_skills_create_model)
        @api.marshal_with(project_skills_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new project_skills"""
            try:
                data = api.payload
                validated_data = validate_project_skills_create(data)
                entity = project_skills_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return project_skills_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating project_skills: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The project_skills identifier')
    @api.response(404, 'Project_skills not found')
    class Project_skillsResource(Resource):
        @api.doc('get_project_skills')
        @api.marshal_with(project_skills_response_model)
        @token_required
        async def get(self, id):
            """Get a project_skills given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Project_skills not found")
                return project_skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting project_skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_project_skills')
        @api.expect(project_skills_update_model)
        @api.marshal_with(project_skills_response_model)
        @token_required
        async def put(self, id):
            """Update a project_skills given its identifier"""
            try:
                data = api.payload
                validated_data = validate_project_skills_update(data)
                entity = project_skills_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Project_skills not found")
                return project_skills_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating project_skills {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_project_skills')
        @api.response(204, 'Project_skills deleted')
        @token_required
        async def delete(self, id):
            """Delete a project_skills given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Project_skills not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting project_skills {id}: {str(e)}")
                api.abort(400, str(e))

    return api
