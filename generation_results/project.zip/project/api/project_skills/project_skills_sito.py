from typing import List, Optional
from domain.project_skills.project_skills_entity import Project_skills
from domain.project_skills.project_skills_service_interface import IAsyncProject_skillsService
from infrastructure.repositories.project_skills.project_skills_repository import Project_skillsRepository
from api.mappers.project_skills_mapper import project_skills_mapper
from shared.utils.logger import logger

class Project_skillsService(IAsyncProject_skillsService):
    """Service implementation for Project_skills"""

    def __init__(self):
        self.repository = Project_skillsRepository()

    async def get_by_id(self, id: str) -> Optional[Project_skills]:
        """Get project_skills by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting project_skills by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Project_skills]:
        """Get all project_skillss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all project_skillss: {str(e)}")
            raise

    async def create(self, data: Project_skills) -> Project_skills:
        """Create new project_skills"""
        try:
            return await self.repository.create(project_skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating project_skills: {str(e)}")
            raise

    async def update(self, id: str, data: Project_skills) -> Optional[Project_skills]:
        """Update project_skills"""
        try:
            return await self.repository.update(id, project_skills_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating project_skills: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete project_skills"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting project_skills: {str(e)}")
            raise
