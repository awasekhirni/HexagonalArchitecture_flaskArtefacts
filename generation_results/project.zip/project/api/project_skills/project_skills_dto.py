from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Project_skillsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Project_skillsBase(BaseModel):
    """Base schema for project_skills"""
    pass

class Project_skillsCreate(Project_skillsBase):
    """Schema for creating project_skills"""
    name: str
    description: Optional[str] = None
    status: Project_skillsStatus = Project_skillsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Project_skillsUpdate(Project_skillsBase):
    """Schema for updating project_skills"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Project_skillsStatus] = None

class Project_skillsResponse(Project_skillsBase):
    """Response schema for project_skills"""
    id: str
    name: str
    description: Optional[str] = None
    status: Project_skillsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_project_skills_create(data: Project_skillsCreate) -> Project_skillsCreate:
    """Validate project_skills creation data"""
    return data

def validate_project_skills_update(data: Project_skillsUpdate) -> Project_skillsUpdate:
    """Validate project_skills update data"""
    return data
