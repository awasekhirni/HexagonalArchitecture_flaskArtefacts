from typing import List, Optional
from domain.industries.industries_entity import Industries
from domain.industries.industries_service_interface import IAsyncIndustriesService
from infrastructure.repositories.industries.industries_repository import IndustriesRepository
from api.mappers.industries_mapper import industries_mapper
from shared.utils.logger import logger

class IndustriesService(IAsyncIndustriesService):
    """Service implementation for Industries"""

    def __init__(self):
        self.repository = IndustriesRepository()

    async def get_by_id(self, id: str) -> Optional[Industries]:
        """Get industries by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting industries by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Industries]:
        """Get all industriess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all industriess: {str(e)}")
            raise

    async def create(self, data: Industries) -> Industries:
        """Create new industries"""
        try:
            return await self.repository.create(industries_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating industries: {str(e)}")
            raise

    async def update(self, id: str, data: Industries) -> Optional[Industries]:
        """Update industries"""
        try:
            return await self.repository.update(id, industries_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating industries: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete industries"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting industries: {str(e)}")
            raise
