from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.industries.industries_entity import Industries
from domain.industries.industries_service_interface import IAsyncIndustriesService
from api.dtos.industries_dto import IndustriesCreate, IndustriesUpdate, IndustriesResponse
from api.mappers.industries_mapper import industries_mapper
from api.validations.industries_validation_schemas import validate_industries_create, validate_industries_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('industries', description='Industries operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
industries_create_model = api.model('IndustriesCreate', {
    'name': fields.String(required=True, description='industries name'),
    'description': fields.String(description='industries description'),
    'status': fields.String(description='industries status', enum=['active', 'inactive', 'pending'])
})

industries_update_model = api.model('IndustriesUpdate', {
    'name': fields.String(description='industries name'),
    'description': fields.String(description='industries description'),
    'status': fields.String(description='industries status', enum=['active', 'inactive', 'pending'])
})

industries_response_model = api.model('IndustriesResponse', {
    'id': fields.String(description='industries ID'),
    'name': fields.String(description='industries name'),
    'description': fields.String(description='industries description'),
    'status': fields.String(description='industries status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncIndustriesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class IndustriesList(Resource):
        @api.doc('list_industriess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(industries_response_model)
        @token_required
        async def get(self):
            """List all industriess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [industries_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting industriess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_industries')
        @api.expect(industries_create_model)
        @api.marshal_with(industries_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new industries"""
            try:
                data = api.payload
                validated_data = validate_industries_create(data)
                entity = industries_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return industries_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating industries: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The industries identifier')
    @api.response(404, 'Industries not found')
    class IndustriesResource(Resource):
        @api.doc('get_industries')
        @api.marshal_with(industries_response_model)
        @token_required
        async def get(self, id):
            """Get a industries given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Industries not found")
                return industries_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting industries {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_industries')
        @api.expect(industries_update_model)
        @api.marshal_with(industries_response_model)
        @token_required
        async def put(self, id):
            """Update a industries given its identifier"""
            try:
                data = api.payload
                validated_data = validate_industries_update(data)
                entity = industries_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Industries not found")
                return industries_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating industries {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_industries')
        @api.response(204, 'Industries deleted')
        @token_required
        async def delete(self, id):
            """Delete a industries given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Industries not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting industries {id}: {str(e)}")
                api.abort(400, str(e))

    return api
