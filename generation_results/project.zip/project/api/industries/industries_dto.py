from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class IndustriesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class IndustriesBase(BaseModel):
    """Base schema for industries"""
    pass

class IndustriesCreate(IndustriesBase):
    """Schema for creating industries"""
    name: str
    description: Optional[str] = None
    status: IndustriesStatus = IndustriesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class IndustriesUpdate(IndustriesBase):
    """Schema for updating industries"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[IndustriesStatus] = None

class IndustriesResponse(IndustriesBase):
    """Response schema for industries"""
    id: str
    name: str
    description: Optional[str] = None
    status: IndustriesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_industries_create(data: IndustriesCreate) -> IndustriesCreate:
    """Validate industries creation data"""
    return data

def validate_industries_update(data: IndustriesUpdate) -> IndustriesUpdate:
    """Validate industries update data"""
    return data
