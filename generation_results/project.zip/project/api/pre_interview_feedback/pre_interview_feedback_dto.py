from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Pre_interview_feedbackStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Pre_interview_feedbackBase(BaseModel):
    """Base schema for pre_interview_feedback"""
    pass

class Pre_interview_feedbackCreate(Pre_interview_feedbackBase):
    """Schema for creating pre_interview_feedback"""
    name: str
    description: Optional[str] = None
    status: Pre_interview_feedbackStatus = Pre_interview_feedbackStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Pre_interview_feedbackUpdate(Pre_interview_feedbackBase):
    """Schema for updating pre_interview_feedback"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Pre_interview_feedbackStatus] = None

class Pre_interview_feedbackResponse(Pre_interview_feedbackBase):
    """Response schema for pre_interview_feedback"""
    id: str
    name: str
    description: Optional[str] = None
    status: Pre_interview_feedbackStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_pre_interview_feedback_create(data: Pre_interview_feedbackCreate) -> Pre_interview_feedbackCreate:
    """Validate pre_interview_feedback creation data"""
    return data

def validate_pre_interview_feedback_update(data: Pre_interview_feedbackUpdate) -> Pre_interview_feedbackUpdate:
    """Validate pre_interview_feedback update data"""
    return data
