from typing import List, Optional
from domain.pre_interview_feedback.pre_interview_feedback_entity import Pre_interview_feedback
from domain.pre_interview_feedback.pre_interview_feedback_service_interface import IAsyncPre_interview_feedbackService
from infrastructure.repositories.pre_interview_feedback.pre_interview_feedback_repository import Pre_interview_feedbackRepository
from api.mappers.pre_interview_feedback_mapper import pre_interview_feedback_mapper
from shared.utils.logger import logger

class Pre_interview_feedbackService(IAsyncPre_interview_feedbackService):
    """Service implementation for Pre_interview_feedback"""

    def __init__(self):
        self.repository = Pre_interview_feedbackRepository()

    async def get_by_id(self, id: str) -> Optional[Pre_interview_feedback]:
        """Get pre_interview_feedback by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting pre_interview_feedback by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Pre_interview_feedback]:
        """Get all pre_interview_feedbacks"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all pre_interview_feedbacks: {str(e)}")
            raise

    async def create(self, data: Pre_interview_feedback) -> Pre_interview_feedback:
        """Create new pre_interview_feedback"""
        try:
            return await self.repository.create(pre_interview_feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating pre_interview_feedback: {str(e)}")
            raise

    async def update(self, id: str, data: Pre_interview_feedback) -> Optional[Pre_interview_feedback]:
        """Update pre_interview_feedback"""
        try:
            return await self.repository.update(id, pre_interview_feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating pre_interview_feedback: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete pre_interview_feedback"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting pre_interview_feedback: {str(e)}")
            raise
