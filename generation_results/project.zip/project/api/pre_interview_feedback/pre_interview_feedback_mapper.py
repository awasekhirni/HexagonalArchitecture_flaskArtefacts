from domain.pre_interview_feedback.pre_interview_feedback_entity import Pre_interview_feedback
from api.dtos.pre_interview_feedback_dto import Pre_interview_feedbackCreate, Pre_interview_feedbackUpdate, Pre_interview_feedbackResponse
from typing import Union

class Pre_interview_feedbackMapper:
    """Mapper for Pre_interview_feedback between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Pre_interview_feedback) -> Pre_interview_feedbackResponse:
        """Convert entity to response DTO"""
        return Pre_interview_feedbackResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Pre_interview_feedbackCreate, Pre_interview_feedbackUpdate]) -> Pre_interview_feedback:
        """Convert DTO to entity"""
        return Pre_interview_feedback(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Pre_interview_feedback, dto: Pre_interview_feedbackUpdate) -> Pre_interview_feedback:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

pre_interview_feedback_mapper = Pre_interview_feedbackMapper()
