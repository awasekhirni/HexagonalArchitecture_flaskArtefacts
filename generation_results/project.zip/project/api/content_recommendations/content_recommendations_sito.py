from typing import List, Optional
from domain.content_recommendations.content_recommendations_entity import Content_recommendations
from domain.content_recommendations.content_recommendations_service_interface import IAsyncContent_recommendationsService
from infrastructure.repositories.content_recommendations.content_recommendations_repository import Content_recommendationsRepository
from api.mappers.content_recommendations_mapper import content_recommendations_mapper
from shared.utils.logger import logger

class Content_recommendationsService(IAsyncContent_recommendationsService):
    """Service implementation for Content_recommendations"""

    def __init__(self):
        self.repository = Content_recommendationsRepository()

    async def get_by_id(self, id: str) -> Optional[Content_recommendations]:
        """Get content_recommendations by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting content_recommendations by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Content_recommendations]:
        """Get all content_recommendationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all content_recommendationss: {str(e)}")
            raise

    async def create(self, data: Content_recommendations) -> Content_recommendations:
        """Create new content_recommendations"""
        try:
            return await self.repository.create(content_recommendations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating content_recommendations: {str(e)}")
            raise

    async def update(self, id: str, data: Content_recommendations) -> Optional[Content_recommendations]:
        """Update content_recommendations"""
        try:
            return await self.repository.update(id, content_recommendations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating content_recommendations: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete content_recommendations"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting content_recommendations: {str(e)}")
            raise
