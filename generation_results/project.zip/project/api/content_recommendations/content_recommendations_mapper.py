from domain.content_recommendations.content_recommendations_entity import Content_recommendations
from api.dtos.content_recommendations_dto import Content_recommendationsCreate, Content_recommendationsUpdate, Content_recommendationsResponse
from typing import Union

class Content_recommendationsMapper:
    """Mapper for Content_recommendations between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Content_recommendations) -> Content_recommendationsResponse:
        """Convert entity to response DTO"""
        return Content_recommendationsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Content_recommendationsCreate, Content_recommendationsUpdate]) -> Content_recommendations:
        """Convert DTO to entity"""
        return Content_recommendations(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Content_recommendations, dto: Content_recommendationsUpdate) -> Content_recommendations:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

content_recommendations_mapper = Content_recommendationsMapper()
