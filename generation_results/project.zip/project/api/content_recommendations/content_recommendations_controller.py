from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.content_recommendations.content_recommendations_entity import Content_recommendations
from domain.content_recommendations.content_recommendations_service_interface import IAsyncContent_recommendationsService
from api.dtos.content_recommendations_dto import Content_recommendationsCreate, Content_recommendationsUpdate, Content_recommendationsResponse
from api.mappers.content_recommendations_mapper import content_recommendations_mapper
from api.validations.content_recommendations_validation_schemas import validate_content_recommendations_create, validate_content_recommendations_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('content_recommendations', description='Content_recommendations operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
content_recommendations_create_model = api.model('Content_recommendationsCreate', {
    'name': fields.String(required=True, description='content_recommendations name'),
    'description': fields.String(description='content_recommendations description'),
    'status': fields.String(description='content_recommendations status', enum=['active', 'inactive', 'pending'])
})

content_recommendations_update_model = api.model('Content_recommendationsUpdate', {
    'name': fields.String(description='content_recommendations name'),
    'description': fields.String(description='content_recommendations description'),
    'status': fields.String(description='content_recommendations status', enum=['active', 'inactive', 'pending'])
})

content_recommendations_response_model = api.model('Content_recommendationsResponse', {
    'id': fields.String(description='content_recommendations ID'),
    'name': fields.String(description='content_recommendations name'),
    'description': fields.String(description='content_recommendations description'),
    'status': fields.String(description='content_recommendations status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncContent_recommendationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Content_recommendationsList(Resource):
        @api.doc('list_content_recommendationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(content_recommendations_response_model)
        @token_required
        async def get(self):
            """List all content_recommendationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [content_recommendations_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting content_recommendationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_content_recommendations')
        @api.expect(content_recommendations_create_model)
        @api.marshal_with(content_recommendations_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new content_recommendations"""
            try:
                data = api.payload
                validated_data = validate_content_recommendations_create(data)
                entity = content_recommendations_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return content_recommendations_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating content_recommendations: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The content_recommendations identifier')
    @api.response(404, 'Content_recommendations not found')
    class Content_recommendationsResource(Resource):
        @api.doc('get_content_recommendations')
        @api.marshal_with(content_recommendations_response_model)
        @token_required
        async def get(self, id):
            """Get a content_recommendations given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Content_recommendations not found")
                return content_recommendations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting content_recommendations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_content_recommendations')
        @api.expect(content_recommendations_update_model)
        @api.marshal_with(content_recommendations_response_model)
        @token_required
        async def put(self, id):
            """Update a content_recommendations given its identifier"""
            try:
                data = api.payload
                validated_data = validate_content_recommendations_update(data)
                entity = content_recommendations_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Content_recommendations not found")
                return content_recommendations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating content_recommendations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_content_recommendations')
        @api.response(204, 'Content_recommendations deleted')
        @token_required
        async def delete(self, id):
            """Delete a content_recommendations given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Content_recommendations not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting content_recommendations {id}: {str(e)}")
                api.abort(400, str(e))

    return api
