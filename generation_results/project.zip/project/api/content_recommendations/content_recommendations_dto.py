from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Content_recommendationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Content_recommendationsBase(BaseModel):
    """Base schema for content_recommendations"""
    pass

class Content_recommendationsCreate(Content_recommendationsBase):
    """Schema for creating content_recommendations"""
    name: str
    description: Optional[str] = None
    status: Content_recommendationsStatus = Content_recommendationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Content_recommendationsUpdate(Content_recommendationsBase):
    """Schema for updating content_recommendations"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Content_recommendationsStatus] = None

class Content_recommendationsResponse(Content_recommendationsBase):
    """Response schema for content_recommendations"""
    id: str
    name: str
    description: Optional[str] = None
    status: Content_recommendationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_content_recommendations_create(data: Content_recommendationsCreate) -> Content_recommendationsCreate:
    """Validate content_recommendations creation data"""
    return data

def validate_content_recommendations_update(data: Content_recommendationsUpdate) -> Content_recommendationsUpdate:
    """Validate content_recommendations update data"""
    return data
