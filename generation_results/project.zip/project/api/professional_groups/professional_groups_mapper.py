from domain.professional_groups.professional_groups_entity import Professional_groups
from api.dtos.professional_groups_dto import Professional_groupsCreate, Professional_groupsUpdate, Professional_groupsResponse
from typing import Union

class Professional_groupsMapper:
    """Mapper for Professional_groups between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Professional_groups) -> Professional_groupsResponse:
        """Convert entity to response DTO"""
        return Professional_groupsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Professional_groupsCreate, Professional_groupsUpdate]) -> Professional_groups:
        """Convert DTO to entity"""
        return Professional_groups(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Professional_groups, dto: Professional_groupsUpdate) -> Professional_groups:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

professional_groups_mapper = Professional_groupsMapper()
