from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Professional_groupsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Professional_groupsBase(BaseModel):
    """Base schema for professional_groups"""
    pass

class Professional_groupsCreate(Professional_groupsBase):
    """Schema for creating professional_groups"""
    name: str
    description: Optional[str] = None
    status: Professional_groupsStatus = Professional_groupsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Professional_groupsUpdate(Professional_groupsBase):
    """Schema for updating professional_groups"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Professional_groupsStatus] = None

class Professional_groupsResponse(Professional_groupsBase):
    """Response schema for professional_groups"""
    id: str
    name: str
    description: Optional[str] = None
    status: Professional_groupsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_professional_groups_create(data: Professional_groupsCreate) -> Professional_groupsCreate:
    """Validate professional_groups creation data"""
    return data

def validate_professional_groups_update(data: Professional_groupsUpdate) -> Professional_groupsUpdate:
    """Validate professional_groups update data"""
    return data
