from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.professional_groups.professional_groups_entity import Professional_groups
from domain.professional_groups.professional_groups_service_interface import IAsyncProfessional_groupsService
from api.dtos.professional_groups_dto import Professional_groupsCreate, Professional_groupsUpdate, Professional_groupsResponse
from api.mappers.professional_groups_mapper import professional_groups_mapper
from api.validations.professional_groups_validation_schemas import validate_professional_groups_create, validate_professional_groups_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('professional_groups', description='Professional_groups operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
professional_groups_create_model = api.model('Professional_groupsCreate', {
    'name': fields.String(required=True, description='professional_groups name'),
    'description': fields.String(description='professional_groups description'),
    'status': fields.String(description='professional_groups status', enum=['active', 'inactive', 'pending'])
})

professional_groups_update_model = api.model('Professional_groupsUpdate', {
    'name': fields.String(description='professional_groups name'),
    'description': fields.String(description='professional_groups description'),
    'status': fields.String(description='professional_groups status', enum=['active', 'inactive', 'pending'])
})

professional_groups_response_model = api.model('Professional_groupsResponse', {
    'id': fields.String(description='professional_groups ID'),
    'name': fields.String(description='professional_groups name'),
    'description': fields.String(description='professional_groups description'),
    'status': fields.String(description='professional_groups status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProfessional_groupsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Professional_groupsList(Resource):
        @api.doc('list_professional_groupss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(professional_groups_response_model)
        @token_required
        async def get(self):
            """List all professional_groupss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [professional_groups_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting professional_groupss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_professional_groups')
        @api.expect(professional_groups_create_model)
        @api.marshal_with(professional_groups_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new professional_groups"""
            try:
                data = api.payload
                validated_data = validate_professional_groups_create(data)
                entity = professional_groups_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return professional_groups_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating professional_groups: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The professional_groups identifier')
    @api.response(404, 'Professional_groups not found')
    class Professional_groupsResource(Resource):
        @api.doc('get_professional_groups')
        @api.marshal_with(professional_groups_response_model)
        @token_required
        async def get(self, id):
            """Get a professional_groups given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Professional_groups not found")
                return professional_groups_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting professional_groups {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_professional_groups')
        @api.expect(professional_groups_update_model)
        @api.marshal_with(professional_groups_response_model)
        @token_required
        async def put(self, id):
            """Update a professional_groups given its identifier"""
            try:
                data = api.payload
                validated_data = validate_professional_groups_update(data)
                entity = professional_groups_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Professional_groups not found")
                return professional_groups_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating professional_groups {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_professional_groups')
        @api.response(204, 'Professional_groups deleted')
        @token_required
        async def delete(self, id):
            """Delete a professional_groups given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Professional_groups not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting professional_groups {id}: {str(e)}")
                api.abort(400, str(e))

    return api
