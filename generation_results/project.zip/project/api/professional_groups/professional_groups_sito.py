from typing import List, Optional
from domain.professional_groups.professional_groups_entity import Professional_groups
from domain.professional_groups.professional_groups_service_interface import IAsyncProfessional_groupsService
from infrastructure.repositories.professional_groups.professional_groups_repository import Professional_groupsRepository
from api.mappers.professional_groups_mapper import professional_groups_mapper
from shared.utils.logger import logger

class Professional_groupsService(IAsyncProfessional_groupsService):
    """Service implementation for Professional_groups"""

    def __init__(self):
        self.repository = Professional_groupsRepository()

    async def get_by_id(self, id: str) -> Optional[Professional_groups]:
        """Get professional_groups by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting professional_groups by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Professional_groups]:
        """Get all professional_groupss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all professional_groupss: {str(e)}")
            raise

    async def create(self, data: Professional_groups) -> Professional_groups:
        """Create new professional_groups"""
        try:
            return await self.repository.create(professional_groups_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating professional_groups: {str(e)}")
            raise

    async def update(self, id: str, data: Professional_groups) -> Optional[Professional_groups]:
        """Update professional_groups"""
        try:
            return await self.repository.update(id, professional_groups_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating professional_groups: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete professional_groups"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting professional_groups: {str(e)}")
            raise
