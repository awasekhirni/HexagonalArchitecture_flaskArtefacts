from domain.project_tags.project_tags_entity import Project_tags
from api.dtos.project_tags_dto import Project_tagsCreate, Project_tagsUpdate, Project_tagsResponse
from typing import Union

class Project_tagsMapper:
    """Mapper for Project_tags between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Project_tags) -> Project_tagsResponse:
        """Convert entity to response DTO"""
        return Project_tagsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Project_tagsCreate, Project_tagsUpdate]) -> Project_tags:
        """Convert DTO to entity"""
        return Project_tags(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Project_tags, dto: Project_tagsUpdate) -> Project_tags:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

project_tags_mapper = Project_tagsMapper()
