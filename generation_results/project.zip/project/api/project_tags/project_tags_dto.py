from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Project_tagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Project_tagsBase(BaseModel):
    """Base schema for project_tags"""
    pass

class Project_tagsCreate(Project_tagsBase):
    """Schema for creating project_tags"""
    name: str
    description: Optional[str] = None
    status: Project_tagsStatus = Project_tagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Project_tagsUpdate(Project_tagsBase):
    """Schema for updating project_tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Project_tagsStatus] = None

class Project_tagsResponse(Project_tagsBase):
    """Response schema for project_tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: Project_tagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_project_tags_create(data: Project_tagsCreate) -> Project_tagsCreate:
    """Validate project_tags creation data"""
    return data

def validate_project_tags_update(data: Project_tagsUpdate) -> Project_tagsUpdate:
    """Validate project_tags update data"""
    return data
