from typing import List, Optional
from domain.project_tags.project_tags_entity import Project_tags
from domain.project_tags.project_tags_service_interface import IAsyncProject_tagsService
from infrastructure.repositories.project_tags.project_tags_repository import Project_tagsRepository
from api.mappers.project_tags_mapper import project_tags_mapper
from shared.utils.logger import logger

class Project_tagsService(IAsyncProject_tagsService):
    """Service implementation for Project_tags"""

    def __init__(self):
        self.repository = Project_tagsRepository()

    async def get_by_id(self, id: str) -> Optional[Project_tags]:
        """Get project_tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting project_tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Project_tags]:
        """Get all project_tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all project_tagss: {str(e)}")
            raise

    async def create(self, data: Project_tags) -> Project_tags:
        """Create new project_tags"""
        try:
            return await self.repository.create(project_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating project_tags: {str(e)}")
            raise

    async def update(self, id: str, data: Project_tags) -> Optional[Project_tags]:
        """Update project_tags"""
        try:
            return await self.repository.update(id, project_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating project_tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete project_tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting project_tags: {str(e)}")
            raise
