from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.project_tags.project_tags_entity import Project_tags
from domain.project_tags.project_tags_service_interface import IAsyncProject_tagsService
from api.dtos.project_tags_dto import Project_tagsCreate, Project_tagsUpdate, Project_tagsResponse
from api.mappers.project_tags_mapper import project_tags_mapper
from api.validations.project_tags_validation_schemas import validate_project_tags_create, validate_project_tags_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('project_tags', description='Project_tags operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
project_tags_create_model = api.model('Project_tagsCreate', {
    'name': fields.String(required=True, description='project_tags name'),
    'description': fields.String(description='project_tags description'),
    'status': fields.String(description='project_tags status', enum=['active', 'inactive', 'pending'])
})

project_tags_update_model = api.model('Project_tagsUpdate', {
    'name': fields.String(description='project_tags name'),
    'description': fields.String(description='project_tags description'),
    'status': fields.String(description='project_tags status', enum=['active', 'inactive', 'pending'])
})

project_tags_response_model = api.model('Project_tagsResponse', {
    'id': fields.String(description='project_tags ID'),
    'name': fields.String(description='project_tags name'),
    'description': fields.String(description='project_tags description'),
    'status': fields.String(description='project_tags status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProject_tagsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Project_tagsList(Resource):
        @api.doc('list_project_tagss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(project_tags_response_model)
        @token_required
        async def get(self):
            """List all project_tagss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [project_tags_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting project_tagss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_project_tags')
        @api.expect(project_tags_create_model)
        @api.marshal_with(project_tags_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new project_tags"""
            try:
                data = api.payload
                validated_data = validate_project_tags_create(data)
                entity = project_tags_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return project_tags_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating project_tags: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The project_tags identifier')
    @api.response(404, 'Project_tags not found')
    class Project_tagsResource(Resource):
        @api.doc('get_project_tags')
        @api.marshal_with(project_tags_response_model)
        @token_required
        async def get(self, id):
            """Get a project_tags given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Project_tags not found")
                return project_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting project_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_project_tags')
        @api.expect(project_tags_update_model)
        @api.marshal_with(project_tags_response_model)
        @token_required
        async def put(self, id):
            """Update a project_tags given its identifier"""
            try:
                data = api.payload
                validated_data = validate_project_tags_update(data)
                entity = project_tags_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Project_tags not found")
                return project_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating project_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_project_tags')
        @api.response(204, 'Project_tags deleted')
        @token_required
        async def delete(self, id):
            """Delete a project_tags given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Project_tags not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting project_tags {id}: {str(e)}")
                api.abort(400, str(e))

    return api
