from typing import List, Optional
from domain.groups.groups_entity import Groups
from domain.groups.groups_service_interface import IAsyncGroupsService
from infrastructure.repositories.groups.groups_repository import GroupsRepository
from api.mappers.groups_mapper import groups_mapper
from shared.utils.logger import logger

class GroupsService(IAsyncGroupsService):
    """Service implementation for Groups"""

    def __init__(self):
        self.repository = GroupsRepository()

    async def get_by_id(self, id: str) -> Optional[Groups]:
        """Get groups by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting groups by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Groups]:
        """Get all groupss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all groupss: {str(e)}")
            raise

    async def create(self, data: Groups) -> Groups:
        """Create new groups"""
        try:
            return await self.repository.create(groups_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating groups: {str(e)}")
            raise

    async def update(self, id: str, data: Groups) -> Optional[Groups]:
        """Update groups"""
        try:
            return await self.repository.update(id, groups_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating groups: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete groups"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting groups: {str(e)}")
            raise
