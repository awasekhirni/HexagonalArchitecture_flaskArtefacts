from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class GroupsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class GroupsBase(BaseModel):
    """Base schema for groups"""
    pass

class GroupsCreate(GroupsBase):
    """Schema for creating groups"""
    name: str
    description: Optional[str] = None
    status: GroupsStatus = GroupsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class GroupsUpdate(GroupsBase):
    """Schema for updating groups"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[GroupsStatus] = None

class GroupsResponse(GroupsBase):
    """Response schema for groups"""
    id: str
    name: str
    description: Optional[str] = None
    status: GroupsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_groups_create(data: GroupsCreate) -> GroupsCreate:
    """Validate groups creation data"""
    return data

def validate_groups_update(data: GroupsUpdate) -> GroupsUpdate:
    """Validate groups update data"""
    return data
