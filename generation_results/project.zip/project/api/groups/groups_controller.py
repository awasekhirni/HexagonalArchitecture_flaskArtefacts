from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.groups.groups_entity import Groups
from domain.groups.groups_service_interface import IAsyncGroupsService
from api.dtos.groups_dto import GroupsCreate, GroupsUpdate, GroupsResponse
from api.mappers.groups_mapper import groups_mapper
from api.validations.groups_validation_schemas import validate_groups_create, validate_groups_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('groups', description='Groups operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
groups_create_model = api.model('GroupsCreate', {
    'name': fields.String(required=True, description='groups name'),
    'description': fields.String(description='groups description'),
    'status': fields.String(description='groups status', enum=['active', 'inactive', 'pending'])
})

groups_update_model = api.model('GroupsUpdate', {
    'name': fields.String(description='groups name'),
    'description': fields.String(description='groups description'),
    'status': fields.String(description='groups status', enum=['active', 'inactive', 'pending'])
})

groups_response_model = api.model('GroupsResponse', {
    'id': fields.String(description='groups ID'),
    'name': fields.String(description='groups name'),
    'description': fields.String(description='groups description'),
    'status': fields.String(description='groups status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncGroupsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class GroupsList(Resource):
        @api.doc('list_groupss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(groups_response_model)
        @token_required
        async def get(self):
            """List all groupss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [groups_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting groupss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_groups')
        @api.expect(groups_create_model)
        @api.marshal_with(groups_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new groups"""
            try:
                data = api.payload
                validated_data = validate_groups_create(data)
                entity = groups_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return groups_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating groups: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The groups identifier')
    @api.response(404, 'Groups not found')
    class GroupsResource(Resource):
        @api.doc('get_groups')
        @api.marshal_with(groups_response_model)
        @token_required
        async def get(self, id):
            """Get a groups given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Groups not found")
                return groups_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting groups {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_groups')
        @api.expect(groups_update_model)
        @api.marshal_with(groups_response_model)
        @token_required
        async def put(self, id):
            """Update a groups given its identifier"""
            try:
                data = api.payload
                validated_data = validate_groups_update(data)
                entity = groups_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Groups not found")
                return groups_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating groups {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_groups')
        @api.response(204, 'Groups deleted')
        @token_required
        async def delete(self, id):
            """Delete a groups given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Groups not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting groups {id}: {str(e)}")
                api.abort(400, str(e))

    return api
