from domain.groups.groups_entity import Groups
from api.dtos.groups_dto import GroupsCreate, GroupsUpdate, GroupsResponse
from typing import Union

class GroupsMapper:
    """Mapper for Groups between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Groups) -> GroupsResponse:
        """Convert entity to response DTO"""
        return GroupsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[GroupsCreate, GroupsUpdate]) -> Groups:
        """Convert DTO to entity"""
        return Groups(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Groups, dto: GroupsUpdate) -> Groups:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

groups_mapper = GroupsMapper()
