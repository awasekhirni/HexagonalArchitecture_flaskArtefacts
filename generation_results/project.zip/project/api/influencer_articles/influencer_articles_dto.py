from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Influencer_articlesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Influencer_articlesBase(BaseModel):
    """Base schema for influencer_articles"""
    pass

class Influencer_articlesCreate(Influencer_articlesBase):
    """Schema for creating influencer_articles"""
    name: str
    description: Optional[str] = None
    status: Influencer_articlesStatus = Influencer_articlesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Influencer_articlesUpdate(Influencer_articlesBase):
    """Schema for updating influencer_articles"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Influencer_articlesStatus] = None

class Influencer_articlesResponse(Influencer_articlesBase):
    """Response schema for influencer_articles"""
    id: str
    name: str
    description: Optional[str] = None
    status: Influencer_articlesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_influencer_articles_create(data: Influencer_articlesCreate) -> Influencer_articlesCreate:
    """Validate influencer_articles creation data"""
    return data

def validate_influencer_articles_update(data: Influencer_articlesUpdate) -> Influencer_articlesUpdate:
    """Validate influencer_articles update data"""
    return data
