from typing import List, Optional
from domain.influencer_articles.influencer_articles_entity import Influencer_articles
from domain.influencer_articles.influencer_articles_service_interface import IAsyncInfluencer_articlesService
from infrastructure.repositories.influencer_articles.influencer_articles_repository import Influencer_articlesRepository
from api.mappers.influencer_articles_mapper import influencer_articles_mapper
from shared.utils.logger import logger

class Influencer_articlesService(IAsyncInfluencer_articlesService):
    """Service implementation for Influencer_articles"""

    def __init__(self):
        self.repository = Influencer_articlesRepository()

    async def get_by_id(self, id: str) -> Optional[Influencer_articles]:
        """Get influencer_articles by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting influencer_articles by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Influencer_articles]:
        """Get all influencer_articless"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all influencer_articless: {str(e)}")
            raise

    async def create(self, data: Influencer_articles) -> Influencer_articles:
        """Create new influencer_articles"""
        try:
            return await self.repository.create(influencer_articles_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating influencer_articles: {str(e)}")
            raise

    async def update(self, id: str, data: Influencer_articles) -> Optional[Influencer_articles]:
        """Update influencer_articles"""
        try:
            return await self.repository.update(id, influencer_articles_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating influencer_articles: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete influencer_articles"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting influencer_articles: {str(e)}")
            raise
