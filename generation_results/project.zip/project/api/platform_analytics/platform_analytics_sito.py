from typing import List, Optional
from domain.platform_analytics.platform_analytics_entity import Platform_analytics
from domain.platform_analytics.platform_analytics_service_interface import IAsyncPlatform_analyticsService
from infrastructure.repositories.platform_analytics.platform_analytics_repository import Platform_analyticsRepository
from api.mappers.platform_analytics_mapper import platform_analytics_mapper
from shared.utils.logger import logger

class Platform_analyticsService(IAsyncPlatform_analyticsService):
    """Service implementation for Platform_analytics"""

    def __init__(self):
        self.repository = Platform_analyticsRepository()

    async def get_by_id(self, id: str) -> Optional[Platform_analytics]:
        """Get platform_analytics by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting platform_analytics by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Platform_analytics]:
        """Get all platform_analyticss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all platform_analyticss: {str(e)}")
            raise

    async def create(self, data: Platform_analytics) -> Platform_analytics:
        """Create new platform_analytics"""
        try:
            return await self.repository.create(platform_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating platform_analytics: {str(e)}")
            raise

    async def update(self, id: str, data: Platform_analytics) -> Optional[Platform_analytics]:
        """Update platform_analytics"""
        try:
            return await self.repository.update(id, platform_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating platform_analytics: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete platform_analytics"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting platform_analytics: {str(e)}")
            raise
