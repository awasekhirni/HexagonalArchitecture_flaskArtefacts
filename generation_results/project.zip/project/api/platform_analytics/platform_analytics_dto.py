from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Platform_analyticsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Platform_analyticsBase(BaseModel):
    """Base schema for platform_analytics"""
    pass

class Platform_analyticsCreate(Platform_analyticsBase):
    """Schema for creating platform_analytics"""
    name: str
    description: Optional[str] = None
    status: Platform_analyticsStatus = Platform_analyticsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Platform_analyticsUpdate(Platform_analyticsBase):
    """Schema for updating platform_analytics"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Platform_analyticsStatus] = None

class Platform_analyticsResponse(Platform_analyticsBase):
    """Response schema for platform_analytics"""
    id: str
    name: str
    description: Optional[str] = None
    status: Platform_analyticsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_platform_analytics_create(data: Platform_analyticsCreate) -> Platform_analyticsCreate:
    """Validate platform_analytics creation data"""
    return data

def validate_platform_analytics_update(data: Platform_analyticsUpdate) -> Platform_analyticsUpdate:
    """Validate platform_analytics update data"""
    return data
