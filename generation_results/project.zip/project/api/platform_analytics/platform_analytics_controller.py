from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.platform_analytics.platform_analytics_entity import Platform_analytics
from domain.platform_analytics.platform_analytics_service_interface import IAsyncPlatform_analyticsService
from api.dtos.platform_analytics_dto import Platform_analyticsCreate, Platform_analyticsUpdate, Platform_analyticsResponse
from api.mappers.platform_analytics_mapper import platform_analytics_mapper
from api.validations.platform_analytics_validation_schemas import validate_platform_analytics_create, validate_platform_analytics_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('platform_analytics', description='Platform_analytics operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
platform_analytics_create_model = api.model('Platform_analyticsCreate', {
    'name': fields.String(required=True, description='platform_analytics name'),
    'description': fields.String(description='platform_analytics description'),
    'status': fields.String(description='platform_analytics status', enum=['active', 'inactive', 'pending'])
})

platform_analytics_update_model = api.model('Platform_analyticsUpdate', {
    'name': fields.String(description='platform_analytics name'),
    'description': fields.String(description='platform_analytics description'),
    'status': fields.String(description='platform_analytics status', enum=['active', 'inactive', 'pending'])
})

platform_analytics_response_model = api.model('Platform_analyticsResponse', {
    'id': fields.String(description='platform_analytics ID'),
    'name': fields.String(description='platform_analytics name'),
    'description': fields.String(description='platform_analytics description'),
    'status': fields.String(description='platform_analytics status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPlatform_analyticsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Platform_analyticsList(Resource):
        @api.doc('list_platform_analyticss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(platform_analytics_response_model)
        @token_required
        async def get(self):
            """List all platform_analyticss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [platform_analytics_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting platform_analyticss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_platform_analytics')
        @api.expect(platform_analytics_create_model)
        @api.marshal_with(platform_analytics_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new platform_analytics"""
            try:
                data = api.payload
                validated_data = validate_platform_analytics_create(data)
                entity = platform_analytics_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return platform_analytics_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating platform_analytics: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The platform_analytics identifier')
    @api.response(404, 'Platform_analytics not found')
    class Platform_analyticsResource(Resource):
        @api.doc('get_platform_analytics')
        @api.marshal_with(platform_analytics_response_model)
        @token_required
        async def get(self, id):
            """Get a platform_analytics given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Platform_analytics not found")
                return platform_analytics_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting platform_analytics {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_platform_analytics')
        @api.expect(platform_analytics_update_model)
        @api.marshal_with(platform_analytics_response_model)
        @token_required
        async def put(self, id):
            """Update a platform_analytics given its identifier"""
            try:
                data = api.payload
                validated_data = validate_platform_analytics_update(data)
                entity = platform_analytics_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Platform_analytics not found")
                return platform_analytics_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating platform_analytics {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_platform_analytics')
        @api.response(204, 'Platform_analytics deleted')
        @token_required
        async def delete(self, id):
            """Delete a platform_analytics given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Platform_analytics not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting platform_analytics {id}: {str(e)}")
                api.abort(400, str(e))

    return api
