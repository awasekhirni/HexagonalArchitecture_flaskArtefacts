from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_encryption_keysStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_encryption_keysBase(BaseModel):
    """Base schema for user_encryption_keys"""
    pass

class User_encryption_keysCreate(User_encryption_keysBase):
    """Schema for creating user_encryption_keys"""
    name: str
    description: Optional[str] = None
    status: User_encryption_keysStatus = User_encryption_keysStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_encryption_keysUpdate(User_encryption_keysBase):
    """Schema for updating user_encryption_keys"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_encryption_keysStatus] = None

class User_encryption_keysResponse(User_encryption_keysBase):
    """Response schema for user_encryption_keys"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_encryption_keysStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_encryption_keys_create(data: User_encryption_keysCreate) -> User_encryption_keysCreate:
    """Validate user_encryption_keys creation data"""
    return data

def validate_user_encryption_keys_update(data: User_encryption_keysUpdate) -> User_encryption_keysUpdate:
    """Validate user_encryption_keys update data"""
    return data
