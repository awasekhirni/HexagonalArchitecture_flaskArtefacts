from typing import List, Optional
from domain.user_encryption_keys.user_encryption_keys_entity import User_encryption_keys
from domain.user_encryption_keys.user_encryption_keys_service_interface import IAsyncUser_encryption_keysService
from infrastructure.repositories.user_encryption_keys.user_encryption_keys_repository import User_encryption_keysRepository
from api.mappers.user_encryption_keys_mapper import user_encryption_keys_mapper
from shared.utils.logger import logger

class User_encryption_keysService(IAsyncUser_encryption_keysService):
    """Service implementation for User_encryption_keys"""

    def __init__(self):
        self.repository = User_encryption_keysRepository()

    async def get_by_id(self, id: str) -> Optional[User_encryption_keys]:
        """Get user_encryption_keys by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_encryption_keys by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_encryption_keys]:
        """Get all user_encryption_keyss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_encryption_keyss: {str(e)}")
            raise

    async def create(self, data: User_encryption_keys) -> User_encryption_keys:
        """Create new user_encryption_keys"""
        try:
            return await self.repository.create(user_encryption_keys_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_encryption_keys: {str(e)}")
            raise

    async def update(self, id: str, data: User_encryption_keys) -> Optional[User_encryption_keys]:
        """Update user_encryption_keys"""
        try:
            return await self.repository.update(id, user_encryption_keys_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_encryption_keys: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_encryption_keys"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_encryption_keys: {str(e)}")
            raise
