from typing import List, Optional
from domain.mentors.mentors_entity import Mentors
from domain.mentors.mentors_service_interface import IAsyncMentorsService
from infrastructure.repositories.mentors.mentors_repository import MentorsRepository
from api.mappers.mentors_mapper import mentors_mapper
from shared.utils.logger import logger

class MentorsService(IAsyncMentorsService):
    """Service implementation for Mentors"""

    def __init__(self):
        self.repository = MentorsRepository()

    async def get_by_id(self, id: str) -> Optional[Mentors]:
        """Get mentors by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting mentors by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Mentors]:
        """Get all mentorss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all mentorss: {str(e)}")
            raise

    async def create(self, data: Mentors) -> Mentors:
        """Create new mentors"""
        try:
            return await self.repository.create(mentors_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating mentors: {str(e)}")
            raise

    async def update(self, id: str, data: Mentors) -> Optional[Mentors]:
        """Update mentors"""
        try:
            return await self.repository.update(id, mentors_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating mentors: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete mentors"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting mentors: {str(e)}")
            raise
