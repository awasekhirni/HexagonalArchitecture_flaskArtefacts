from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class MentorsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class MentorsBase(BaseModel):
    """Base schema for mentors"""
    pass

class MentorsCreate(MentorsBase):
    """Schema for creating mentors"""
    name: str
    description: Optional[str] = None
    status: MentorsStatus = MentorsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class MentorsUpdate(MentorsBase):
    """Schema for updating mentors"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[MentorsStatus] = None

class MentorsResponse(MentorsBase):
    """Response schema for mentors"""
    id: str
    name: str
    description: Optional[str] = None
    status: MentorsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_mentors_create(data: MentorsCreate) -> MentorsCreate:
    """Validate mentors creation data"""
    return data

def validate_mentors_update(data: MentorsUpdate) -> MentorsUpdate:
    """Validate mentors update data"""
    return data
