from typing import List, Optional
from domain.attendance.attendance_entity import Attendance
from domain.attendance.attendance_service_interface import IAsyncAttendanceService
from infrastructure.repositories.attendance.attendance_repository import AttendanceRepository
from api.mappers.attendance_mapper import attendance_mapper
from shared.utils.logger import logger

class AttendanceService(IAsyncAttendanceService):
    """Service implementation for Attendance"""

    def __init__(self):
        self.repository = AttendanceRepository()

    async def get_by_id(self, id: str) -> Optional[Attendance]:
        """Get attendance by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting attendance by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Attendance]:
        """Get all attendances"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all attendances: {str(e)}")
            raise

    async def create(self, data: Attendance) -> Attendance:
        """Create new attendance"""
        try:
            return await self.repository.create(attendance_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating attendance: {str(e)}")
            raise

    async def update(self, id: str, data: Attendance) -> Optional[Attendance]:
        """Update attendance"""
        try:
            return await self.repository.update(id, attendance_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating attendance: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete attendance"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting attendance: {str(e)}")
            raise
