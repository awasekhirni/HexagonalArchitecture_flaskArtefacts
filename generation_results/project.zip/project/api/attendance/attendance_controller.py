from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.attendance.attendance_entity import Attendance
from domain.attendance.attendance_service_interface import IAsyncAttendanceService
from api.dtos.attendance_dto import AttendanceCreate, AttendanceUpdate, AttendanceResponse
from api.mappers.attendance_mapper import attendance_mapper
from api.validations.attendance_validation_schemas import validate_attendance_create, validate_attendance_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('attendance', description='Attendance operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
attendance_create_model = api.model('AttendanceCreate', {
    'name': fields.String(required=True, description='attendance name'),
    'description': fields.String(description='attendance description'),
    'status': fields.String(description='attendance status', enum=['active', 'inactive', 'pending'])
})

attendance_update_model = api.model('AttendanceUpdate', {
    'name': fields.String(description='attendance name'),
    'description': fields.String(description='attendance description'),
    'status': fields.String(description='attendance status', enum=['active', 'inactive', 'pending'])
})

attendance_response_model = api.model('AttendanceResponse', {
    'id': fields.String(description='attendance ID'),
    'name': fields.String(description='attendance name'),
    'description': fields.String(description='attendance description'),
    'status': fields.String(description='attendance status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncAttendanceService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class AttendanceList(Resource):
        @api.doc('list_attendances')
        @api.expect(pagination_parser)
        @api.marshal_list_with(attendance_response_model)
        @token_required
        async def get(self):
            """List all attendances"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [attendance_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting attendances: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_attendance')
        @api.expect(attendance_create_model)
        @api.marshal_with(attendance_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new attendance"""
            try:
                data = api.payload
                validated_data = validate_attendance_create(data)
                entity = attendance_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return attendance_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating attendance: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The attendance identifier')
    @api.response(404, 'Attendance not found')
    class AttendanceResource(Resource):
        @api.doc('get_attendance')
        @api.marshal_with(attendance_response_model)
        @token_required
        async def get(self, id):
            """Get a attendance given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Attendance not found")
                return attendance_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting attendance {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_attendance')
        @api.expect(attendance_update_model)
        @api.marshal_with(attendance_response_model)
        @token_required
        async def put(self, id):
            """Update a attendance given its identifier"""
            try:
                data = api.payload
                validated_data = validate_attendance_update(data)
                entity = attendance_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Attendance not found")
                return attendance_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating attendance {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_attendance')
        @api.response(204, 'Attendance deleted')
        @token_required
        async def delete(self, id):
            """Delete a attendance given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Attendance not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting attendance {id}: {str(e)}")
                api.abort(400, str(e))

    return api
