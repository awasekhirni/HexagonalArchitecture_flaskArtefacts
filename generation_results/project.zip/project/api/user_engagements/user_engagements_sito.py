from typing import List, Optional
from domain.user_engagements.user_engagements_entity import User_engagements
from domain.user_engagements.user_engagements_service_interface import IAsyncUser_engagementsService
from infrastructure.repositories.user_engagements.user_engagements_repository import User_engagementsRepository
from api.mappers.user_engagements_mapper import user_engagements_mapper
from shared.utils.logger import logger

class User_engagementsService(IAsyncUser_engagementsService):
    """Service implementation for User_engagements"""

    def __init__(self):
        self.repository = User_engagementsRepository()

    async def get_by_id(self, id: str) -> Optional[User_engagements]:
        """Get user_engagements by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_engagements by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_engagements]:
        """Get all user_engagementss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_engagementss: {str(e)}")
            raise

    async def create(self, data: User_engagements) -> User_engagements:
        """Create new user_engagements"""
        try:
            return await self.repository.create(user_engagements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_engagements: {str(e)}")
            raise

    async def update(self, id: str, data: User_engagements) -> Optional[User_engagements]:
        """Update user_engagements"""
        try:
            return await self.repository.update(id, user_engagements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_engagements: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_engagements"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_engagements: {str(e)}")
            raise
