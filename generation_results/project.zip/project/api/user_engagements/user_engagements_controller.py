from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_engagements.user_engagements_entity import User_engagements
from domain.user_engagements.user_engagements_service_interface import IAsyncUser_engagementsService
from api.dtos.user_engagements_dto import User_engagementsCreate, User_engagementsUpdate, User_engagementsResponse
from api.mappers.user_engagements_mapper import user_engagements_mapper
from api.validations.user_engagements_validation_schemas import validate_user_engagements_create, validate_user_engagements_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_engagements', description='User_engagements operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_engagements_create_model = api.model('User_engagementsCreate', {
    'name': fields.String(required=True, description='user_engagements name'),
    'description': fields.String(description='user_engagements description'),
    'status': fields.String(description='user_engagements status', enum=['active', 'inactive', 'pending'])
})

user_engagements_update_model = api.model('User_engagementsUpdate', {
    'name': fields.String(description='user_engagements name'),
    'description': fields.String(description='user_engagements description'),
    'status': fields.String(description='user_engagements status', enum=['active', 'inactive', 'pending'])
})

user_engagements_response_model = api.model('User_engagementsResponse', {
    'id': fields.String(description='user_engagements ID'),
    'name': fields.String(description='user_engagements name'),
    'description': fields.String(description='user_engagements description'),
    'status': fields.String(description='user_engagements status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_engagementsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_engagementsList(Resource):
        @api.doc('list_user_engagementss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_engagements_response_model)
        @token_required
        async def get(self):
            """List all user_engagementss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_engagements_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_engagementss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_engagements')
        @api.expect(user_engagements_create_model)
        @api.marshal_with(user_engagements_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_engagements"""
            try:
                data = api.payload
                validated_data = validate_user_engagements_create(data)
                entity = user_engagements_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_engagements_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_engagements: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_engagements identifier')
    @api.response(404, 'User_engagements not found')
    class User_engagementsResource(Resource):
        @api.doc('get_user_engagements')
        @api.marshal_with(user_engagements_response_model)
        @token_required
        async def get(self, id):
            """Get a user_engagements given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_engagements not found")
                return user_engagements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_engagements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_engagements')
        @api.expect(user_engagements_update_model)
        @api.marshal_with(user_engagements_response_model)
        @token_required
        async def put(self, id):
            """Update a user_engagements given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_engagements_update(data)
                entity = user_engagements_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_engagements not found")
                return user_engagements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_engagements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_engagements')
        @api.response(204, 'User_engagements deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_engagements given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_engagements not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_engagements {id}: {str(e)}")
                api.abort(400, str(e))

    return api
