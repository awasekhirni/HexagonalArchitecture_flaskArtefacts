from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.mentorship_sessions.mentorship_sessions_entity import Mentorship_sessions
from domain.mentorship_sessions.mentorship_sessions_service_interface import IAsyncMentorship_sessionsService
from api.dtos.mentorship_sessions_dto import Mentorship_sessionsCreate, Mentorship_sessionsUpdate, Mentorship_sessionsResponse
from api.mappers.mentorship_sessions_mapper import mentorship_sessions_mapper
from api.validations.mentorship_sessions_validation_schemas import validate_mentorship_sessions_create, validate_mentorship_sessions_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('mentorship_sessions', description='Mentorship_sessions operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
mentorship_sessions_create_model = api.model('Mentorship_sessionsCreate', {
    'name': fields.String(required=True, description='mentorship_sessions name'),
    'description': fields.String(description='mentorship_sessions description'),
    'status': fields.String(description='mentorship_sessions status', enum=['active', 'inactive', 'pending'])
})

mentorship_sessions_update_model = api.model('Mentorship_sessionsUpdate', {
    'name': fields.String(description='mentorship_sessions name'),
    'description': fields.String(description='mentorship_sessions description'),
    'status': fields.String(description='mentorship_sessions status', enum=['active', 'inactive', 'pending'])
})

mentorship_sessions_response_model = api.model('Mentorship_sessionsResponse', {
    'id': fields.String(description='mentorship_sessions ID'),
    'name': fields.String(description='mentorship_sessions name'),
    'description': fields.String(description='mentorship_sessions description'),
    'status': fields.String(description='mentorship_sessions status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncMentorship_sessionsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Mentorship_sessionsList(Resource):
        @api.doc('list_mentorship_sessionss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(mentorship_sessions_response_model)
        @token_required
        async def get(self):
            """List all mentorship_sessionss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [mentorship_sessions_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting mentorship_sessionss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_mentorship_sessions')
        @api.expect(mentorship_sessions_create_model)
        @api.marshal_with(mentorship_sessions_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new mentorship_sessions"""
            try:
                data = api.payload
                validated_data = validate_mentorship_sessions_create(data)
                entity = mentorship_sessions_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return mentorship_sessions_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating mentorship_sessions: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The mentorship_sessions identifier')
    @api.response(404, 'Mentorship_sessions not found')
    class Mentorship_sessionsResource(Resource):
        @api.doc('get_mentorship_sessions')
        @api.marshal_with(mentorship_sessions_response_model)
        @token_required
        async def get(self, id):
            """Get a mentorship_sessions given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Mentorship_sessions not found")
                return mentorship_sessions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting mentorship_sessions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_mentorship_sessions')
        @api.expect(mentorship_sessions_update_model)
        @api.marshal_with(mentorship_sessions_response_model)
        @token_required
        async def put(self, id):
            """Update a mentorship_sessions given its identifier"""
            try:
                data = api.payload
                validated_data = validate_mentorship_sessions_update(data)
                entity = mentorship_sessions_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Mentorship_sessions not found")
                return mentorship_sessions_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating mentorship_sessions {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_mentorship_sessions')
        @api.response(204, 'Mentorship_sessions deleted')
        @token_required
        async def delete(self, id):
            """Delete a mentorship_sessions given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Mentorship_sessions not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting mentorship_sessions {id}: {str(e)}")
                api.abort(400, str(e))

    return api
