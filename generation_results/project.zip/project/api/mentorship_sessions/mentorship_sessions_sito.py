from typing import List, Optional
from domain.mentorship_sessions.mentorship_sessions_entity import Mentorship_sessions
from domain.mentorship_sessions.mentorship_sessions_service_interface import IAsyncMentorship_sessionsService
from infrastructure.repositories.mentorship_sessions.mentorship_sessions_repository import Mentorship_sessionsRepository
from api.mappers.mentorship_sessions_mapper import mentorship_sessions_mapper
from shared.utils.logger import logger

class Mentorship_sessionsService(IAsyncMentorship_sessionsService):
    """Service implementation for Mentorship_sessions"""

    def __init__(self):
        self.repository = Mentorship_sessionsRepository()

    async def get_by_id(self, id: str) -> Optional[Mentorship_sessions]:
        """Get mentorship_sessions by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting mentorship_sessions by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Mentorship_sessions]:
        """Get all mentorship_sessionss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all mentorship_sessionss: {str(e)}")
            raise

    async def create(self, data: Mentorship_sessions) -> Mentorship_sessions:
        """Create new mentorship_sessions"""
        try:
            return await self.repository.create(mentorship_sessions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating mentorship_sessions: {str(e)}")
            raise

    async def update(self, id: str, data: Mentorship_sessions) -> Optional[Mentorship_sessions]:
        """Update mentorship_sessions"""
        try:
            return await self.repository.update(id, mentorship_sessions_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating mentorship_sessions: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete mentorship_sessions"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting mentorship_sessions: {str(e)}")
            raise
