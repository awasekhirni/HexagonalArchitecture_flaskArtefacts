from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Mentorship_sessionsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Mentorship_sessionsBase(BaseModel):
    """Base schema for mentorship_sessions"""
    pass

class Mentorship_sessionsCreate(Mentorship_sessionsBase):
    """Schema for creating mentorship_sessions"""
    name: str
    description: Optional[str] = None
    status: Mentorship_sessionsStatus = Mentorship_sessionsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Mentorship_sessionsUpdate(Mentorship_sessionsBase):
    """Schema for updating mentorship_sessions"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Mentorship_sessionsStatus] = None

class Mentorship_sessionsResponse(Mentorship_sessionsBase):
    """Response schema for mentorship_sessions"""
    id: str
    name: str
    description: Optional[str] = None
    status: Mentorship_sessionsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_mentorship_sessions_create(data: Mentorship_sessionsCreate) -> Mentorship_sessionsCreate:
    """Validate mentorship_sessions creation data"""
    return data

def validate_mentorship_sessions_update(data: Mentorship_sessionsUpdate) -> Mentorship_sessionsUpdate:
    """Validate mentorship_sessions update data"""
    return data
