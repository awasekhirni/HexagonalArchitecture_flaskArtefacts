from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Post_interview_feedbackStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Post_interview_feedbackBase(BaseModel):
    """Base schema for post_interview_feedback"""
    pass

class Post_interview_feedbackCreate(Post_interview_feedbackBase):
    """Schema for creating post_interview_feedback"""
    name: str
    description: Optional[str] = None
    status: Post_interview_feedbackStatus = Post_interview_feedbackStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Post_interview_feedbackUpdate(Post_interview_feedbackBase):
    """Schema for updating post_interview_feedback"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Post_interview_feedbackStatus] = None

class Post_interview_feedbackResponse(Post_interview_feedbackBase):
    """Response schema for post_interview_feedback"""
    id: str
    name: str
    description: Optional[str] = None
    status: Post_interview_feedbackStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_post_interview_feedback_create(data: Post_interview_feedbackCreate) -> Post_interview_feedbackCreate:
    """Validate post_interview_feedback creation data"""
    return data

def validate_post_interview_feedback_update(data: Post_interview_feedbackUpdate) -> Post_interview_feedbackUpdate:
    """Validate post_interview_feedback update data"""
    return data
