from typing import List, Optional
from domain.post_interview_feedback.post_interview_feedback_entity import Post_interview_feedback
from domain.post_interview_feedback.post_interview_feedback_service_interface import IAsyncPost_interview_feedbackService
from infrastructure.repositories.post_interview_feedback.post_interview_feedback_repository import Post_interview_feedbackRepository
from api.mappers.post_interview_feedback_mapper import post_interview_feedback_mapper
from shared.utils.logger import logger

class Post_interview_feedbackService(IAsyncPost_interview_feedbackService):
    """Service implementation for Post_interview_feedback"""

    def __init__(self):
        self.repository = Post_interview_feedbackRepository()

    async def get_by_id(self, id: str) -> Optional[Post_interview_feedback]:
        """Get post_interview_feedback by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting post_interview_feedback by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Post_interview_feedback]:
        """Get all post_interview_feedbacks"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all post_interview_feedbacks: {str(e)}")
            raise

    async def create(self, data: Post_interview_feedback) -> Post_interview_feedback:
        """Create new post_interview_feedback"""
        try:
            return await self.repository.create(post_interview_feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating post_interview_feedback: {str(e)}")
            raise

    async def update(self, id: str, data: Post_interview_feedback) -> Optional[Post_interview_feedback]:
        """Update post_interview_feedback"""
        try:
            return await self.repository.update(id, post_interview_feedback_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating post_interview_feedback: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete post_interview_feedback"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting post_interview_feedback: {str(e)}")
            raise
