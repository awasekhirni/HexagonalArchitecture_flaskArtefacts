from domain.post_interview_feedback.post_interview_feedback_entity import Post_interview_feedback
from api.dtos.post_interview_feedback_dto import Post_interview_feedbackCreate, Post_interview_feedbackUpdate, Post_interview_feedbackResponse
from typing import Union

class Post_interview_feedbackMapper:
    """Mapper for Post_interview_feedback between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Post_interview_feedback) -> Post_interview_feedbackResponse:
        """Convert entity to response DTO"""
        return Post_interview_feedbackResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Post_interview_feedbackCreate, Post_interview_feedbackUpdate]) -> Post_interview_feedback:
        """Convert DTO to entity"""
        return Post_interview_feedback(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Post_interview_feedback, dto: Post_interview_feedbackUpdate) -> Post_interview_feedback:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

post_interview_feedback_mapper = Post_interview_feedbackMapper()
