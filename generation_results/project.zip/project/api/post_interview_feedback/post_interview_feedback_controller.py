from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.post_interview_feedback.post_interview_feedback_entity import Post_interview_feedback
from domain.post_interview_feedback.post_interview_feedback_service_interface import IAsyncPost_interview_feedbackService
from api.dtos.post_interview_feedback_dto import Post_interview_feedbackCreate, Post_interview_feedbackUpdate, Post_interview_feedbackResponse
from api.mappers.post_interview_feedback_mapper import post_interview_feedback_mapper
from api.validations.post_interview_feedback_validation_schemas import validate_post_interview_feedback_create, validate_post_interview_feedback_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('post_interview_feedback', description='Post_interview_feedback operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
post_interview_feedback_create_model = api.model('Post_interview_feedbackCreate', {
    'name': fields.String(required=True, description='post_interview_feedback name'),
    'description': fields.String(description='post_interview_feedback description'),
    'status': fields.String(description='post_interview_feedback status', enum=['active', 'inactive', 'pending'])
})

post_interview_feedback_update_model = api.model('Post_interview_feedbackUpdate', {
    'name': fields.String(description='post_interview_feedback name'),
    'description': fields.String(description='post_interview_feedback description'),
    'status': fields.String(description='post_interview_feedback status', enum=['active', 'inactive', 'pending'])
})

post_interview_feedback_response_model = api.model('Post_interview_feedbackResponse', {
    'id': fields.String(description='post_interview_feedback ID'),
    'name': fields.String(description='post_interview_feedback name'),
    'description': fields.String(description='post_interview_feedback description'),
    'status': fields.String(description='post_interview_feedback status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPost_interview_feedbackService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Post_interview_feedbackList(Resource):
        @api.doc('list_post_interview_feedbacks')
        @api.expect(pagination_parser)
        @api.marshal_list_with(post_interview_feedback_response_model)
        @token_required
        async def get(self):
            """List all post_interview_feedbacks"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [post_interview_feedback_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting post_interview_feedbacks: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_post_interview_feedback')
        @api.expect(post_interview_feedback_create_model)
        @api.marshal_with(post_interview_feedback_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new post_interview_feedback"""
            try:
                data = api.payload
                validated_data = validate_post_interview_feedback_create(data)
                entity = post_interview_feedback_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return post_interview_feedback_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating post_interview_feedback: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The post_interview_feedback identifier')
    @api.response(404, 'Post_interview_feedback not found')
    class Post_interview_feedbackResource(Resource):
        @api.doc('get_post_interview_feedback')
        @api.marshal_with(post_interview_feedback_response_model)
        @token_required
        async def get(self, id):
            """Get a post_interview_feedback given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Post_interview_feedback not found")
                return post_interview_feedback_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting post_interview_feedback {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_post_interview_feedback')
        @api.expect(post_interview_feedback_update_model)
        @api.marshal_with(post_interview_feedback_response_model)
        @token_required
        async def put(self, id):
            """Update a post_interview_feedback given its identifier"""
            try:
                data = api.payload
                validated_data = validate_post_interview_feedback_update(data)
                entity = post_interview_feedback_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Post_interview_feedback not found")
                return post_interview_feedback_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating post_interview_feedback {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_post_interview_feedback')
        @api.response(204, 'Post_interview_feedback deleted')
        @token_required
        async def delete(self, id):
            """Delete a post_interview_feedback given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Post_interview_feedback not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting post_interview_feedback {id}: {str(e)}")
                api.abort(400, str(e))

    return api
