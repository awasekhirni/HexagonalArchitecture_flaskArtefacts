from typing import List, Optional
from domain.block_appeals.block_appeals_entity import Block_appeals
from domain.block_appeals.block_appeals_service_interface import IAsyncBlock_appealsService
from infrastructure.repositories.block_appeals.block_appeals_repository import Block_appealsRepository
from api.mappers.block_appeals_mapper import block_appeals_mapper
from shared.utils.logger import logger

class Block_appealsService(IAsyncBlock_appealsService):
    """Service implementation for Block_appeals"""

    def __init__(self):
        self.repository = Block_appealsRepository()

    async def get_by_id(self, id: str) -> Optional[Block_appeals]:
        """Get block_appeals by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting block_appeals by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Block_appeals]:
        """Get all block_appealss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all block_appealss: {str(e)}")
            raise

    async def create(self, data: Block_appeals) -> Block_appeals:
        """Create new block_appeals"""
        try:
            return await self.repository.create(block_appeals_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating block_appeals: {str(e)}")
            raise

    async def update(self, id: str, data: Block_appeals) -> Optional[Block_appeals]:
        """Update block_appeals"""
        try:
            return await self.repository.update(id, block_appeals_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating block_appeals: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete block_appeals"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting block_appeals: {str(e)}")
            raise
