from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.block_appeals.block_appeals_entity import Block_appeals
from domain.block_appeals.block_appeals_service_interface import IAsyncBlock_appealsService
from api.dtos.block_appeals_dto import Block_appealsCreate, Block_appealsUpdate, Block_appealsResponse
from api.mappers.block_appeals_mapper import block_appeals_mapper
from api.validations.block_appeals_validation_schemas import validate_block_appeals_create, validate_block_appeals_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('block_appeals', description='Block_appeals operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
block_appeals_create_model = api.model('Block_appealsCreate', {
    'name': fields.String(required=True, description='block_appeals name'),
    'description': fields.String(description='block_appeals description'),
    'status': fields.String(description='block_appeals status', enum=['active', 'inactive', 'pending'])
})

block_appeals_update_model = api.model('Block_appealsUpdate', {
    'name': fields.String(description='block_appeals name'),
    'description': fields.String(description='block_appeals description'),
    'status': fields.String(description='block_appeals status', enum=['active', 'inactive', 'pending'])
})

block_appeals_response_model = api.model('Block_appealsResponse', {
    'id': fields.String(description='block_appeals ID'),
    'name': fields.String(description='block_appeals name'),
    'description': fields.String(description='block_appeals description'),
    'status': fields.String(description='block_appeals status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncBlock_appealsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Block_appealsList(Resource):
        @api.doc('list_block_appealss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(block_appeals_response_model)
        @token_required
        async def get(self):
            """List all block_appealss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [block_appeals_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting block_appealss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_block_appeals')
        @api.expect(block_appeals_create_model)
        @api.marshal_with(block_appeals_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new block_appeals"""
            try:
                data = api.payload
                validated_data = validate_block_appeals_create(data)
                entity = block_appeals_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return block_appeals_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating block_appeals: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The block_appeals identifier')
    @api.response(404, 'Block_appeals not found')
    class Block_appealsResource(Resource):
        @api.doc('get_block_appeals')
        @api.marshal_with(block_appeals_response_model)
        @token_required
        async def get(self, id):
            """Get a block_appeals given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Block_appeals not found")
                return block_appeals_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting block_appeals {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_block_appeals')
        @api.expect(block_appeals_update_model)
        @api.marshal_with(block_appeals_response_model)
        @token_required
        async def put(self, id):
            """Update a block_appeals given its identifier"""
            try:
                data = api.payload
                validated_data = validate_block_appeals_update(data)
                entity = block_appeals_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Block_appeals not found")
                return block_appeals_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating block_appeals {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_block_appeals')
        @api.response(204, 'Block_appeals deleted')
        @token_required
        async def delete(self, id):
            """Delete a block_appeals given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Block_appeals not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting block_appeals {id}: {str(e)}")
                api.abort(400, str(e))

    return api
