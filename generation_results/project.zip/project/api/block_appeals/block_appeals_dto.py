from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Block_appealsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Block_appealsBase(BaseModel):
    """Base schema for block_appeals"""
    pass

class Block_appealsCreate(Block_appealsBase):
    """Schema for creating block_appeals"""
    name: str
    description: Optional[str] = None
    status: Block_appealsStatus = Block_appealsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Block_appealsUpdate(Block_appealsBase):
    """Schema for updating block_appeals"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Block_appealsStatus] = None

class Block_appealsResponse(Block_appealsBase):
    """Response schema for block_appeals"""
    id: str
    name: str
    description: Optional[str] = None
    status: Block_appealsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_block_appeals_create(data: Block_appealsCreate) -> Block_appealsCreate:
    """Validate block_appeals creation data"""
    return data

def validate_block_appeals_update(data: Block_appealsUpdate) -> Block_appealsUpdate:
    """Validate block_appeals update data"""
    return data
