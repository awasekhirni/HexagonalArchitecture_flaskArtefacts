from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.political_affiliations.political_affiliations_entity import Political_affiliations
from domain.political_affiliations.political_affiliations_service_interface import IAsyncPolitical_affiliationsService
from api.dtos.political_affiliations_dto import Political_affiliationsCreate, Political_affiliationsUpdate, Political_affiliationsResponse
from api.mappers.political_affiliations_mapper import political_affiliations_mapper
from api.validations.political_affiliations_validation_schemas import validate_political_affiliations_create, validate_political_affiliations_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('political_affiliations', description='Political_affiliations operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
political_affiliations_create_model = api.model('Political_affiliationsCreate', {
    'name': fields.String(required=True, description='political_affiliations name'),
    'description': fields.String(description='political_affiliations description'),
    'status': fields.String(description='political_affiliations status', enum=['active', 'inactive', 'pending'])
})

political_affiliations_update_model = api.model('Political_affiliationsUpdate', {
    'name': fields.String(description='political_affiliations name'),
    'description': fields.String(description='political_affiliations description'),
    'status': fields.String(description='political_affiliations status', enum=['active', 'inactive', 'pending'])
})

political_affiliations_response_model = api.model('Political_affiliationsResponse', {
    'id': fields.String(description='political_affiliations ID'),
    'name': fields.String(description='political_affiliations name'),
    'description': fields.String(description='political_affiliations description'),
    'status': fields.String(description='political_affiliations status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncPolitical_affiliationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Political_affiliationsList(Resource):
        @api.doc('list_political_affiliationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(political_affiliations_response_model)
        @token_required
        async def get(self):
            """List all political_affiliationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [political_affiliations_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting political_affiliationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_political_affiliations')
        @api.expect(political_affiliations_create_model)
        @api.marshal_with(political_affiliations_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new political_affiliations"""
            try:
                data = api.payload
                validated_data = validate_political_affiliations_create(data)
                entity = political_affiliations_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return political_affiliations_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating political_affiliations: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The political_affiliations identifier')
    @api.response(404, 'Political_affiliations not found')
    class Political_affiliationsResource(Resource):
        @api.doc('get_political_affiliations')
        @api.marshal_with(political_affiliations_response_model)
        @token_required
        async def get(self, id):
            """Get a political_affiliations given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Political_affiliations not found")
                return political_affiliations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting political_affiliations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_political_affiliations')
        @api.expect(political_affiliations_update_model)
        @api.marshal_with(political_affiliations_response_model)
        @token_required
        async def put(self, id):
            """Update a political_affiliations given its identifier"""
            try:
                data = api.payload
                validated_data = validate_political_affiliations_update(data)
                entity = political_affiliations_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Political_affiliations not found")
                return political_affiliations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating political_affiliations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_political_affiliations')
        @api.response(204, 'Political_affiliations deleted')
        @token_required
        async def delete(self, id):
            """Delete a political_affiliations given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Political_affiliations not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting political_affiliations {id}: {str(e)}")
                api.abort(400, str(e))

    return api
