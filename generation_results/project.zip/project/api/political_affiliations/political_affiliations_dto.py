from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Political_affiliationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Political_affiliationsBase(BaseModel):
    """Base schema for political_affiliations"""
    pass

class Political_affiliationsCreate(Political_affiliationsBase):
    """Schema for creating political_affiliations"""
    name: str
    description: Optional[str] = None
    status: Political_affiliationsStatus = Political_affiliationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Political_affiliationsUpdate(Political_affiliationsBase):
    """Schema for updating political_affiliations"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Political_affiliationsStatus] = None

class Political_affiliationsResponse(Political_affiliationsBase):
    """Response schema for political_affiliations"""
    id: str
    name: str
    description: Optional[str] = None
    status: Political_affiliationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_political_affiliations_create(data: Political_affiliationsCreate) -> Political_affiliationsCreate:
    """Validate political_affiliations creation data"""
    return data

def validate_political_affiliations_update(data: Political_affiliationsUpdate) -> Political_affiliationsUpdate:
    """Validate political_affiliations update data"""
    return data
