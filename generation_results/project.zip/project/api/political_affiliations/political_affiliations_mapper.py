from domain.political_affiliations.political_affiliations_entity import Political_affiliations
from api.dtos.political_affiliations_dto import Political_affiliationsCreate, Political_affiliationsUpdate, Political_affiliationsResponse
from typing import Union

class Political_affiliationsMapper:
    """Mapper for Political_affiliations between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Political_affiliations) -> Political_affiliationsResponse:
        """Convert entity to response DTO"""
        return Political_affiliationsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Political_affiliationsCreate, Political_affiliationsUpdate]) -> Political_affiliations:
        """Convert DTO to entity"""
        return Political_affiliations(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Political_affiliations, dto: Political_affiliationsUpdate) -> Political_affiliations:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

political_affiliations_mapper = Political_affiliationsMapper()
