from typing import List, Optional
from domain.political_affiliations.political_affiliations_entity import Political_affiliations
from domain.political_affiliations.political_affiliations_service_interface import IAsyncPolitical_affiliationsService
from infrastructure.repositories.political_affiliations.political_affiliations_repository import Political_affiliationsRepository
from api.mappers.political_affiliations_mapper import political_affiliations_mapper
from shared.utils.logger import logger

class Political_affiliationsService(IAsyncPolitical_affiliationsService):
    """Service implementation for Political_affiliations"""

    def __init__(self):
        self.repository = Political_affiliationsRepository()

    async def get_by_id(self, id: str) -> Optional[Political_affiliations]:
        """Get political_affiliations by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting political_affiliations by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Political_affiliations]:
        """Get all political_affiliationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all political_affiliationss: {str(e)}")
            raise

    async def create(self, data: Political_affiliations) -> Political_affiliations:
        """Create new political_affiliations"""
        try:
            return await self.repository.create(political_affiliations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating political_affiliations: {str(e)}")
            raise

    async def update(self, id: str, data: Political_affiliations) -> Optional[Political_affiliations]:
        """Update political_affiliations"""
        try:
            return await self.repository.update(id, political_affiliations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating political_affiliations: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete political_affiliations"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting political_affiliations: {str(e)}")
            raise
