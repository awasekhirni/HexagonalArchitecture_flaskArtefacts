from typing import List, Optional
from domain.jwt_blacklist.jwt_blacklist_entity import Jwt_blacklist
from domain.jwt_blacklist.jwt_blacklist_service_interface import IAsyncJwt_blacklistService
from infrastructure.repositories.jwt_blacklist.jwt_blacklist_repository import Jwt_blacklistRepository
from api.mappers.jwt_blacklist_mapper import jwt_blacklist_mapper
from shared.utils.logger import logger

class Jwt_blacklistService(IAsyncJwt_blacklistService):
    """Service implementation for Jwt_blacklist"""

    def __init__(self):
        self.repository = Jwt_blacklistRepository()

    async def get_by_id(self, id: str) -> Optional[Jwt_blacklist]:
        """Get jwt_blacklist by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting jwt_blacklist by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Jwt_blacklist]:
        """Get all jwt_blacklists"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all jwt_blacklists: {str(e)}")
            raise

    async def create(self, data: Jwt_blacklist) -> Jwt_blacklist:
        """Create new jwt_blacklist"""
        try:
            return await self.repository.create(jwt_blacklist_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating jwt_blacklist: {str(e)}")
            raise

    async def update(self, id: str, data: Jwt_blacklist) -> Optional[Jwt_blacklist]:
        """Update jwt_blacklist"""
        try:
            return await self.repository.update(id, jwt_blacklist_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating jwt_blacklist: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete jwt_blacklist"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting jwt_blacklist: {str(e)}")
            raise
