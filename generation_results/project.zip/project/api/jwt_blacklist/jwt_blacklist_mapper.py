from domain.jwt_blacklist.jwt_blacklist_entity import Jwt_blacklist
from api.dtos.jwt_blacklist_dto import Jwt_blacklistCreate, Jwt_blacklistUpdate, Jwt_blacklistResponse
from typing import Union

class Jwt_blacklistMapper:
    """Mapper for Jwt_blacklist between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Jwt_blacklist) -> Jwt_blacklistResponse:
        """Convert entity to response DTO"""
        return Jwt_blacklistResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Jwt_blacklistCreate, Jwt_blacklistUpdate]) -> Jwt_blacklist:
        """Convert DTO to entity"""
        return Jwt_blacklist(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Jwt_blacklist, dto: Jwt_blacklistUpdate) -> Jwt_blacklist:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

jwt_blacklist_mapper = Jwt_blacklistMapper()
