from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Jwt_blacklistStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Jwt_blacklistBase(BaseModel):
    """Base schema for jwt_blacklist"""
    pass

class Jwt_blacklistCreate(Jwt_blacklistBase):
    """Schema for creating jwt_blacklist"""
    name: str
    description: Optional[str] = None
    status: Jwt_blacklistStatus = Jwt_blacklistStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Jwt_blacklistUpdate(Jwt_blacklistBase):
    """Schema for updating jwt_blacklist"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Jwt_blacklistStatus] = None

class Jwt_blacklistResponse(Jwt_blacklistBase):
    """Response schema for jwt_blacklist"""
    id: str
    name: str
    description: Optional[str] = None
    status: Jwt_blacklistStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_jwt_blacklist_create(data: Jwt_blacklistCreate) -> Jwt_blacklistCreate:
    """Validate jwt_blacklist creation data"""
    return data

def validate_jwt_blacklist_update(data: Jwt_blacklistUpdate) -> Jwt_blacklistUpdate:
    """Validate jwt_blacklist update data"""
    return data
