from domain.influencer_article_likes.influencer_article_likes_entity import Influencer_article_likes
from api.dtos.influencer_article_likes_dto import Influencer_article_likesCreate, Influencer_article_likesUpdate, Influencer_article_likesResponse
from typing import Union

class Influencer_article_likesMapper:
    """Mapper for Influencer_article_likes between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Influencer_article_likes) -> Influencer_article_likesResponse:
        """Convert entity to response DTO"""
        return Influencer_article_likesResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Influencer_article_likesCreate, Influencer_article_likesUpdate]) -> Influencer_article_likes:
        """Convert DTO to entity"""
        return Influencer_article_likes(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Influencer_article_likes, dto: Influencer_article_likesUpdate) -> Influencer_article_likes:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

influencer_article_likes_mapper = Influencer_article_likesMapper()
