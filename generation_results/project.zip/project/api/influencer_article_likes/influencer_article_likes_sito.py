from typing import List, Optional
from domain.influencer_article_likes.influencer_article_likes_entity import Influencer_article_likes
from domain.influencer_article_likes.influencer_article_likes_service_interface import IAsyncInfluencer_article_likesService
from infrastructure.repositories.influencer_article_likes.influencer_article_likes_repository import Influencer_article_likesRepository
from api.mappers.influencer_article_likes_mapper import influencer_article_likes_mapper
from shared.utils.logger import logger

class Influencer_article_likesService(IAsyncInfluencer_article_likesService):
    """Service implementation for Influencer_article_likes"""

    def __init__(self):
        self.repository = Influencer_article_likesRepository()

    async def get_by_id(self, id: str) -> Optional[Influencer_article_likes]:
        """Get influencer_article_likes by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting influencer_article_likes by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Influencer_article_likes]:
        """Get all influencer_article_likess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all influencer_article_likess: {str(e)}")
            raise

    async def create(self, data: Influencer_article_likes) -> Influencer_article_likes:
        """Create new influencer_article_likes"""
        try:
            return await self.repository.create(influencer_article_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating influencer_article_likes: {str(e)}")
            raise

    async def update(self, id: str, data: Influencer_article_likes) -> Optional[Influencer_article_likes]:
        """Update influencer_article_likes"""
        try:
            return await self.repository.update(id, influencer_article_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating influencer_article_likes: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete influencer_article_likes"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting influencer_article_likes: {str(e)}")
            raise
