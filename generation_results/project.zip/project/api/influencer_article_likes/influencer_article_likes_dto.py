from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Influencer_article_likesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Influencer_article_likesBase(BaseModel):
    """Base schema for influencer_article_likes"""
    pass

class Influencer_article_likesCreate(Influencer_article_likesBase):
    """Schema for creating influencer_article_likes"""
    name: str
    description: Optional[str] = None
    status: Influencer_article_likesStatus = Influencer_article_likesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Influencer_article_likesUpdate(Influencer_article_likesBase):
    """Schema for updating influencer_article_likes"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Influencer_article_likesStatus] = None

class Influencer_article_likesResponse(Influencer_article_likesBase):
    """Response schema for influencer_article_likes"""
    id: str
    name: str
    description: Optional[str] = None
    status: Influencer_article_likesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_influencer_article_likes_create(data: Influencer_article_likesCreate) -> Influencer_article_likesCreate:
    """Validate influencer_article_likes creation data"""
    return data

def validate_influencer_article_likes_update(data: Influencer_article_likesUpdate) -> Influencer_article_likesUpdate:
    """Validate influencer_article_likes update data"""
    return data
