from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.mentorship_matches.mentorship_matches_entity import Mentorship_matches
from domain.mentorship_matches.mentorship_matches_service_interface import IAsyncMentorship_matchesService
from api.dtos.mentorship_matches_dto import Mentorship_matchesCreate, Mentorship_matchesUpdate, Mentorship_matchesResponse
from api.mappers.mentorship_matches_mapper import mentorship_matches_mapper
from api.validations.mentorship_matches_validation_schemas import validate_mentorship_matches_create, validate_mentorship_matches_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('mentorship_matches', description='Mentorship_matches operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
mentorship_matches_create_model = api.model('Mentorship_matchesCreate', {
    'name': fields.String(required=True, description='mentorship_matches name'),
    'description': fields.String(description='mentorship_matches description'),
    'status': fields.String(description='mentorship_matches status', enum=['active', 'inactive', 'pending'])
})

mentorship_matches_update_model = api.model('Mentorship_matchesUpdate', {
    'name': fields.String(description='mentorship_matches name'),
    'description': fields.String(description='mentorship_matches description'),
    'status': fields.String(description='mentorship_matches status', enum=['active', 'inactive', 'pending'])
})

mentorship_matches_response_model = api.model('Mentorship_matchesResponse', {
    'id': fields.String(description='mentorship_matches ID'),
    'name': fields.String(description='mentorship_matches name'),
    'description': fields.String(description='mentorship_matches description'),
    'status': fields.String(description='mentorship_matches status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncMentorship_matchesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Mentorship_matchesList(Resource):
        @api.doc('list_mentorship_matchess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(mentorship_matches_response_model)
        @token_required
        async def get(self):
            """List all mentorship_matchess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [mentorship_matches_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting mentorship_matchess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_mentorship_matches')
        @api.expect(mentorship_matches_create_model)
        @api.marshal_with(mentorship_matches_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new mentorship_matches"""
            try:
                data = api.payload
                validated_data = validate_mentorship_matches_create(data)
                entity = mentorship_matches_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return mentorship_matches_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating mentorship_matches: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The mentorship_matches identifier')
    @api.response(404, 'Mentorship_matches not found')
    class Mentorship_matchesResource(Resource):
        @api.doc('get_mentorship_matches')
        @api.marshal_with(mentorship_matches_response_model)
        @token_required
        async def get(self, id):
            """Get a mentorship_matches given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Mentorship_matches not found")
                return mentorship_matches_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting mentorship_matches {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_mentorship_matches')
        @api.expect(mentorship_matches_update_model)
        @api.marshal_with(mentorship_matches_response_model)
        @token_required
        async def put(self, id):
            """Update a mentorship_matches given its identifier"""
            try:
                data = api.payload
                validated_data = validate_mentorship_matches_update(data)
                entity = mentorship_matches_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Mentorship_matches not found")
                return mentorship_matches_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating mentorship_matches {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_mentorship_matches')
        @api.response(204, 'Mentorship_matches deleted')
        @token_required
        async def delete(self, id):
            """Delete a mentorship_matches given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Mentorship_matches not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting mentorship_matches {id}: {str(e)}")
                api.abort(400, str(e))

    return api
