from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Mentorship_matchesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Mentorship_matchesBase(BaseModel):
    """Base schema for mentorship_matches"""
    pass

class Mentorship_matchesCreate(Mentorship_matchesBase):
    """Schema for creating mentorship_matches"""
    name: str
    description: Optional[str] = None
    status: Mentorship_matchesStatus = Mentorship_matchesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Mentorship_matchesUpdate(Mentorship_matchesBase):
    """Schema for updating mentorship_matches"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Mentorship_matchesStatus] = None

class Mentorship_matchesResponse(Mentorship_matchesBase):
    """Response schema for mentorship_matches"""
    id: str
    name: str
    description: Optional[str] = None
    status: Mentorship_matchesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_mentorship_matches_create(data: Mentorship_matchesCreate) -> Mentorship_matchesCreate:
    """Validate mentorship_matches creation data"""
    return data

def validate_mentorship_matches_update(data: Mentorship_matchesUpdate) -> Mentorship_matchesUpdate:
    """Validate mentorship_matches update data"""
    return data
