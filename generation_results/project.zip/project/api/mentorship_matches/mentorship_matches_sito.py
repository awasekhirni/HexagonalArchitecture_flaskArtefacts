from typing import List, Optional
from domain.mentorship_matches.mentorship_matches_entity import Mentorship_matches
from domain.mentorship_matches.mentorship_matches_service_interface import IAsyncMentorship_matchesService
from infrastructure.repositories.mentorship_matches.mentorship_matches_repository import Mentorship_matchesRepository
from api.mappers.mentorship_matches_mapper import mentorship_matches_mapper
from shared.utils.logger import logger

class Mentorship_matchesService(IAsyncMentorship_matchesService):
    """Service implementation for Mentorship_matches"""

    def __init__(self):
        self.repository = Mentorship_matchesRepository()

    async def get_by_id(self, id: str) -> Optional[Mentorship_matches]:
        """Get mentorship_matches by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting mentorship_matches by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Mentorship_matches]:
        """Get all mentorship_matchess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all mentorship_matchess: {str(e)}")
            raise

    async def create(self, data: Mentorship_matches) -> Mentorship_matches:
        """Create new mentorship_matches"""
        try:
            return await self.repository.create(mentorship_matches_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating mentorship_matches: {str(e)}")
            raise

    async def update(self, id: str, data: Mentorship_matches) -> Optional[Mentorship_matches]:
        """Update mentorship_matches"""
        try:
            return await self.repository.update(id, mentorship_matches_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating mentorship_matches: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete mentorship_matches"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting mentorship_matches: {str(e)}")
            raise
