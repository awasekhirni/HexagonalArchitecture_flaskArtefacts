from domain.podcast_comments.podcast_comments_entity import Podcast_comments
from api.dtos.podcast_comments_dto import Podcast_commentsCreate, Podcast_commentsUpdate, Podcast_commentsResponse
from typing import Union

class Podcast_commentsMapper:
    """Mapper for Podcast_comments between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Podcast_comments) -> Podcast_commentsResponse:
        """Convert entity to response DTO"""
        return Podcast_commentsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Podcast_commentsCreate, Podcast_commentsUpdate]) -> Podcast_comments:
        """Convert DTO to entity"""
        return Podcast_comments(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Podcast_comments, dto: Podcast_commentsUpdate) -> Podcast_comments:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

podcast_comments_mapper = Podcast_commentsMapper()
