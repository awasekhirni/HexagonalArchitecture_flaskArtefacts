from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Podcast_commentsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Podcast_commentsBase(BaseModel):
    """Base schema for podcast_comments"""
    pass

class Podcast_commentsCreate(Podcast_commentsBase):
    """Schema for creating podcast_comments"""
    name: str
    description: Optional[str] = None
    status: Podcast_commentsStatus = Podcast_commentsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Podcast_commentsUpdate(Podcast_commentsBase):
    """Schema for updating podcast_comments"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Podcast_commentsStatus] = None

class Podcast_commentsResponse(Podcast_commentsBase):
    """Response schema for podcast_comments"""
    id: str
    name: str
    description: Optional[str] = None
    status: Podcast_commentsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_podcast_comments_create(data: Podcast_commentsCreate) -> Podcast_commentsCreate:
    """Validate podcast_comments creation data"""
    return data

def validate_podcast_comments_update(data: Podcast_commentsUpdate) -> Podcast_commentsUpdate:
    """Validate podcast_comments update data"""
    return data
