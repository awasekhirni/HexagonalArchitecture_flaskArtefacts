from typing import List, Optional
from domain.podcast_comments.podcast_comments_entity import Podcast_comments
from domain.podcast_comments.podcast_comments_service_interface import IAsyncPodcast_commentsService
from infrastructure.repositories.podcast_comments.podcast_comments_repository import Podcast_commentsRepository
from api.mappers.podcast_comments_mapper import podcast_comments_mapper
from shared.utils.logger import logger

class Podcast_commentsService(IAsyncPodcast_commentsService):
    """Service implementation for Podcast_comments"""

    def __init__(self):
        self.repository = Podcast_commentsRepository()

    async def get_by_id(self, id: str) -> Optional[Podcast_comments]:
        """Get podcast_comments by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting podcast_comments by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Podcast_comments]:
        """Get all podcast_commentss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all podcast_commentss: {str(e)}")
            raise

    async def create(self, data: Podcast_comments) -> Podcast_comments:
        """Create new podcast_comments"""
        try:
            return await self.repository.create(podcast_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating podcast_comments: {str(e)}")
            raise

    async def update(self, id: str, data: Podcast_comments) -> Optional[Podcast_comments]:
        """Update podcast_comments"""
        try:
            return await self.repository.update(id, podcast_comments_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating podcast_comments: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete podcast_comments"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting podcast_comments: {str(e)}")
            raise
