from typing import List, Optional
from domain.blog_posts.blog_posts_entity import Blog_posts
from domain.blog_posts.blog_posts_service_interface import IAsyncBlog_postsService
from infrastructure.repositories.blog_posts.blog_posts_repository import Blog_postsRepository
from api.mappers.blog_posts_mapper import blog_posts_mapper
from shared.utils.logger import logger

class Blog_postsService(IAsyncBlog_postsService):
    """Service implementation for Blog_posts"""

    def __init__(self):
        self.repository = Blog_postsRepository()

    async def get_by_id(self, id: str) -> Optional[Blog_posts]:
        """Get blog_posts by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting blog_posts by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Blog_posts]:
        """Get all blog_postss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all blog_postss: {str(e)}")
            raise

    async def create(self, data: Blog_posts) -> Blog_posts:
        """Create new blog_posts"""
        try:
            return await self.repository.create(blog_posts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating blog_posts: {str(e)}")
            raise

    async def update(self, id: str, data: Blog_posts) -> Optional[Blog_posts]:
        """Update blog_posts"""
        try:
            return await self.repository.update(id, blog_posts_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating blog_posts: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete blog_posts"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting blog_posts: {str(e)}")
            raise
