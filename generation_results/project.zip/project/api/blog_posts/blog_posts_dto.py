from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Blog_postsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Blog_postsBase(BaseModel):
    """Base schema for blog_posts"""
    pass

class Blog_postsCreate(Blog_postsBase):
    """Schema for creating blog_posts"""
    name: str
    description: Optional[str] = None
    status: Blog_postsStatus = Blog_postsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Blog_postsUpdate(Blog_postsBase):
    """Schema for updating blog_posts"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Blog_postsStatus] = None

class Blog_postsResponse(Blog_postsBase):
    """Response schema for blog_posts"""
    id: str
    name: str
    description: Optional[str] = None
    status: Blog_postsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_blog_posts_create(data: Blog_postsCreate) -> Blog_postsCreate:
    """Validate blog_posts creation data"""
    return data

def validate_blog_posts_update(data: Blog_postsUpdate) -> Blog_postsUpdate:
    """Validate blog_posts update data"""
    return data
