from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.blog_posts.blog_posts_entity import Blog_posts
from domain.blog_posts.blog_posts_service_interface import IAsyncBlog_postsService
from api.dtos.blog_posts_dto import Blog_postsCreate, Blog_postsUpdate, Blog_postsResponse
from api.mappers.blog_posts_mapper import blog_posts_mapper
from api.validations.blog_posts_validation_schemas import validate_blog_posts_create, validate_blog_posts_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('blog_posts', description='Blog_posts operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
blog_posts_create_model = api.model('Blog_postsCreate', {
    'name': fields.String(required=True, description='blog_posts name'),
    'description': fields.String(description='blog_posts description'),
    'status': fields.String(description='blog_posts status', enum=['active', 'inactive', 'pending'])
})

blog_posts_update_model = api.model('Blog_postsUpdate', {
    'name': fields.String(description='blog_posts name'),
    'description': fields.String(description='blog_posts description'),
    'status': fields.String(description='blog_posts status', enum=['active', 'inactive', 'pending'])
})

blog_posts_response_model = api.model('Blog_postsResponse', {
    'id': fields.String(description='blog_posts ID'),
    'name': fields.String(description='blog_posts name'),
    'description': fields.String(description='blog_posts description'),
    'status': fields.String(description='blog_posts status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncBlog_postsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Blog_postsList(Resource):
        @api.doc('list_blog_postss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(blog_posts_response_model)
        @token_required
        async def get(self):
            """List all blog_postss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [blog_posts_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting blog_postss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_blog_posts')
        @api.expect(blog_posts_create_model)
        @api.marshal_with(blog_posts_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new blog_posts"""
            try:
                data = api.payload
                validated_data = validate_blog_posts_create(data)
                entity = blog_posts_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return blog_posts_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating blog_posts: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The blog_posts identifier')
    @api.response(404, 'Blog_posts not found')
    class Blog_postsResource(Resource):
        @api.doc('get_blog_posts')
        @api.marshal_with(blog_posts_response_model)
        @token_required
        async def get(self, id):
            """Get a blog_posts given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Blog_posts not found")
                return blog_posts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting blog_posts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_blog_posts')
        @api.expect(blog_posts_update_model)
        @api.marshal_with(blog_posts_response_model)
        @token_required
        async def put(self, id):
            """Update a blog_posts given its identifier"""
            try:
                data = api.payload
                validated_data = validate_blog_posts_update(data)
                entity = blog_posts_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Blog_posts not found")
                return blog_posts_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating blog_posts {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_blog_posts')
        @api.response(204, 'Blog_posts deleted')
        @token_required
        async def delete(self, id):
            """Delete a blog_posts given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Blog_posts not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting blog_posts {id}: {str(e)}")
                api.abort(400, str(e))

    return api
