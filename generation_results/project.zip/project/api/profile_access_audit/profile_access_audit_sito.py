from typing import List, Optional
from domain.profile_access_audit.profile_access_audit_entity import Profile_access_audit
from domain.profile_access_audit.profile_access_audit_service_interface import IAsyncProfile_access_auditService
from infrastructure.repositories.profile_access_audit.profile_access_audit_repository import Profile_access_auditRepository
from api.mappers.profile_access_audit_mapper import profile_access_audit_mapper
from shared.utils.logger import logger

class Profile_access_auditService(IAsyncProfile_access_auditService):
    """Service implementation for Profile_access_audit"""

    def __init__(self):
        self.repository = Profile_access_auditRepository()

    async def get_by_id(self, id: str) -> Optional[Profile_access_audit]:
        """Get profile_access_audit by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting profile_access_audit by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Profile_access_audit]:
        """Get all profile_access_audits"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all profile_access_audits: {str(e)}")
            raise

    async def create(self, data: Profile_access_audit) -> Profile_access_audit:
        """Create new profile_access_audit"""
        try:
            return await self.repository.create(profile_access_audit_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating profile_access_audit: {str(e)}")
            raise

    async def update(self, id: str, data: Profile_access_audit) -> Optional[Profile_access_audit]:
        """Update profile_access_audit"""
        try:
            return await self.repository.update(id, profile_access_audit_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating profile_access_audit: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete profile_access_audit"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting profile_access_audit: {str(e)}")
            raise
