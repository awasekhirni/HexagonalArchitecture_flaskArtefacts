from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.profile_access_audit.profile_access_audit_entity import Profile_access_audit
from domain.profile_access_audit.profile_access_audit_service_interface import IAsyncProfile_access_auditService
from api.dtos.profile_access_audit_dto import Profile_access_auditCreate, Profile_access_auditUpdate, Profile_access_auditResponse
from api.mappers.profile_access_audit_mapper import profile_access_audit_mapper
from api.validations.profile_access_audit_validation_schemas import validate_profile_access_audit_create, validate_profile_access_audit_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('profile_access_audit', description='Profile_access_audit operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
profile_access_audit_create_model = api.model('Profile_access_auditCreate', {
    'name': fields.String(required=True, description='profile_access_audit name'),
    'description': fields.String(description='profile_access_audit description'),
    'status': fields.String(description='profile_access_audit status', enum=['active', 'inactive', 'pending'])
})

profile_access_audit_update_model = api.model('Profile_access_auditUpdate', {
    'name': fields.String(description='profile_access_audit name'),
    'description': fields.String(description='profile_access_audit description'),
    'status': fields.String(description='profile_access_audit status', enum=['active', 'inactive', 'pending'])
})

profile_access_audit_response_model = api.model('Profile_access_auditResponse', {
    'id': fields.String(description='profile_access_audit ID'),
    'name': fields.String(description='profile_access_audit name'),
    'description': fields.String(description='profile_access_audit description'),
    'status': fields.String(description='profile_access_audit status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProfile_access_auditService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Profile_access_auditList(Resource):
        @api.doc('list_profile_access_audits')
        @api.expect(pagination_parser)
        @api.marshal_list_with(profile_access_audit_response_model)
        @token_required
        async def get(self):
            """List all profile_access_audits"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [profile_access_audit_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting profile_access_audits: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_profile_access_audit')
        @api.expect(profile_access_audit_create_model)
        @api.marshal_with(profile_access_audit_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new profile_access_audit"""
            try:
                data = api.payload
                validated_data = validate_profile_access_audit_create(data)
                entity = profile_access_audit_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return profile_access_audit_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating profile_access_audit: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The profile_access_audit identifier')
    @api.response(404, 'Profile_access_audit not found')
    class Profile_access_auditResource(Resource):
        @api.doc('get_profile_access_audit')
        @api.marshal_with(profile_access_audit_response_model)
        @token_required
        async def get(self, id):
            """Get a profile_access_audit given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Profile_access_audit not found")
                return profile_access_audit_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting profile_access_audit {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_profile_access_audit')
        @api.expect(profile_access_audit_update_model)
        @api.marshal_with(profile_access_audit_response_model)
        @token_required
        async def put(self, id):
            """Update a profile_access_audit given its identifier"""
            try:
                data = api.payload
                validated_data = validate_profile_access_audit_update(data)
                entity = profile_access_audit_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Profile_access_audit not found")
                return profile_access_audit_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating profile_access_audit {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_profile_access_audit')
        @api.response(204, 'Profile_access_audit deleted')
        @token_required
        async def delete(self, id):
            """Delete a profile_access_audit given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Profile_access_audit not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting profile_access_audit {id}: {str(e)}")
                api.abort(400, str(e))

    return api
