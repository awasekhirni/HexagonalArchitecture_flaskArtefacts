from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Profile_access_auditStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Profile_access_auditBase(BaseModel):
    """Base schema for profile_access_audit"""
    pass

class Profile_access_auditCreate(Profile_access_auditBase):
    """Schema for creating profile_access_audit"""
    name: str
    description: Optional[str] = None
    status: Profile_access_auditStatus = Profile_access_auditStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Profile_access_auditUpdate(Profile_access_auditBase):
    """Schema for updating profile_access_audit"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Profile_access_auditStatus] = None

class Profile_access_auditResponse(Profile_access_auditBase):
    """Response schema for profile_access_audit"""
    id: str
    name: str
    description: Optional[str] = None
    status: Profile_access_auditStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_profile_access_audit_create(data: Profile_access_auditCreate) -> Profile_access_auditCreate:
    """Validate profile_access_audit creation data"""
    return data

def validate_profile_access_audit_update(data: Profile_access_auditUpdate) -> Profile_access_auditUpdate:
    """Validate profile_access_audit update data"""
    return data
