from typing import List, Optional
from domain.employee_resignations.employee_resignations_entity import Employee_resignations
from domain.employee_resignations.employee_resignations_service_interface import IAsyncEmployee_resignationsService
from infrastructure.repositories.employee_resignations.employee_resignations_repository import Employee_resignationsRepository
from api.mappers.employee_resignations_mapper import employee_resignations_mapper
from shared.utils.logger import logger

class Employee_resignationsService(IAsyncEmployee_resignationsService):
    """Service implementation for Employee_resignations"""

    def __init__(self):
        self.repository = Employee_resignationsRepository()

    async def get_by_id(self, id: str) -> Optional[Employee_resignations]:
        """Get employee_resignations by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting employee_resignations by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Employee_resignations]:
        """Get all employee_resignationss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all employee_resignationss: {str(e)}")
            raise

    async def create(self, data: Employee_resignations) -> Employee_resignations:
        """Create new employee_resignations"""
        try:
            return await self.repository.create(employee_resignations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating employee_resignations: {str(e)}")
            raise

    async def update(self, id: str, data: Employee_resignations) -> Optional[Employee_resignations]:
        """Update employee_resignations"""
        try:
            return await self.repository.update(id, employee_resignations_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating employee_resignations: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete employee_resignations"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting employee_resignations: {str(e)}")
            raise
