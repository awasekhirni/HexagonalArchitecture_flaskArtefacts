from domain.employee_resignations.employee_resignations_entity import Employee_resignations
from api.dtos.employee_resignations_dto import Employee_resignationsCreate, Employee_resignationsUpdate, Employee_resignationsResponse
from typing import Union

class Employee_resignationsMapper:
    """Mapper for Employee_resignations between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Employee_resignations) -> Employee_resignationsResponse:
        """Convert entity to response DTO"""
        return Employee_resignationsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Employee_resignationsCreate, Employee_resignationsUpdate]) -> Employee_resignations:
        """Convert DTO to entity"""
        return Employee_resignations(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Employee_resignations, dto: Employee_resignationsUpdate) -> Employee_resignations:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

employee_resignations_mapper = Employee_resignationsMapper()
