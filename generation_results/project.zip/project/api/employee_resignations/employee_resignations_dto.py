from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Employee_resignationsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Employee_resignationsBase(BaseModel):
    """Base schema for employee_resignations"""
    pass

class Employee_resignationsCreate(Employee_resignationsBase):
    """Schema for creating employee_resignations"""
    name: str
    description: Optional[str] = None
    status: Employee_resignationsStatus = Employee_resignationsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Employee_resignationsUpdate(Employee_resignationsBase):
    """Schema for updating employee_resignations"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Employee_resignationsStatus] = None

class Employee_resignationsResponse(Employee_resignationsBase):
    """Response schema for employee_resignations"""
    id: str
    name: str
    description: Optional[str] = None
    status: Employee_resignationsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_employee_resignations_create(data: Employee_resignationsCreate) -> Employee_resignationsCreate:
    """Validate employee_resignations creation data"""
    return data

def validate_employee_resignations_update(data: Employee_resignationsUpdate) -> Employee_resignationsUpdate:
    """Validate employee_resignations update data"""
    return data
