from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.employee_resignations.employee_resignations_entity import Employee_resignations
from domain.employee_resignations.employee_resignations_service_interface import IAsyncEmployee_resignationsService
from api.dtos.employee_resignations_dto import Employee_resignationsCreate, Employee_resignationsUpdate, Employee_resignationsResponse
from api.mappers.employee_resignations_mapper import employee_resignations_mapper
from api.validations.employee_resignations_validation_schemas import validate_employee_resignations_create, validate_employee_resignations_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('employee_resignations', description='Employee_resignations operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
employee_resignations_create_model = api.model('Employee_resignationsCreate', {
    'name': fields.String(required=True, description='employee_resignations name'),
    'description': fields.String(description='employee_resignations description'),
    'status': fields.String(description='employee_resignations status', enum=['active', 'inactive', 'pending'])
})

employee_resignations_update_model = api.model('Employee_resignationsUpdate', {
    'name': fields.String(description='employee_resignations name'),
    'description': fields.String(description='employee_resignations description'),
    'status': fields.String(description='employee_resignations status', enum=['active', 'inactive', 'pending'])
})

employee_resignations_response_model = api.model('Employee_resignationsResponse', {
    'id': fields.String(description='employee_resignations ID'),
    'name': fields.String(description='employee_resignations name'),
    'description': fields.String(description='employee_resignations description'),
    'status': fields.String(description='employee_resignations status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncEmployee_resignationsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Employee_resignationsList(Resource):
        @api.doc('list_employee_resignationss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(employee_resignations_response_model)
        @token_required
        async def get(self):
            """List all employee_resignationss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [employee_resignations_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting employee_resignationss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_employee_resignations')
        @api.expect(employee_resignations_create_model)
        @api.marshal_with(employee_resignations_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new employee_resignations"""
            try:
                data = api.payload
                validated_data = validate_employee_resignations_create(data)
                entity = employee_resignations_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return employee_resignations_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating employee_resignations: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The employee_resignations identifier')
    @api.response(404, 'Employee_resignations not found')
    class Employee_resignationsResource(Resource):
        @api.doc('get_employee_resignations')
        @api.marshal_with(employee_resignations_response_model)
        @token_required
        async def get(self, id):
            """Get a employee_resignations given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Employee_resignations not found")
                return employee_resignations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting employee_resignations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_employee_resignations')
        @api.expect(employee_resignations_update_model)
        @api.marshal_with(employee_resignations_response_model)
        @token_required
        async def put(self, id):
            """Update a employee_resignations given its identifier"""
            try:
                data = api.payload
                validated_data = validate_employee_resignations_update(data)
                entity = employee_resignations_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Employee_resignations not found")
                return employee_resignations_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating employee_resignations {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_employee_resignations')
        @api.response(204, 'Employee_resignations deleted')
        @token_required
        async def delete(self, id):
            """Delete a employee_resignations given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Employee_resignations not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting employee_resignations {id}: {str(e)}")
                api.abort(400, str(e))

    return api
