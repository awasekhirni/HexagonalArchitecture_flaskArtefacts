from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.interests.interests_entity import Interests
from domain.interests.interests_service_interface import IAsyncInterestsService
from api.dtos.interests_dto import InterestsCreate, InterestsUpdate, InterestsResponse
from api.mappers.interests_mapper import interests_mapper
from api.validations.interests_validation_schemas import validate_interests_create, validate_interests_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('interests', description='Interests operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
interests_create_model = api.model('InterestsCreate', {
    'name': fields.String(required=True, description='interests name'),
    'description': fields.String(description='interests description'),
    'status': fields.String(description='interests status', enum=['active', 'inactive', 'pending'])
})

interests_update_model = api.model('InterestsUpdate', {
    'name': fields.String(description='interests name'),
    'description': fields.String(description='interests description'),
    'status': fields.String(description='interests status', enum=['active', 'inactive', 'pending'])
})

interests_response_model = api.model('InterestsResponse', {
    'id': fields.String(description='interests ID'),
    'name': fields.String(description='interests name'),
    'description': fields.String(description='interests description'),
    'status': fields.String(description='interests status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncInterestsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class InterestsList(Resource):
        @api.doc('list_interestss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(interests_response_model)
        @token_required
        async def get(self):
            """List all interestss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [interests_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting interestss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_interests')
        @api.expect(interests_create_model)
        @api.marshal_with(interests_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new interests"""
            try:
                data = api.payload
                validated_data = validate_interests_create(data)
                entity = interests_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return interests_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating interests: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The interests identifier')
    @api.response(404, 'Interests not found')
    class InterestsResource(Resource):
        @api.doc('get_interests')
        @api.marshal_with(interests_response_model)
        @token_required
        async def get(self, id):
            """Get a interests given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Interests not found")
                return interests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting interests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_interests')
        @api.expect(interests_update_model)
        @api.marshal_with(interests_response_model)
        @token_required
        async def put(self, id):
            """Update a interests given its identifier"""
            try:
                data = api.payload
                validated_data = validate_interests_update(data)
                entity = interests_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Interests not found")
                return interests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating interests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_interests')
        @api.response(204, 'Interests deleted')
        @token_required
        async def delete(self, id):
            """Delete a interests given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Interests not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting interests {id}: {str(e)}")
                api.abort(400, str(e))

    return api
