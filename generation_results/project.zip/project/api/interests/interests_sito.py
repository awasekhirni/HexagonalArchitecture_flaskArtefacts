from typing import List, Optional
from domain.interests.interests_entity import Interests
from domain.interests.interests_service_interface import IAsyncInterestsService
from infrastructure.repositories.interests.interests_repository import InterestsRepository
from api.mappers.interests_mapper import interests_mapper
from shared.utils.logger import logger

class InterestsService(IAsyncInterestsService):
    """Service implementation for Interests"""

    def __init__(self):
        self.repository = InterestsRepository()

    async def get_by_id(self, id: str) -> Optional[Interests]:
        """Get interests by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting interests by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Interests]:
        """Get all interestss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all interestss: {str(e)}")
            raise

    async def create(self, data: Interests) -> Interests:
        """Create new interests"""
        try:
            return await self.repository.create(interests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating interests: {str(e)}")
            raise

    async def update(self, id: str, data: Interests) -> Optional[Interests]:
        """Update interests"""
        try:
            return await self.repository.update(id, interests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating interests: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete interests"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting interests: {str(e)}")
            raise
