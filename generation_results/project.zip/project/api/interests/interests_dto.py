from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class InterestsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class InterestsBase(BaseModel):
    """Base schema for interests"""
    pass

class InterestsCreate(InterestsBase):
    """Schema for creating interests"""
    name: str
    description: Optional[str] = None
    status: InterestsStatus = InterestsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class InterestsUpdate(InterestsBase):
    """Schema for updating interests"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[InterestsStatus] = None

class InterestsResponse(InterestsBase):
    """Response schema for interests"""
    id: str
    name: str
    description: Optional[str] = None
    status: InterestsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_interests_create(data: InterestsCreate) -> InterestsCreate:
    """Validate interests creation data"""
    return data

def validate_interests_update(data: InterestsUpdate) -> InterestsUpdate:
    """Validate interests update data"""
    return data
