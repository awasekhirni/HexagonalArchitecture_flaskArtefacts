from typing import List, Optional
from domain.direct_messages.direct_messages_entity import Direct_messages
from domain.direct_messages.direct_messages_service_interface import IAsyncDirect_messagesService
from infrastructure.repositories.direct_messages.direct_messages_repository import Direct_messagesRepository
from api.mappers.direct_messages_mapper import direct_messages_mapper
from shared.utils.logger import logger

class Direct_messagesService(IAsyncDirect_messagesService):
    """Service implementation for Direct_messages"""

    def __init__(self):
        self.repository = Direct_messagesRepository()

    async def get_by_id(self, id: str) -> Optional[Direct_messages]:
        """Get direct_messages by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting direct_messages by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Direct_messages]:
        """Get all direct_messagess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all direct_messagess: {str(e)}")
            raise

    async def create(self, data: Direct_messages) -> Direct_messages:
        """Create new direct_messages"""
        try:
            return await self.repository.create(direct_messages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating direct_messages: {str(e)}")
            raise

    async def update(self, id: str, data: Direct_messages) -> Optional[Direct_messages]:
        """Update direct_messages"""
        try:
            return await self.repository.update(id, direct_messages_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating direct_messages: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete direct_messages"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting direct_messages: {str(e)}")
            raise
