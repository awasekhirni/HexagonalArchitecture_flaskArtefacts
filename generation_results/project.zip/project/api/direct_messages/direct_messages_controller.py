from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.direct_messages.direct_messages_entity import Direct_messages
from domain.direct_messages.direct_messages_service_interface import IAsyncDirect_messagesService
from api.dtos.direct_messages_dto import Direct_messagesCreate, Direct_messagesUpdate, Direct_messagesResponse
from api.mappers.direct_messages_mapper import direct_messages_mapper
from api.validations.direct_messages_validation_schemas import validate_direct_messages_create, validate_direct_messages_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('direct_messages', description='Direct_messages operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
direct_messages_create_model = api.model('Direct_messagesCreate', {
    'name': fields.String(required=True, description='direct_messages name'),
    'description': fields.String(description='direct_messages description'),
    'status': fields.String(description='direct_messages status', enum=['active', 'inactive', 'pending'])
})

direct_messages_update_model = api.model('Direct_messagesUpdate', {
    'name': fields.String(description='direct_messages name'),
    'description': fields.String(description='direct_messages description'),
    'status': fields.String(description='direct_messages status', enum=['active', 'inactive', 'pending'])
})

direct_messages_response_model = api.model('Direct_messagesResponse', {
    'id': fields.String(description='direct_messages ID'),
    'name': fields.String(description='direct_messages name'),
    'description': fields.String(description='direct_messages description'),
    'status': fields.String(description='direct_messages status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncDirect_messagesService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Direct_messagesList(Resource):
        @api.doc('list_direct_messagess')
        @api.expect(pagination_parser)
        @api.marshal_list_with(direct_messages_response_model)
        @token_required
        async def get(self):
            """List all direct_messagess"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [direct_messages_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting direct_messagess: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_direct_messages')
        @api.expect(direct_messages_create_model)
        @api.marshal_with(direct_messages_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new direct_messages"""
            try:
                data = api.payload
                validated_data = validate_direct_messages_create(data)
                entity = direct_messages_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return direct_messages_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating direct_messages: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The direct_messages identifier')
    @api.response(404, 'Direct_messages not found')
    class Direct_messagesResource(Resource):
        @api.doc('get_direct_messages')
        @api.marshal_with(direct_messages_response_model)
        @token_required
        async def get(self, id):
            """Get a direct_messages given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Direct_messages not found")
                return direct_messages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting direct_messages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_direct_messages')
        @api.expect(direct_messages_update_model)
        @api.marshal_with(direct_messages_response_model)
        @token_required
        async def put(self, id):
            """Update a direct_messages given its identifier"""
            try:
                data = api.payload
                validated_data = validate_direct_messages_update(data)
                entity = direct_messages_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Direct_messages not found")
                return direct_messages_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating direct_messages {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_direct_messages')
        @api.response(204, 'Direct_messages deleted')
        @token_required
        async def delete(self, id):
            """Delete a direct_messages given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Direct_messages not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting direct_messages {id}: {str(e)}")
                api.abort(400, str(e))

    return api
