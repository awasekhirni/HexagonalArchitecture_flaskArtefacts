from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Direct_messagesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Direct_messagesBase(BaseModel):
    """Base schema for direct_messages"""
    pass

class Direct_messagesCreate(Direct_messagesBase):
    """Schema for creating direct_messages"""
    name: str
    description: Optional[str] = None
    status: Direct_messagesStatus = Direct_messagesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Direct_messagesUpdate(Direct_messagesBase):
    """Schema for updating direct_messages"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Direct_messagesStatus] = None

class Direct_messagesResponse(Direct_messagesBase):
    """Response schema for direct_messages"""
    id: str
    name: str
    description: Optional[str] = None
    status: Direct_messagesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_direct_messages_create(data: Direct_messagesCreate) -> Direct_messagesCreate:
    """Validate direct_messages creation data"""
    return data

def validate_direct_messages_update(data: Direct_messagesUpdate) -> Direct_messagesUpdate:
    """Validate direct_messages update data"""
    return data
