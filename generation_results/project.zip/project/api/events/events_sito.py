from typing import List, Optional
from domain.events.events_entity import Events
from domain.events.events_service_interface import IAsyncEventsService
from infrastructure.repositories.events.events_repository import EventsRepository
from api.mappers.events_mapper import events_mapper
from shared.utils.logger import logger

class EventsService(IAsyncEventsService):
    """Service implementation for Events"""

    def __init__(self):
        self.repository = EventsRepository()

    async def get_by_id(self, id: str) -> Optional[Events]:
        """Get events by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting events by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Events]:
        """Get all eventss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all eventss: {str(e)}")
            raise

    async def create(self, data: Events) -> Events:
        """Create new events"""
        try:
            return await self.repository.create(events_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating events: {str(e)}")
            raise

    async def update(self, id: str, data: Events) -> Optional[Events]:
        """Update events"""
        try:
            return await self.repository.update(id, events_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating events: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete events"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting events: {str(e)}")
            raise
