from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class EventsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class EventsBase(BaseModel):
    """Base schema for events"""
    pass

class EventsCreate(EventsBase):
    """Schema for creating events"""
    name: str
    description: Optional[str] = None
    status: EventsStatus = EventsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class EventsUpdate(EventsBase):
    """Schema for updating events"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[EventsStatus] = None

class EventsResponse(EventsBase):
    """Response schema for events"""
    id: str
    name: str
    description: Optional[str] = None
    status: EventsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_events_create(data: EventsCreate) -> EventsCreate:
    """Validate events creation data"""
    return data

def validate_events_update(data: EventsUpdate) -> EventsUpdate:
    """Validate events update data"""
    return data
