from domain.events.events_entity import Events
from api.dtos.events_dto import EventsCreate, EventsUpdate, EventsResponse
from typing import Union

class EventsMapper:
    """Mapper for Events between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Events) -> EventsResponse:
        """Convert entity to response DTO"""
        return EventsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[EventsCreate, EventsUpdate]) -> Events:
        """Convert DTO to entity"""
        return Events(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Events, dto: EventsUpdate) -> Events:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

events_mapper = EventsMapper()
