from typing import List, Optional
from domain.profile_visits.profile_visits_entity import Profile_visits
from domain.profile_visits.profile_visits_service_interface import IAsyncProfile_visitsService
from infrastructure.repositories.profile_visits.profile_visits_repository import Profile_visitsRepository
from api.mappers.profile_visits_mapper import profile_visits_mapper
from shared.utils.logger import logger

class Profile_visitsService(IAsyncProfile_visitsService):
    """Service implementation for Profile_visits"""

    def __init__(self):
        self.repository = Profile_visitsRepository()

    async def get_by_id(self, id: str) -> Optional[Profile_visits]:
        """Get profile_visits by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting profile_visits by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Profile_visits]:
        """Get all profile_visitss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all profile_visitss: {str(e)}")
            raise

    async def create(self, data: Profile_visits) -> Profile_visits:
        """Create new profile_visits"""
        try:
            return await self.repository.create(profile_visits_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating profile_visits: {str(e)}")
            raise

    async def update(self, id: str, data: Profile_visits) -> Optional[Profile_visits]:
        """Update profile_visits"""
        try:
            return await self.repository.update(id, profile_visits_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating profile_visits: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete profile_visits"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting profile_visits: {str(e)}")
            raise
