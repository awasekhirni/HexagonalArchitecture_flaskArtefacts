from domain.profile_visits.profile_visits_entity import Profile_visits
from api.dtos.profile_visits_dto import Profile_visitsCreate, Profile_visitsUpdate, Profile_visitsResponse
from typing import Union

class Profile_visitsMapper:
    """Mapper for Profile_visits between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Profile_visits) -> Profile_visitsResponse:
        """Convert entity to response DTO"""
        return Profile_visitsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Profile_visitsCreate, Profile_visitsUpdate]) -> Profile_visits:
        """Convert DTO to entity"""
        return Profile_visits(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Profile_visits, dto: Profile_visitsUpdate) -> Profile_visits:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

profile_visits_mapper = Profile_visitsMapper()
