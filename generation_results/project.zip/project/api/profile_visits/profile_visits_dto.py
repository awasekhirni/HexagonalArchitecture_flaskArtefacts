from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Profile_visitsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Profile_visitsBase(BaseModel):
    """Base schema for profile_visits"""
    pass

class Profile_visitsCreate(Profile_visitsBase):
    """Schema for creating profile_visits"""
    name: str
    description: Optional[str] = None
    status: Profile_visitsStatus = Profile_visitsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Profile_visitsUpdate(Profile_visitsBase):
    """Schema for updating profile_visits"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Profile_visitsStatus] = None

class Profile_visitsResponse(Profile_visitsBase):
    """Response schema for profile_visits"""
    id: str
    name: str
    description: Optional[str] = None
    status: Profile_visitsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_profile_visits_create(data: Profile_visitsCreate) -> Profile_visitsCreate:
    """Validate profile_visits creation data"""
    return data

def validate_profile_visits_update(data: Profile_visitsUpdate) -> Profile_visitsUpdate:
    """Validate profile_visits update data"""
    return data
