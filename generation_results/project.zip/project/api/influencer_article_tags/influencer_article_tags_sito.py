from typing import List, Optional
from domain.influencer_article_tags.influencer_article_tags_entity import Influencer_article_tags
from domain.influencer_article_tags.influencer_article_tags_service_interface import IAsyncInfluencer_article_tagsService
from infrastructure.repositories.influencer_article_tags.influencer_article_tags_repository import Influencer_article_tagsRepository
from api.mappers.influencer_article_tags_mapper import influencer_article_tags_mapper
from shared.utils.logger import logger

class Influencer_article_tagsService(IAsyncInfluencer_article_tagsService):
    """Service implementation for Influencer_article_tags"""

    def __init__(self):
        self.repository = Influencer_article_tagsRepository()

    async def get_by_id(self, id: str) -> Optional[Influencer_article_tags]:
        """Get influencer_article_tags by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting influencer_article_tags by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Influencer_article_tags]:
        """Get all influencer_article_tagss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all influencer_article_tagss: {str(e)}")
            raise

    async def create(self, data: Influencer_article_tags) -> Influencer_article_tags:
        """Create new influencer_article_tags"""
        try:
            return await self.repository.create(influencer_article_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating influencer_article_tags: {str(e)}")
            raise

    async def update(self, id: str, data: Influencer_article_tags) -> Optional[Influencer_article_tags]:
        """Update influencer_article_tags"""
        try:
            return await self.repository.update(id, influencer_article_tags_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating influencer_article_tags: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete influencer_article_tags"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting influencer_article_tags: {str(e)}")
            raise
