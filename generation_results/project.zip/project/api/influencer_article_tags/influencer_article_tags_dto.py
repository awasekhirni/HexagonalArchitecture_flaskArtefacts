from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Influencer_article_tagsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Influencer_article_tagsBase(BaseModel):
    """Base schema for influencer_article_tags"""
    pass

class Influencer_article_tagsCreate(Influencer_article_tagsBase):
    """Schema for creating influencer_article_tags"""
    name: str
    description: Optional[str] = None
    status: Influencer_article_tagsStatus = Influencer_article_tagsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Influencer_article_tagsUpdate(Influencer_article_tagsBase):
    """Schema for updating influencer_article_tags"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Influencer_article_tagsStatus] = None

class Influencer_article_tagsResponse(Influencer_article_tagsBase):
    """Response schema for influencer_article_tags"""
    id: str
    name: str
    description: Optional[str] = None
    status: Influencer_article_tagsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_influencer_article_tags_create(data: Influencer_article_tagsCreate) -> Influencer_article_tagsCreate:
    """Validate influencer_article_tags creation data"""
    return data

def validate_influencer_article_tags_update(data: Influencer_article_tagsUpdate) -> Influencer_article_tagsUpdate:
    """Validate influencer_article_tags update data"""
    return data
