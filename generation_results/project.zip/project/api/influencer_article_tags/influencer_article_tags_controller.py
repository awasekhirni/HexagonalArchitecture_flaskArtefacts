from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.influencer_article_tags.influencer_article_tags_entity import Influencer_article_tags
from domain.influencer_article_tags.influencer_article_tags_service_interface import IAsyncInfluencer_article_tagsService
from api.dtos.influencer_article_tags_dto import Influencer_article_tagsCreate, Influencer_article_tagsUpdate, Influencer_article_tagsResponse
from api.mappers.influencer_article_tags_mapper import influencer_article_tags_mapper
from api.validations.influencer_article_tags_validation_schemas import validate_influencer_article_tags_create, validate_influencer_article_tags_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('influencer_article_tags', description='Influencer_article_tags operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
influencer_article_tags_create_model = api.model('Influencer_article_tagsCreate', {
    'name': fields.String(required=True, description='influencer_article_tags name'),
    'description': fields.String(description='influencer_article_tags description'),
    'status': fields.String(description='influencer_article_tags status', enum=['active', 'inactive', 'pending'])
})

influencer_article_tags_update_model = api.model('Influencer_article_tagsUpdate', {
    'name': fields.String(description='influencer_article_tags name'),
    'description': fields.String(description='influencer_article_tags description'),
    'status': fields.String(description='influencer_article_tags status', enum=['active', 'inactive', 'pending'])
})

influencer_article_tags_response_model = api.model('Influencer_article_tagsResponse', {
    'id': fields.String(description='influencer_article_tags ID'),
    'name': fields.String(description='influencer_article_tags name'),
    'description': fields.String(description='influencer_article_tags description'),
    'status': fields.String(description='influencer_article_tags status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncInfluencer_article_tagsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Influencer_article_tagsList(Resource):
        @api.doc('list_influencer_article_tagss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(influencer_article_tags_response_model)
        @token_required
        async def get(self):
            """List all influencer_article_tagss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [influencer_article_tags_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting influencer_article_tagss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_influencer_article_tags')
        @api.expect(influencer_article_tags_create_model)
        @api.marshal_with(influencer_article_tags_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new influencer_article_tags"""
            try:
                data = api.payload
                validated_data = validate_influencer_article_tags_create(data)
                entity = influencer_article_tags_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return influencer_article_tags_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating influencer_article_tags: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The influencer_article_tags identifier')
    @api.response(404, 'Influencer_article_tags not found')
    class Influencer_article_tagsResource(Resource):
        @api.doc('get_influencer_article_tags')
        @api.marshal_with(influencer_article_tags_response_model)
        @token_required
        async def get(self, id):
            """Get a influencer_article_tags given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Influencer_article_tags not found")
                return influencer_article_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting influencer_article_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_influencer_article_tags')
        @api.expect(influencer_article_tags_update_model)
        @api.marshal_with(influencer_article_tags_response_model)
        @token_required
        async def put(self, id):
            """Update a influencer_article_tags given its identifier"""
            try:
                data = api.payload
                validated_data = validate_influencer_article_tags_update(data)
                entity = influencer_article_tags_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Influencer_article_tags not found")
                return influencer_article_tags_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating influencer_article_tags {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_influencer_article_tags')
        @api.response(204, 'Influencer_article_tags deleted')
        @token_required
        async def delete(self, id):
            """Delete a influencer_article_tags given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Influencer_article_tags not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting influencer_article_tags {id}: {str(e)}")
                api.abort(400, str(e))

    return api
