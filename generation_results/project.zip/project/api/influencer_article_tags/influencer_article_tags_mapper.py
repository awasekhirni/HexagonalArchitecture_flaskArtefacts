from domain.influencer_article_tags.influencer_article_tags_entity import Influencer_article_tags
from api.dtos.influencer_article_tags_dto import Influencer_article_tagsCreate, Influencer_article_tagsUpdate, Influencer_article_tagsResponse
from typing import Union

class Influencer_article_tagsMapper:
    """Mapper for Influencer_article_tags between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Influencer_article_tags) -> Influencer_article_tagsResponse:
        """Convert entity to response DTO"""
        return Influencer_article_tagsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Influencer_article_tagsCreate, Influencer_article_tagsUpdate]) -> Influencer_article_tags:
        """Convert DTO to entity"""
        return Influencer_article_tags(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Influencer_article_tags, dto: Influencer_article_tagsUpdate) -> Influencer_article_tags:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

influencer_article_tags_mapper = Influencer_article_tagsMapper()
