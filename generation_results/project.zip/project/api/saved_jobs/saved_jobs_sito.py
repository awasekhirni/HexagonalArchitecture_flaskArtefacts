from typing import List, Optional
from domain.saved_jobs.saved_jobs_entity import Saved_jobs
from domain.saved_jobs.saved_jobs_service_interface import IAsyncSaved_jobsService
from infrastructure.repositories.saved_jobs.saved_jobs_repository import Saved_jobsRepository
from api.mappers.saved_jobs_mapper import saved_jobs_mapper
from shared.utils.logger import logger

class Saved_jobsService(IAsyncSaved_jobsService):
    """Service implementation for Saved_jobs"""

    def __init__(self):
        self.repository = Saved_jobsRepository()

    async def get_by_id(self, id: str) -> Optional[Saved_jobs]:
        """Get saved_jobs by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting saved_jobs by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Saved_jobs]:
        """Get all saved_jobss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all saved_jobss: {str(e)}")
            raise

    async def create(self, data: Saved_jobs) -> Saved_jobs:
        """Create new saved_jobs"""
        try:
            return await self.repository.create(saved_jobs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating saved_jobs: {str(e)}")
            raise

    async def update(self, id: str, data: Saved_jobs) -> Optional[Saved_jobs]:
        """Update saved_jobs"""
        try:
            return await self.repository.update(id, saved_jobs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating saved_jobs: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete saved_jobs"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting saved_jobs: {str(e)}")
            raise
