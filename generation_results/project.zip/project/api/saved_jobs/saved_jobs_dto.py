from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Saved_jobsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Saved_jobsBase(BaseModel):
    """Base schema for saved_jobs"""
    pass

class Saved_jobsCreate(Saved_jobsBase):
    """Schema for creating saved_jobs"""
    name: str
    description: Optional[str] = None
    status: Saved_jobsStatus = Saved_jobsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Saved_jobsUpdate(Saved_jobsBase):
    """Schema for updating saved_jobs"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Saved_jobsStatus] = None

class Saved_jobsResponse(Saved_jobsBase):
    """Response schema for saved_jobs"""
    id: str
    name: str
    description: Optional[str] = None
    status: Saved_jobsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_saved_jobs_create(data: Saved_jobsCreate) -> Saved_jobsCreate:
    """Validate saved_jobs creation data"""
    return data

def validate_saved_jobs_update(data: Saved_jobsUpdate) -> Saved_jobsUpdate:
    """Validate saved_jobs update data"""
    return data
