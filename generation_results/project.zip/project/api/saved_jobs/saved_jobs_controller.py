from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.saved_jobs.saved_jobs_entity import Saved_jobs
from domain.saved_jobs.saved_jobs_service_interface import IAsyncSaved_jobsService
from api.dtos.saved_jobs_dto import Saved_jobsCreate, Saved_jobsUpdate, Saved_jobsResponse
from api.mappers.saved_jobs_mapper import saved_jobs_mapper
from api.validations.saved_jobs_validation_schemas import validate_saved_jobs_create, validate_saved_jobs_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('saved_jobs', description='Saved_jobs operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
saved_jobs_create_model = api.model('Saved_jobsCreate', {
    'name': fields.String(required=True, description='saved_jobs name'),
    'description': fields.String(description='saved_jobs description'),
    'status': fields.String(description='saved_jobs status', enum=['active', 'inactive', 'pending'])
})

saved_jobs_update_model = api.model('Saved_jobsUpdate', {
    'name': fields.String(description='saved_jobs name'),
    'description': fields.String(description='saved_jobs description'),
    'status': fields.String(description='saved_jobs status', enum=['active', 'inactive', 'pending'])
})

saved_jobs_response_model = api.model('Saved_jobsResponse', {
    'id': fields.String(description='saved_jobs ID'),
    'name': fields.String(description='saved_jobs name'),
    'description': fields.String(description='saved_jobs description'),
    'status': fields.String(description='saved_jobs status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncSaved_jobsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Saved_jobsList(Resource):
        @api.doc('list_saved_jobss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(saved_jobs_response_model)
        @token_required
        async def get(self):
            """List all saved_jobss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [saved_jobs_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting saved_jobss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_saved_jobs')
        @api.expect(saved_jobs_create_model)
        @api.marshal_with(saved_jobs_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new saved_jobs"""
            try:
                data = api.payload
                validated_data = validate_saved_jobs_create(data)
                entity = saved_jobs_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return saved_jobs_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating saved_jobs: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The saved_jobs identifier')
    @api.response(404, 'Saved_jobs not found')
    class Saved_jobsResource(Resource):
        @api.doc('get_saved_jobs')
        @api.marshal_with(saved_jobs_response_model)
        @token_required
        async def get(self, id):
            """Get a saved_jobs given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Saved_jobs not found")
                return saved_jobs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting saved_jobs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_saved_jobs')
        @api.expect(saved_jobs_update_model)
        @api.marshal_with(saved_jobs_response_model)
        @token_required
        async def put(self, id):
            """Update a saved_jobs given its identifier"""
            try:
                data = api.payload
                validated_data = validate_saved_jobs_update(data)
                entity = saved_jobs_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Saved_jobs not found")
                return saved_jobs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating saved_jobs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_saved_jobs')
        @api.response(204, 'Saved_jobs deleted')
        @token_required
        async def delete(self, id):
            """Delete a saved_jobs given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Saved_jobs not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting saved_jobs {id}: {str(e)}")
                api.abort(400, str(e))

    return api
