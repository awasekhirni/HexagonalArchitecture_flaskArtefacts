from typing import List, Optional
from domain.content_analytics.content_analytics_entity import Content_analytics
from domain.content_analytics.content_analytics_service_interface import IAsyncContent_analyticsService
from infrastructure.repositories.content_analytics.content_analytics_repository import Content_analyticsRepository
from api.mappers.content_analytics_mapper import content_analytics_mapper
from shared.utils.logger import logger

class Content_analyticsService(IAsyncContent_analyticsService):
    """Service implementation for Content_analytics"""

    def __init__(self):
        self.repository = Content_analyticsRepository()

    async def get_by_id(self, id: str) -> Optional[Content_analytics]:
        """Get content_analytics by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting content_analytics by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Content_analytics]:
        """Get all content_analyticss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all content_analyticss: {str(e)}")
            raise

    async def create(self, data: Content_analytics) -> Content_analytics:
        """Create new content_analytics"""
        try:
            return await self.repository.create(content_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating content_analytics: {str(e)}")
            raise

    async def update(self, id: str, data: Content_analytics) -> Optional[Content_analytics]:
        """Update content_analytics"""
        try:
            return await self.repository.update(id, content_analytics_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating content_analytics: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete content_analytics"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting content_analytics: {str(e)}")
            raise
