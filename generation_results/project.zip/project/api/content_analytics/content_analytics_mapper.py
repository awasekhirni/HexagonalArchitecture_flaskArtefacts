from domain.content_analytics.content_analytics_entity import Content_analytics
from api.dtos.content_analytics_dto import Content_analyticsCreate, Content_analyticsUpdate, Content_analyticsResponse
from typing import Union

class Content_analyticsMapper:
    """Mapper for Content_analytics between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Content_analytics) -> Content_analyticsResponse:
        """Convert entity to response DTO"""
        return Content_analyticsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Content_analyticsCreate, Content_analyticsUpdate]) -> Content_analytics:
        """Convert DTO to entity"""
        return Content_analytics(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Content_analytics, dto: Content_analyticsUpdate) -> Content_analytics:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

content_analytics_mapper = Content_analyticsMapper()
