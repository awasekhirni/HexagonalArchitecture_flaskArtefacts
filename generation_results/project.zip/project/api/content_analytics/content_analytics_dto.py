from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Content_analyticsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Content_analyticsBase(BaseModel):
    """Base schema for content_analytics"""
    pass

class Content_analyticsCreate(Content_analyticsBase):
    """Schema for creating content_analytics"""
    name: str
    description: Optional[str] = None
    status: Content_analyticsStatus = Content_analyticsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Content_analyticsUpdate(Content_analyticsBase):
    """Schema for updating content_analytics"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Content_analyticsStatus] = None

class Content_analyticsResponse(Content_analyticsBase):
    """Response schema for content_analytics"""
    id: str
    name: str
    description: Optional[str] = None
    status: Content_analyticsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_content_analytics_create(data: Content_analyticsCreate) -> Content_analyticsCreate:
    """Validate content_analytics creation data"""
    return data

def validate_content_analytics_update(data: Content_analyticsUpdate) -> Content_analyticsUpdate:
    """Validate content_analytics update data"""
    return data
