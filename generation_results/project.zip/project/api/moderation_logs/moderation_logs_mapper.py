from domain.moderation_logs.moderation_logs_entity import Moderation_logs
from api.dtos.moderation_logs_dto import Moderation_logsCreate, Moderation_logsUpdate, Moderation_logsResponse
from typing import Union

class Moderation_logsMapper:
    """Mapper for Moderation_logs between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Moderation_logs) -> Moderation_logsResponse:
        """Convert entity to response DTO"""
        return Moderation_logsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Moderation_logsCreate, Moderation_logsUpdate]) -> Moderation_logs:
        """Convert DTO to entity"""
        return Moderation_logs(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Moderation_logs, dto: Moderation_logsUpdate) -> Moderation_logs:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

moderation_logs_mapper = Moderation_logsMapper()
