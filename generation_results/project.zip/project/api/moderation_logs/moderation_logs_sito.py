from typing import List, Optional
from domain.moderation_logs.moderation_logs_entity import Moderation_logs
from domain.moderation_logs.moderation_logs_service_interface import IAsyncModeration_logsService
from infrastructure.repositories.moderation_logs.moderation_logs_repository import Moderation_logsRepository
from api.mappers.moderation_logs_mapper import moderation_logs_mapper
from shared.utils.logger import logger

class Moderation_logsService(IAsyncModeration_logsService):
    """Service implementation for Moderation_logs"""

    def __init__(self):
        self.repository = Moderation_logsRepository()

    async def get_by_id(self, id: str) -> Optional[Moderation_logs]:
        """Get moderation_logs by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting moderation_logs by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Moderation_logs]:
        """Get all moderation_logss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all moderation_logss: {str(e)}")
            raise

    async def create(self, data: Moderation_logs) -> Moderation_logs:
        """Create new moderation_logs"""
        try:
            return await self.repository.create(moderation_logs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating moderation_logs: {str(e)}")
            raise

    async def update(self, id: str, data: Moderation_logs) -> Optional[Moderation_logs]:
        """Update moderation_logs"""
        try:
            return await self.repository.update(id, moderation_logs_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating moderation_logs: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete moderation_logs"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting moderation_logs: {str(e)}")
            raise
