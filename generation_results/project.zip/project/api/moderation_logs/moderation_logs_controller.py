from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.moderation_logs.moderation_logs_entity import Moderation_logs
from domain.moderation_logs.moderation_logs_service_interface import IAsyncModeration_logsService
from api.dtos.moderation_logs_dto import Moderation_logsCreate, Moderation_logsUpdate, Moderation_logsResponse
from api.mappers.moderation_logs_mapper import moderation_logs_mapper
from api.validations.moderation_logs_validation_schemas import validate_moderation_logs_create, validate_moderation_logs_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('moderation_logs', description='Moderation_logs operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
moderation_logs_create_model = api.model('Moderation_logsCreate', {
    'name': fields.String(required=True, description='moderation_logs name'),
    'description': fields.String(description='moderation_logs description'),
    'status': fields.String(description='moderation_logs status', enum=['active', 'inactive', 'pending'])
})

moderation_logs_update_model = api.model('Moderation_logsUpdate', {
    'name': fields.String(description='moderation_logs name'),
    'description': fields.String(description='moderation_logs description'),
    'status': fields.String(description='moderation_logs status', enum=['active', 'inactive', 'pending'])
})

moderation_logs_response_model = api.model('Moderation_logsResponse', {
    'id': fields.String(description='moderation_logs ID'),
    'name': fields.String(description='moderation_logs name'),
    'description': fields.String(description='moderation_logs description'),
    'status': fields.String(description='moderation_logs status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncModeration_logsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Moderation_logsList(Resource):
        @api.doc('list_moderation_logss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(moderation_logs_response_model)
        @token_required
        async def get(self):
            """List all moderation_logss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [moderation_logs_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting moderation_logss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_moderation_logs')
        @api.expect(moderation_logs_create_model)
        @api.marshal_with(moderation_logs_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new moderation_logs"""
            try:
                data = api.payload
                validated_data = validate_moderation_logs_create(data)
                entity = moderation_logs_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return moderation_logs_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating moderation_logs: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The moderation_logs identifier')
    @api.response(404, 'Moderation_logs not found')
    class Moderation_logsResource(Resource):
        @api.doc('get_moderation_logs')
        @api.marshal_with(moderation_logs_response_model)
        @token_required
        async def get(self, id):
            """Get a moderation_logs given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Moderation_logs not found")
                return moderation_logs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting moderation_logs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_moderation_logs')
        @api.expect(moderation_logs_update_model)
        @api.marshal_with(moderation_logs_response_model)
        @token_required
        async def put(self, id):
            """Update a moderation_logs given its identifier"""
            try:
                data = api.payload
                validated_data = validate_moderation_logs_update(data)
                entity = moderation_logs_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Moderation_logs not found")
                return moderation_logs_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating moderation_logs {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_moderation_logs')
        @api.response(204, 'Moderation_logs deleted')
        @token_required
        async def delete(self, id):
            """Delete a moderation_logs given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Moderation_logs not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting moderation_logs {id}: {str(e)}")
                api.abort(400, str(e))

    return api
