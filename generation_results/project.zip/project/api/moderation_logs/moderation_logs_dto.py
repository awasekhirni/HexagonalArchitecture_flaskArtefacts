from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Moderation_logsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Moderation_logsBase(BaseModel):
    """Base schema for moderation_logs"""
    pass

class Moderation_logsCreate(Moderation_logsBase):
    """Schema for creating moderation_logs"""
    name: str
    description: Optional[str] = None
    status: Moderation_logsStatus = Moderation_logsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Moderation_logsUpdate(Moderation_logsBase):
    """Schema for updating moderation_logs"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Moderation_logsStatus] = None

class Moderation_logsResponse(Moderation_logsBase):
    """Response schema for moderation_logs"""
    id: str
    name: str
    description: Optional[str] = None
    status: Moderation_logsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_moderation_logs_create(data: Moderation_logsCreate) -> Moderation_logsCreate:
    """Validate moderation_logs creation data"""
    return data

def validate_moderation_logs_update(data: Moderation_logsUpdate) -> Moderation_logsUpdate:
    """Validate moderation_logs update data"""
    return data
