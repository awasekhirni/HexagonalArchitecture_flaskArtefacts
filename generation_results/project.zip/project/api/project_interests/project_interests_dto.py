from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Project_interestsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Project_interestsBase(BaseModel):
    """Base schema for project_interests"""
    pass

class Project_interestsCreate(Project_interestsBase):
    """Schema for creating project_interests"""
    name: str
    description: Optional[str] = None
    status: Project_interestsStatus = Project_interestsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Project_interestsUpdate(Project_interestsBase):
    """Schema for updating project_interests"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Project_interestsStatus] = None

class Project_interestsResponse(Project_interestsBase):
    """Response schema for project_interests"""
    id: str
    name: str
    description: Optional[str] = None
    status: Project_interestsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_project_interests_create(data: Project_interestsCreate) -> Project_interestsCreate:
    """Validate project_interests creation data"""
    return data

def validate_project_interests_update(data: Project_interestsUpdate) -> Project_interestsUpdate:
    """Validate project_interests update data"""
    return data
