from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.project_interests.project_interests_entity import Project_interests
from domain.project_interests.project_interests_service_interface import IAsyncProject_interestsService
from api.dtos.project_interests_dto import Project_interestsCreate, Project_interestsUpdate, Project_interestsResponse
from api.mappers.project_interests_mapper import project_interests_mapper
from api.validations.project_interests_validation_schemas import validate_project_interests_create, validate_project_interests_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('project_interests', description='Project_interests operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
project_interests_create_model = api.model('Project_interestsCreate', {
    'name': fields.String(required=True, description='project_interests name'),
    'description': fields.String(description='project_interests description'),
    'status': fields.String(description='project_interests status', enum=['active', 'inactive', 'pending'])
})

project_interests_update_model = api.model('Project_interestsUpdate', {
    'name': fields.String(description='project_interests name'),
    'description': fields.String(description='project_interests description'),
    'status': fields.String(description='project_interests status', enum=['active', 'inactive', 'pending'])
})

project_interests_response_model = api.model('Project_interestsResponse', {
    'id': fields.String(description='project_interests ID'),
    'name': fields.String(description='project_interests name'),
    'description': fields.String(description='project_interests description'),
    'status': fields.String(description='project_interests status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncProject_interestsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class Project_interestsList(Resource):
        @api.doc('list_project_interestss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(project_interests_response_model)
        @token_required
        async def get(self):
            """List all project_interestss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [project_interests_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting project_interestss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_project_interests')
        @api.expect(project_interests_create_model)
        @api.marshal_with(project_interests_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new project_interests"""
            try:
                data = api.payload
                validated_data = validate_project_interests_create(data)
                entity = project_interests_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return project_interests_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating project_interests: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The project_interests identifier')
    @api.response(404, 'Project_interests not found')
    class Project_interestsResource(Resource):
        @api.doc('get_project_interests')
        @api.marshal_with(project_interests_response_model)
        @token_required
        async def get(self, id):
            """Get a project_interests given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"Project_interests not found")
                return project_interests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting project_interests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_project_interests')
        @api.expect(project_interests_update_model)
        @api.marshal_with(project_interests_response_model)
        @token_required
        async def put(self, id):
            """Update a project_interests given its identifier"""
            try:
                data = api.payload
                validated_data = validate_project_interests_update(data)
                entity = project_interests_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"Project_interests not found")
                return project_interests_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating project_interests {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_project_interests')
        @api.response(204, 'Project_interests deleted')
        @token_required
        async def delete(self, id):
            """Delete a project_interests given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"Project_interests not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting project_interests {id}: {str(e)}")
                api.abort(400, str(e))

    return api
