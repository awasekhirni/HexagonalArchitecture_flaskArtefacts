from typing import List, Optional
from domain.project_interests.project_interests_entity import Project_interests
from domain.project_interests.project_interests_service_interface import IAsyncProject_interestsService
from infrastructure.repositories.project_interests.project_interests_repository import Project_interestsRepository
from api.mappers.project_interests_mapper import project_interests_mapper
from shared.utils.logger import logger

class Project_interestsService(IAsyncProject_interestsService):
    """Service implementation for Project_interests"""

    def __init__(self):
        self.repository = Project_interestsRepository()

    async def get_by_id(self, id: str) -> Optional[Project_interests]:
        """Get project_interests by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting project_interests by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Project_interests]:
        """Get all project_interestss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all project_interestss: {str(e)}")
            raise

    async def create(self, data: Project_interests) -> Project_interests:
        """Create new project_interests"""
        try:
            return await self.repository.create(project_interests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating project_interests: {str(e)}")
            raise

    async def update(self, id: str, data: Project_interests) -> Optional[Project_interests]:
        """Update project_interests"""
        try:
            return await self.repository.update(id, project_interests_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating project_interests: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete project_interests"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting project_interests: {str(e)}")
            raise
