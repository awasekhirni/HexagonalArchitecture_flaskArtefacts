from domain.project_interests.project_interests_entity import Project_interests
from api.dtos.project_interests_dto import Project_interestsCreate, Project_interestsUpdate, Project_interestsResponse
from typing import Union

class Project_interestsMapper:
    """Mapper for Project_interests between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Project_interests) -> Project_interestsResponse:
        """Convert entity to response DTO"""
        return Project_interestsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Project_interestsCreate, Project_interestsUpdate]) -> Project_interests:
        """Convert DTO to entity"""
        return Project_interests(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Project_interests, dto: Project_interestsUpdate) -> Project_interests:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

project_interests_mapper = Project_interestsMapper()
