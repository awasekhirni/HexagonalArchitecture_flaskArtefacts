from domain.blog_likes.blog_likes_entity import Blog_likes
from api.dtos.blog_likes_dto import Blog_likesCreate, Blog_likesUpdate, Blog_likesResponse
from typing import Union

class Blog_likesMapper:
    """Mapper for Blog_likes between entity and DTOs"""

    @staticmethod
    def to_dto(entity: Blog_likes) -> Blog_likesResponse:
        """Convert entity to response DTO"""
        return Blog_likesResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[Blog_likesCreate, Blog_likesUpdate]) -> Blog_likes:
        """Convert DTO to entity"""
        return Blog_likes(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: Blog_likes, dto: Blog_likesUpdate) -> Blog_likes:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

blog_likes_mapper = Blog_likesMapper()
