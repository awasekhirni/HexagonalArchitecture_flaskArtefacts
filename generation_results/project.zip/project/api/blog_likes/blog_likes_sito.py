from typing import List, Optional
from domain.blog_likes.blog_likes_entity import Blog_likes
from domain.blog_likes.blog_likes_service_interface import IAsyncBlog_likesService
from infrastructure.repositories.blog_likes.blog_likes_repository import Blog_likesRepository
from api.mappers.blog_likes_mapper import blog_likes_mapper
from shared.utils.logger import logger

class Blog_likesService(IAsyncBlog_likesService):
    """Service implementation for Blog_likes"""

    def __init__(self):
        self.repository = Blog_likesRepository()

    async def get_by_id(self, id: str) -> Optional[Blog_likes]:
        """Get blog_likes by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting blog_likes by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[Blog_likes]:
        """Get all blog_likess"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all blog_likess: {str(e)}")
            raise

    async def create(self, data: Blog_likes) -> Blog_likes:
        """Create new blog_likes"""
        try:
            return await self.repository.create(blog_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating blog_likes: {str(e)}")
            raise

    async def update(self, id: str, data: Blog_likes) -> Optional[Blog_likes]:
        """Update blog_likes"""
        try:
            return await self.repository.update(id, blog_likes_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating blog_likes: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete blog_likes"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting blog_likes: {str(e)}")
            raise
