from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class Blog_likesStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class Blog_likesBase(BaseModel):
    """Base schema for blog_likes"""
    pass

class Blog_likesCreate(Blog_likesBase):
    """Schema for creating blog_likes"""
    name: str
    description: Optional[str] = None
    status: Blog_likesStatus = Blog_likesStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class Blog_likesUpdate(Blog_likesBase):
    """Schema for updating blog_likes"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[Blog_likesStatus] = None

class Blog_likesResponse(Blog_likesBase):
    """Response schema for blog_likes"""
    id: str
    name: str
    description: Optional[str] = None
    status: Blog_likesStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_blog_likes_create(data: Blog_likesCreate) -> Blog_likesCreate:
    """Validate blog_likes creation data"""
    return data

def validate_blog_likes_update(data: Blog_likesUpdate) -> Blog_likesUpdate:
    """Validate blog_likes update data"""
    return data
