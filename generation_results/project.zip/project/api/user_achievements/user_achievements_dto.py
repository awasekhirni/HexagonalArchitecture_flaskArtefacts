from enum import Enum
from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime

class User_achievementsStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"

class User_achievementsBase(BaseModel):
    """Base schema for user_achievements"""
    pass

class User_achievementsCreate(User_achievementsBase):
    """Schema for creating user_achievements"""
    name: str
    description: Optional[str] = None
    status: User_achievementsStatus = User_achievementsStatus.ACTIVE

    @validator('name')
    def validate_name(cls, v):
        if len(v) < 3:
            raise ValueError("Name must be at least 3 characters")
        return v

class User_achievementsUpdate(User_achievementsBase):
    """Schema for updating user_achievements"""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[User_achievementsStatus] = None

class User_achievementsResponse(User_achievementsBase):
    """Response schema for user_achievements"""
    id: str
    name: str
    description: Optional[str] = None
    status: User_achievementsStatus
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True

def validate_user_achievements_create(data: User_achievementsCreate) -> User_achievementsCreate:
    """Validate user_achievements creation data"""
    return data

def validate_user_achievements_update(data: User_achievementsUpdate) -> User_achievementsUpdate:
    """Validate user_achievements update data"""
    return data
