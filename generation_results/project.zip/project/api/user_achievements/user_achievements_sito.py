from typing import List, Optional
from domain.user_achievements.user_achievements_entity import User_achievements
from domain.user_achievements.user_achievements_service_interface import IAsyncUser_achievementsService
from infrastructure.repositories.user_achievements.user_achievements_repository import User_achievementsRepository
from api.mappers.user_achievements_mapper import user_achievements_mapper
from shared.utils.logger import logger

class User_achievementsService(IAsyncUser_achievementsService):
    """Service implementation for User_achievements"""

    def __init__(self):
        self.repository = User_achievementsRepository()

    async def get_by_id(self, id: str) -> Optional[User_achievements]:
        """Get user_achievements by ID"""
        try:
            return await self.repository.get_by_id(id)
        except Exception as e:
            logger.error(f"Error getting user_achievements by ID: {str(e)}")
            raise

    async def get_all(self, skip: int = 0, limit: int = 100) -> List[User_achievements]:
        """Get all user_achievementss"""
        try:
            return await self.repository.get_all(skip=skip, limit=limit)
        except Exception as e:
            logger.error(f"Error getting all user_achievementss: {str(e)}")
            raise

    async def create(self, data: User_achievements) -> User_achievements:
        """Create new user_achievements"""
        try:
            return await self.repository.create(user_achievements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error creating user_achievements: {str(e)}")
            raise

    async def update(self, id: str, data: User_achievements) -> Optional[User_achievements]:
        """Update user_achievements"""
        try:
            return await self.repository.update(id, user_achievements_mapper.to_entity(data))
        except Exception as e:
            logger.error(f"Error updating user_achievements: {str(e)}")
            raise

    async def delete(self, id: str) -> bool:
        """Delete user_achievements"""
        try:
            return await self.repository.delete(id)
        except Exception as e:
            logger.error(f"Error deleting user_achievements: {str(e)}")
            raise
