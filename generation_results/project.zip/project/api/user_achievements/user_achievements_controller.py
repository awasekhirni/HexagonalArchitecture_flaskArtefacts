from flask_restx import Namespace, Resource, fields, reqparse
from typing import List, Optional
from domain.user_achievements.user_achievements_entity import User_achievements
from domain.user_achievements.user_achievements_service_interface import IAsyncUser_achievementsService
from api.dtos.user_achievements_dto import User_achievementsCreate, User_achievementsUpdate, User_achievementsResponse
from api.mappers.user_achievements_mapper import user_achievements_mapper
from api.validations.user_achievements_validation_schemas import validate_user_achievements_create, validate_user_achievements_update
from shared.utils.auth import token_required
from shared.utils.logger import logger

# Initialize namespace
api = Namespace('user_achievements', description='User_achievements operations')

# Request parsers
pagination_parser = reqparse.RequestParser()
pagination_parser.add_argument('page', type=int, help='Page number', default=1)
pagination_parser.add_argument('per_page', type=int, help='Items per page', default=10)

# Model definitions
user_achievements_create_model = api.model('User_achievementsCreate', {
    'name': fields.String(required=True, description='user_achievements name'),
    'description': fields.String(description='user_achievements description'),
    'status': fields.String(description='user_achievements status', enum=['active', 'inactive', 'pending'])
})

user_achievements_update_model = api.model('User_achievementsUpdate', {
    'name': fields.String(description='user_achievements name'),
    'description': fields.String(description='user_achievements description'),
    'status': fields.String(description='user_achievements status', enum=['active', 'inactive', 'pending'])
})

user_achievements_response_model = api.model('User_achievementsResponse', {
    'id': fields.String(description='user_achievements ID'),
    'name': fields.String(description='user_achievements name'),
    'description': fields.String(description='user_achievements description'),
    'status': fields.String(description='user_achievements status'),
    'created_at': fields.DateTime(description='Creation timestamp'),
    'updated_at': fields.DateTime(description='Last update timestamp')
})

def initialize_controller(service: IAsyncUser_achievementsService):
    """Initialize controller with service dependency"""

    @api.route('/')
    class User_achievementsList(Resource):
        @api.doc('list_user_achievementss')
        @api.expect(pagination_parser)
        @api.marshal_list_with(user_achievements_response_model)
        @token_required
        async def get(self):
            """List all user_achievementss"""
            try:
                args = pagination_parser.parse_args()
                skip = (args['page'] - 1) * args['per_page']
                limit = args['per_page']

                results = await service.get_all(skip=skip, limit=limit)
                return [user_achievements_mapper.to_dto(item) for item in results]
            except Exception as e:
                logger.error(f"Error getting user_achievementss: {str(e)}")
                api.abort(400, str(e))

        @api.doc('create_user_achievements')
        @api.expect(user_achievements_create_model)
        @api.marshal_with(user_achievements_response_model, code=201)
        @token_required
        async def post(self):
            """Create a new user_achievements"""
            try:
                data = api.payload
                validated_data = validate_user_achievements_create(data)
                entity = user_achievements_mapper.to_entity(validated_data)
                result = await service.create(entity.to_dict())
                return user_achievements_mapper.to_dto(result), 201
            except Exception as e:
                logger.error(f"Error creating user_achievements: {str(e)}")
                api.abort(400, str(e))

    @api.route('/<string:id>')
    @api.param('id', 'The user_achievements identifier')
    @api.response(404, 'User_achievements not found')
    class User_achievementsResource(Resource):
        @api.doc('get_user_achievements')
        @api.marshal_with(user_achievements_response_model)
        @token_required
        async def get(self, id):
            """Get a user_achievements given its identifier"""
            try:
                result = await service.get_by_id(id)
                if not result:
                    api.abort(404, f"User_achievements not found")
                return user_achievements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error getting user_achievements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('update_user_achievements')
        @api.expect(user_achievements_update_model)
        @api.marshal_with(user_achievements_response_model)
        @token_required
        async def put(self, id):
            """Update a user_achievements given its identifier"""
            try:
                data = api.payload
                validated_data = validate_user_achievements_update(data)
                entity = user_achievements_mapper.to_entity(validated_data)
                result = await service.update(id, entity.to_dict())
                if not result:
                    api.abort(404, f"User_achievements not found")
                return user_achievements_mapper.to_dto(result)
            except Exception as e:
                logger.error(f"Error updating user_achievements {id}: {str(e)}")
                api.abort(400, str(e))

        @api.doc('delete_user_achievements')
        @api.response(204, 'User_achievements deleted')
        @token_required
        async def delete(self, id):
            """Delete a user_achievements given its identifier"""
            try:
                success = await service.delete(id)
                if not success:
                    api.abort(404, f"User_achievements not found")
                return '', 204
            except Exception as e:
                logger.error(f"Error deleting user_achievements {id}: {str(e)}")
                api.abort(400, str(e))

    return api
