from domain.user_achievements.user_achievements_entity import User_achievements
from api.dtos.user_achievements_dto import User_achievementsCreate, User_achievementsUpdate, User_achievementsResponse
from typing import Union

class User_achievementsMapper:
    """Mapper for User_achievements between entity and DTOs"""

    @staticmethod
    def to_dto(entity: User_achievements) -> User_achievementsResponse:
        """Convert entity to response DTO"""
        return User_achievementsResponse(
            id=str(entity.id),
            name=entity.name,
            description=entity.description,
            status=entity.status,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )

    @staticmethod
    def to_entity(dto: Union[User_achievementsCreate, User_achievementsUpdate]) -> User_achievements:
        """Convert DTO to entity"""
        return User_achievements(
            name=dto.name,
            description=dto.description,
            status=dto.status
        )

    @staticmethod
    def update_entity(entity: User_achievements, dto: User_achievementsUpdate) -> User_achievements:
        """Update entity from DTO"""
        if dto.name is not None:
            entity.name = dto.name
        if dto.description is not None:
            entity.description = dto.description
        if dto.status is not None:
            entity.status = dto.status
        return entity

user_achievements_mapper = User_achievementsMapper()
