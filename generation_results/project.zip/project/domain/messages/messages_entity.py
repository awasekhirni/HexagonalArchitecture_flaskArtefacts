from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class Messages(Base):
    __tablename__ = 'messages'

    message_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d6f2e10>, for_update=False))
    sender_id = Column(UUID(as_uuid=True))
    receiver_id = Column(UUID(as_uuid=True))
    content = Column(Text)
    sent_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d6f2e70>, for_update=False))
    is_read = Column(Boolean, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d6f2ed0>, for_update=False))

    def __repr__(self):
        return f"<Messages(message_id={self.message_id}, sender_id={self.sender_id}, receiver_id={self.receiver_id})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})
