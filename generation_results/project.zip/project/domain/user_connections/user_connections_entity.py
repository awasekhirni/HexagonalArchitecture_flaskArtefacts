from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class StatusEnum(str, Enum):
    """Enum for connection_status column"""
    VALUE1 = "value1"
    VALUE2 = "value2"
    VALUE3 = "value3"

class User_connections(Base):
    __tablename__ = 'user_connections'

    user_id = Column(UUID(as_uuid=True), primary_key=True)
    connected_user_id = Column(UUID(as_uuid=True), primary_key=True)
    connection_status = Column(String, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d593a70>, for_update=False), type_=SqlEnum(StatusEnum))
    connection_date = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d593ad0>, for_update=False))
    users = relationship('users')

    def __repr__(self):
        return f"<User_connections(user_id={self.user_id}, connected_user_id={self.connected_user_id}, connection_status={self.connection_status})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})
