from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class User_resumes(Base):
    __tablename__ = 'user_resumes'

    user_resumes_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d5912b0>, for_update=False))
    user_id = Column(UUID(as_uuid=True))
    resume_file_url = Column(Text)
    resume_encrypted = Column(Text)
    uploaded_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d591310>, for_update=False))
    users = relationship('users')
    profile_access_audit_collection = relationship('profile_access_audit', back_populates='user_resumes')

    def __repr__(self):
        return f"<User_resumes(user_resumes_id={self.user_resumes_id}, user_id={self.user_id}, resume_file_url={self.resume_file_url})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})
