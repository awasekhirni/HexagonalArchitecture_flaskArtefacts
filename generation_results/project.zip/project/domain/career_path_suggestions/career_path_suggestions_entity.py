from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class RoleEnum(str, Enum):
    """Enum for predicted_role column"""
    VALUE1 = "value1"
    VALUE2 = "value2"
    VALUE3 = "value3"

class Career_path_suggestions(Base):
    __tablename__ = 'career_path_suggestions'

    career_path_suggestion_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d656f30>, for_update=False))
    user_id = Column(UUID(as_uuid=True))
    predicted_role = Column(String, type_=SqlEnum(RoleEnum))
    confidence_level = Column(Float)
    suggested_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d656f90>, for_update=False))
    users = relationship('users')

    def __repr__(self):
        return f"<Career_path_suggestions(career_path_suggestion_id={self.career_path_suggestion_id}, user_id={self.user_id}, predicted_role={self.predicted_role})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})
