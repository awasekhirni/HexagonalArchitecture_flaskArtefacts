from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class Freelance_services(Base):
    __tablename__ = 'freelance_services'

    service_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d656390>, for_update=False))
    user_id = Column(UUID(as_uuid=True))
    service_title = Column(String)
    service_description = Column(Text)
    hourly_rate = Column(String)
    availability = Column(String, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d6563f0>, for_update=False))
    created_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d656450>, for_update=False))
    users = relationship('users')
    freelance_requests_collection = relationship('freelance_requests', back_populates='freelance_services')

    def __repr__(self):
        return f"<Freelance_services(service_id={self.service_id}, user_id={self.user_id}, service_title={self.service_title})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})

    def update_timestamps(self):
        """Update timestamp fields"""
        if hasattr(self, 'updated_at'):
            self.updated_at = datetime.utcnow()
        elif hasattr(self, 'created_at') and not self.created_at:
            self.created_at = datetime.utcnow()
