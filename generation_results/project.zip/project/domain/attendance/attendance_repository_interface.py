from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from domain.attendance.attendance_entity import Attendance
from shared.async_base_repository import IAsyncBaseRepository

class IAsyncAttendanceRepository(IAsyncBaseRepository[Attendance], ABC):
    """Async repository interface for Attendance"""

@abstractmethod
async def get_by_id(self, id: Union[int, str, UUID]) -> Optional[{class_name}]:
    """Get entity by ID"""
    pass

@abstractmethod
async def get_all(self, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get all entities"""
    pass

@abstractmethod
async def create(self, data: Dict[str, Any]) -> {class_name}:
    """Create new entity"""
    pass

@abstractmethod
async def update(self, id: Union[int, str, UUID], data: Dict[str, Any]) -> Optional[{class_name}]:
    """Update entity"""
    pass

@abstractmethod
async def delete(self, id: Union[int, str, UUID]) -> bool:
    """Delete entity"""
    pass

@abstractmethod
async def get_by_status(self, status: str, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get entities by status"""
    pass

@abstractmethod
async def change_status(self, id: Union[int, str, UUID], new_status: str) -> Optional[{class_name}]:
    """Change entity status"""
    pass

@abstractmethod
async def get_created_after(self, timestamp: datetime, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get entities created after timestamp"""
    pass

@abstractmethod
async def get_updated_after(self, timestamp: datetime, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get entities updated after timestamp"""
    pass

@abstractmethod
async def get_with_relations(self, id: Union[int, str, UUID], relation_names: List[str]) -> Optional[{class_name}]:
    """Get entity with relations"""
    pass

@abstractmethod
async def count(self) -> int:
    """Count entities"""
    pass

@abstractmethod
async def exists(self, **filters: Any) -> bool:
    """Check if entity exists"""
    pass

@abstractmethod
async def bulk_create(self, items: List[Dict[str, Any]]) -> List[{class_name}]:
    """Bulk create entities"""
    pass
