from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class StatusEnum(str, Enum):
    """Enum for attendance_status column"""
    VALUE1 = "value1"
    VALUE2 = "value2"
    VALUE3 = "value3"

class Attendance(Base):
    __tablename__ = 'attendance'

    attendance_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10cf3bd10>, for_update=False))
    employee_id = Column(UUID(as_uuid=True))
    check_in_time = Column(DateTime, nullable=False)
    check_out_time = Column(DateTime)
    worked_hours = Column(String)
    attendance_status = Column(String, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10cf3bd70>, for_update=False), type_=SqlEnum(StatusEnum))
    created_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10cf3bdd0>, for_update=False))
    employees = relationship('employees')

    def __repr__(self):
        return f"<Attendance(attendance_id={self.attendance_id}, employee_id={self.employee_id}, check_in_time={self.check_in_time})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})

    def update_timestamps(self):
        """Update timestamp fields"""
        if hasattr(self, 'updated_at'):
            self.updated_at = datetime.utcnow()
        elif hasattr(self, 'created_at') and not self.created_at:
            self.created_at = datetime.utcnow()
