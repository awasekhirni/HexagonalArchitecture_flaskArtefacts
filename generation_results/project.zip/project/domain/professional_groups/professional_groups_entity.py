from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class Professional_groups(Base):
    __tablename__ = 'professional_groups'

    group_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d657590>, for_update=False))
    group_name = Column(String)
    group_description = Column(Text)
    created_by = Column(UUID(as_uuid=True))
    created_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10d6575f0>, for_update=False))
    users = relationship('users')

    def __repr__(self):
        return f"<Professional_groups(group_id={self.group_id}, group_name={self.group_name}, group_description={self.group_description})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})

    def update_timestamps(self):
        """Update timestamp fields"""
        if hasattr(self, 'updated_at'):
            self.updated_at = datetime.utcnow()
        elif hasattr(self, 'created_at') and not self.created_at:
            self.created_at = datetime.utcnow()
