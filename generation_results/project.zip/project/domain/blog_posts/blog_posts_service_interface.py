from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from domain.blog_posts.blog_posts_entity import Blog_posts
from shared.async_base_service import IAsyncBaseService

class IAsyncBlog_postsService(IAsyncBaseService[Blog_posts], ABC):
    """Async service interface for Blog_posts"""

@abstractmethod
async def get_by_id(self, id: Union[int, str, UUID]) -> Optional[{class_name}]:
    """Get entity by ID"""
    pass

@abstractmethod
async def get_all(self, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get all entities"""
    pass

@abstractmethod
async def create(self, data: Dict[str, Any]) -> {class_name}:
    """Create new entity"""
    pass

@abstractmethod
async def update(self, id: Union[int, str, UUID], data: Dict[str, Any]) -> Optional[{class_name}]:
    """Update entity"""
    pass

@abstractmethod
async def delete(self, id: Union[int, str, UUID]) -> bool:
    """Delete entity"""
    pass

@abstractmethod
async def get_recently_created(self, days: int = 7, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get recently created entities"""
    pass

@abstractmethod
async def get_recently_updated(self, days: int = 7, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get recently updated entities"""
    pass

@abstractmethod
async def get_for_user(self, user_id: Union[int, str, UUID], skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Get entities for user"""
    pass

@abstractmethod
async def search(self, query: str, fields: List[str] = None, skip: int = 0, limit: int = 100) -> List[{class_name}]:
    """Search entities"""
    pass

@abstractmethod
async def get_stats(self) -> Dict[str, Any]:
    """Get statistics"""
    pass

@abstractmethod
async def export_to_csv(self, filters: Optional[Dict[str, Any]] = None) -> str:
    """Export to CSV"""
    pass

@abstractmethod
async def import_from_csv(self, csv_data: str) -> int:
    """Import from CSV"""
    pass
