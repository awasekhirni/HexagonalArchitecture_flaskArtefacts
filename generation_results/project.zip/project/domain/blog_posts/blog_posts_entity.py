from enum import Enum, auto
from uuid import uuid4
from datetime import datetime
from typing import Dict, Any, Optional, List
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum as SqlEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from infrastructure.database.db import Base

class Blog_posts(Base):
    __tablename__ = 'blog_posts'

    blog_post_id = Column(UUID(as_uuid=True), primary_key=True, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10cfd56d0>, for_update=False))
    user_id = Column(UUID(as_uuid=True))
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime, server_default=DefaultClause(<sqlalchemy.sql.elements.TextClause object at 0x10cfd6150>, for_update=False))
    updated_at = Column(DateTime)
    users = relationship('users')
    blog_comments_collection = relationship('blog_comments', back_populates='blog_posts')
    blog_likes_collection = relationship('blog_likes', back_populates='blog_posts')

    def __repr__(self):
        return f"<Blog_posts(blog_post_id={self.blog_post_id}, user_id={self.user_id}, title={self.title})>"

    def to_dict(self, include_relationships: bool = False) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        data = {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }

        if include_relationships:
            for rel in self.__mapper__.relationships:
                if rel.direction.name == 'MANYTOONE':
                    data[rel.key] = getattr(self, rel.key).to_dict() if getattr(self, rel.key) else None
                elif rel.direction.name == 'ONETOMANY':
                    data[rel.key] = [item.to_dict() for item in getattr(self, rel.key)]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]):
        """Create entity from dictionary"""
        return cls(**{k: v for k, v in data.items() if k in cls.__table__.columns})

    def update_timestamps(self):
        """Update timestamp fields"""
        if hasattr(self, 'updated_at'):
            self.updated_at = datetime.utcnow()
        elif hasattr(self, 'created_at') and not self.created_at:
            self.created_at = datetime.utcnow()
